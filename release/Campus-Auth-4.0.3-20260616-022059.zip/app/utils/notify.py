#!/usr/bin/env python3
"""跨平台桌面通知模块"""

from __future__ import annotations

import os
import shutil
import subprocess

from .logging import get_logger
from .platform import CREATE_NO_WINDOW_FLAG, is_linux, is_macos, is_windows

logger = get_logger("notify", source="backend")


def _notify_windows(title: str, message: str, duration_ms: int) -> bool:
    """Windows: 使用 PowerShell Toast 通知"""

    # PowerShell 双引号上下文中需要转义: `, ", $, \n, \r
    def _escape_ps(s: str) -> str:
        return s.replace("`", "``").replace('"', '`"').replace("$", "`$").replace("\n", "`n").replace("\r", "`r")

    safe_title = _escape_ps(title)
    safe_msg = _escape_ps(message)
    duration_sec = max(1, duration_ms // 1000)

    ps_script = f'''
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null
$template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
$textNodes = $template.GetElementsByTagName("text")
$textNodes.Item(0).AppendChild($template.CreateTextNode("{safe_title}")) > $null
$textNodes.Item(1).AppendChild($template.CreateTextNode("{safe_msg}")) > $null
$toast = [Windows.UI.Notifications.ToastNotification]::new($template)
$toast.ExpirationTime = [DateTimeOffset]::Now.AddSeconds({duration_sec})
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("Campus-Auth").Show($toast)
'''

    try:
        result = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                ps_script,
            ],
            capture_output=True,
            text=True,
            timeout=10,
            creationflags=CREATE_NO_WINDOW_FLAG,
        )
        if result.returncode == 0:
            logger.debug("Windows 通知已发送: {}", title)
            return True
    except Exception:
        logger.debug("PowerShell 通知发送失败", exc_info=True)

    # PowerShell 方案失败时回退到 msg（仅 Windows Pro/Enterprise 可用）
    try:
        result = subprocess.run(
            ["msg", os.environ.get("USERNAME", "*"), f"{title}: {message}"],
            capture_output=True,
            timeout=5,
            creationflags=CREATE_NO_WINDOW_FLAG,
        )
        return result.returncode == 0
    except FileNotFoundError:
        logger.debug("msg 命令不可用（仅 Windows Pro/Enterprise 支持）")
    except Exception:
        logger.debug("msg 通知发送失败", exc_info=True)

    return False


def _notify_macos(title: str, message: str) -> bool:
    """macOS: 使用 osascript 发送通知"""
    try:
        # 先转义反斜杠再转义双引号，防止反斜杠导致双引号逃逸
        # macOS osascript 不支持通知中的换行符，替换为空格
        safe_title = title.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")
        safe_msg = message.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")
        script = f'display notification "{safe_msg}" with title "{safe_title}"'
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.returncode == 0
    except Exception:
        return False


def _notify_linux(title: str, message: str, duration_ms: int) -> bool:
    """Linux: 使用 notify-send"""
    # 检查 notify-send 是否已安装，避免因命令不存在而抛出异常
    if not shutil.which("notify-send"):
        logger.warning("未找到 notify-send，无法发送 Linux 桌面通知")
        return False
    duration_sec = max(1, duration_ms // 1000) * 1000
    result = subprocess.run(
        ["notify-send", title, message, "-t", str(duration_sec), "-a", "Campus-Auth"],
        capture_output=True,
        text=True,
        timeout=5,
    )
    return result.returncode == 0
