(function () {
  const MAX_INCLUDE_DEPTH = 12;

  async function fetchInclude(el) {
    const src = el.getAttribute('data-include');
    if (!src) return;

    try {
      const res = await fetch(src, { cache: 'no-cache' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const html = await res.text();
      const temp = document.createElement('div');
      temp.innerHTML = html;
      // 用获取的内容替换整个 data-include div，避免多余的包装壳
      el.replaceWith(...temp.childNodes);

    } catch (err) {
      const errDiv = document.createElement('div');
      errDiv.className = 'include-error';
      errDiv.textContent = '模板加载失败: ' + src;
      el.replaceWith(errDiv);
      console.error('[template-loader] failed:', src, err);
    }
  }

  async function includeRecursively(root) {
    if (!root) return;

    for (let i = 0; i < MAX_INCLUDE_DEPTH; i += 1) {
      const nodes = root.querySelectorAll('[data-include]');
      if (!nodes.length) return;
      await Promise.all(Array.from(nodes, node => fetchInclude(node)));
    }
  }

  window.loadFrontendPartials = async function () {
    const appRoot = document.getElementById('app');
    await includeRecursively(appRoot);
  };
})();
