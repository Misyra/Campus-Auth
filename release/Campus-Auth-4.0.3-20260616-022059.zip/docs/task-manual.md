# Campus-Auth 开发文档

本文档面向开发者，详细描述 Campus-Auth 的内部架构、执行流程、API 接口及配置参考。如需编写任务 JSON，请参阅 [任务编写指南](task-writing-guide.md)。

## 目录

1. [架构概览](#架构概览)
2. [任务执行流程](#任务执行流程)
3. [变量解析机制](#变量解析机制)
4. [Frame 上下文切换](#frame-上下文切换)
5. [浏览器反检测](#浏览器反检测)
6. [错误处理与重试](#错误处理与重试)
7. [截图机制](#截图机制)
8. [校验规则](#校验规则)
9. [任务文件管理](#任务文件管理)
10. [API 参考](#api-参考)
11. [环境变量参考](#环境变量参考)

---

## 架构概览

系统由统一后台引擎 `ScheduleEngine` 驱动，同时管理网络监控和定时任务调度：

```
ScheduleEngine             统一后台引擎（网络监控 + 定时任务调度）
    ├── NetworkMonitorCore     网络监控核心（检测断网、触发登录）
    │       └── LoginAttemptHandler     登录处理器
    │               └── TaskExecutor(step)   步骤执行器
    └── TaskRegistry           定时任务注册表
            └── TaskExecutor(task)       任务执行（script/browser/shell）
```

### 核心模块

| 模块 | 文件 | 职责 |
|------|------|------|
| `NetworkMonitorCore` | `app/services/monitor_service.py` | 网络检测循环、重试退避、Profile 自动切换 |
| `LoginAttemptHandler` | `app/utils/login.py` | 任务加载、环境变量构建、浏览器生命周期管理 |
| `BrowserContextManager` | `app/utils/browser.py` | Playwright 浏览器启动与配置、反检测注入 |
| `TaskExecutor` | `app/tasks/models.py` | 任务配置模型（TaskConfig, StepConfig） |
| `TaskManager` | `app/tasks/models.py` | 任务文件的 CRUD 操作 |
| `TaskService` | `app/services/task_service.py` | 任务 API 的后端服务层 |
| `ScheduleEngine` | `app/services/engine.py` | 统一后台引擎（监控 + 定时调度，Actor 模型） |
| `TaskExecutor` (execution) | `app/services/task_executor.py` | 双线程池任务执行中心 |

---

## 任务执行流程

### 从监控到登录的完整链路

**1. 网络检测（NetworkMonitorCore）**

`monitor_network()` 主循环每次迭代：
- 检查是否在暂停时段内（`check_pause()`）
- 对配置的探测目标发起并发检测（`check_network_status()`）
  - URL 响应检测：访问 `http://www.msftconnecttest.com/connecttest.txt`、`http://detectportal.firefox.com/success.txt`、`http://captive.apple.com/hotspot-detect.html`
  - TCP 探测：可配置目标
  - HTTP 探测：可配置目标
  - 本地网络检测：通过 `psutil` 检查网卡接口状态
- 检查登录前置条件（`check_login_prerequisites()`）：物理网络 + 认证地址可达性
- 连接失败则调用 `attempt_login()`

**2. 登录准备（LoginAttemptHandler）**

`LoginAttemptHandler` 支持两种任务类型：

**浏览器任务（默认）：**
1. 通过 `TaskManager.get_active_task()` 获取当前活动任务 ID
2. 加载对应的 `TaskConfig` JSON 文件
3. 构建环境变量字典（覆盖顺序见下方）
4. 创建 `BrowserContextManager` 获取浏览器页面
5. 设置弹窗监听器（自动关闭 alert/confirm/prompt）
6. 创建 `TaskExecutor` 并调用 `executor.execute(page)`

**脚本任务：**
1. 加载脚本任务配置
2. 使用 `ScriptRunner` 在子进程中执行脚本
3. 脚本完成后通过网络检测验证登录是否成功

**环境变量构建的覆盖顺序（后者覆盖前者）：**

| 优先级 | 变量 | 来源 |
|--------|------|------|
| 1（最低） | 所有变量 | 系统环境变量（`os.environ`） |
| 2 | `LOGIN_URL` | 配置中的认证地址 |
| 3 | `LOGIN_URL` | 任务的 `url` 字段（经过模板解析），覆盖配置值 |
| 4 | `ISP`、`USERNAME`、`PASSWORD` | 配置中的账号信息 |
| 5（最高） | 自定义变量 | `config["custom_variables"]`（过滤掉系统保留变量名如 `PATH`、`HOME` 等） |

**3. 步骤执行（TaskExecutor）**

`execute(page)` 的流程：
1. 记录任务开始时间，计算全局超时截止时间
2. 调用 `_auto_navigate(page)` 自动导航到认证地址
3. 遍历 `config.steps`：
   - 检查是否超过全局超时
   - 跳过 `navigate` 类型步骤（已由自动导航处理）
   - 步骤间休眠 0.5 秒（可通过任务 JSON 顶层的 `step_delay` 字段配置，浮点数，单位秒）
   - 从 `StepExecutorRegistry` 查找对应的 `StepHandler`
   - 调用 `handler.execute(page, step, resolver)`
   - 记录步骤结果；任一步骤失败立即终止
4. 所有步骤成功后，执行网络检测兜底判断

 **4. 网络检测兜底**

系统统一使用网络连通性检测判断任务成功与否：任务步骤全部完成后，自动检测网络是否可达（超时约 10 秒）。网络通 = 认证成功，网络断 = 认证失败。检测失败时会在日志中显示具体原因。原有 `success_conditions` 字段仅保留兼容性，不再参与判断。

---

## 变量解析机制

### VariableResolver

模板语法：`{{变量名}}`，正则匹配 `\{\{(\w+)\}\}`。

**三级查找优先级（从高到低）：**

| 优先级 | 来源 | 说明 |
|--------|------|------|
| 1 | 运行时变量 | `eval`/`ocr` 步骤通过 `store_as` 写入，以及任务元数据（`url`、`name`、`description`） |
| 2 | 模板变量 + 自定义变量 | 运行时配置变量 + 自定义变量，由 `build_login_template_vars()` 合并为 `template_vars` 字典，不单独成级 |
| 3 | 任务变量 | 任务 JSON 的 `variables` 字段（自身也支持模板引用） |

**递归解析规则：**
- 解析后的值如果仍包含 `{{`，会递归解析，最大深度 8 层
- 循环引用检测：维护 `visited` 集合，重复出现的变量名会抛出 `StepError`
- 未找到的变量：原样保留 `{{VAR}}` 在输出中（不报错）
- 缓存：首次解析的结果会被缓存，`set_runtime_var()` 调用时清除缓存

**解析的触发点：**
- `StepHandler.resolve_params()` — 解析步骤的所有字段
- `_auto_navigate()` — 解析任务的 `url` 字段
- `LoginAttemptHandler` — 解析任务 URL 后存入环境变量

---

## Frame 上下文切换

通过步骤的 `frame` 字段指定目标 frame（必须是字符串，不支持布尔值），`StepHandler._resolve_frame()` 依次尝试三种定位方式：

1. **按 name 属性：** `page.frame(name=frame_selector)`
2. **按 URL 匹配：** `page.frame(url=frame_selector)`
3. **按 CSS 选择器：** 先用 `page.query_selector(frame_selector)` 定位 iframe 元素，再调用 `element.content_frame()` 获取 frame 对象

如果三种方式都失败，系统会回退到主页面继续执行（不会直接失败），这是一种容错设计。

返回的 frame 对象作为 `ctx` 传入 `_find_element()`，所有元素查找都在该上下文中进行。

`frame` 字段只接受字符串类型。执行器在配置解析阶段（`StepConfig.from_dict`）和运行时阶段（`_resolve_frame`）各有一次类型检查：

- **配置解析时：** 如果 `frame` 的值不是字符串且不为 `null`（例如 `true`、`123` 等），会记录一条警告日志 `[StepConfig] 步骤 X 的 frame 字段应为字符串，实际为 bool，已忽略`，并自动清空该字段。
- **运行时：** 如果 `frame` 的值仍不是字符串，会记录 `[frame] 步骤 X 的 frame 字段应为字符串，将回退到主页面执行`，然后直接使用主页面执行步骤。

两层防御确保错误的 `frame` 类型不会导致执行器崩溃，而是安全降级到主页面。

---

## 浏览器反检测

`BrowserContextManager._start_browser()` 通过 `page.add_init_script()` 在页面 JavaScript 执行前注入反检测脚本：

### 注入的 JavaScript

**隐藏自动化标志：**
```js
Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
```

**伪造插件列表：** 模拟 Chrome 默认的三个插件（Chrome PDF Plugin、Chrome PDF Viewer、Native Client），包含完整的 `item()`、`namedItem()` 方法和 `Symbol.iterator` 支持。

**伪造 chrome 对象：**
```js
window.chrome = {
    runtime: { connect: function(){}, sendMessage: function(){} },
    loadTimes: function() { return {}; },
    csi: function() { return {}; },
};
```

**语言覆盖：** `navigator.languages = ['zh-CN', 'zh', 'en-US', 'en']`

**清理 Playwright 痕迹：** `delete window.__playwright; delete window.__pw_manual;`

### 浏览器上下文配置

| 配置项 | 值 | 说明 |
|--------|-----|------|
| `has_touch` | `false` | 桌面模式 |
| `color_scheme` | `"light"` | 浅色主题 |
| `locale` | `"zh-CN"` | 中文语言 |
| `timezone_id` | `"Asia/Shanghai"` | 上海时区 |
| `ignore_https_errors` | `True` | 忽略 HTTPS 证书错误 |
| `user_agent` | 可自定义 | 来自 config 的 `browser_user_agent` |
| `extra_http_headers` | 可自定义 | 来自 config 的 `browser_extra_headers_json` |

### 低资源模式

启用后通过 Playwright 的路由功能拦截以下请求类型：
- 图片（`image`）
- 字体（`font`）
- 媒体（`media`）

返回空响应，减少带宽和内存占用。

### 安全模式

使用纯净 Chromium 启动（不加载任何扩展），通过 `--disable-extensions` 参数实现，用于解决浏览器插件冲突问题。

---

## 错误处理与重试

### 任务执行层面

- 每个步骤的执行都包裹在 try/except 中，异常被捕获并返回 `(False, 错误信息)`
- 全局超时：每步执行前检查 `perf_counter() - start > timeout / 1000`，超时立即失败
- 任一步骤失败 → 调用 `_handle_failure()` → 截图 + 构建错误消息 → 返回

### 步骤自动降级

部分步骤类型在正常执行失败后会自动降级到备用方式，提高兼容性：

| 步骤类型 | 降级行为 |
|----------|----------|
| `input` | 普通 `fill()` 失败 → 自动降级到 JS 强制输入（跳过可见性检查，通过原生 setter 设置值并触发完整事件链：focus → clear → set value → input → change → blur） |
| `click` | 普通 `click()` 失败 → 自动降级到 `dispatch_event('click')` 强制点击 |

所有降级自动完成，无需手动配置，也不支持关闭。

### 监控重试机制

`NetworkMonitorCore` 的重试策略：

| 配置项 | 默认值 | 说明 |
|--------|--------|------|
| `retry_settings.max_retries` | 3 | 最大重试次数 |
| `retry_settings.retry_interval` | 5 | 基础重试间隔（秒） |

**退避算法：** 指数退避，第 N 次重试的等待时间为 `retry_interval × 2^(N-1)`。
- 默认配置下：5s → 10s → 20s

**重试结果：**
- `"retry"` — 等待后重试
- `"break"` — 等待期间监控被停止
- `"give_up"` — 所有重试用尽，重置计数器，回到正常检测间隔

**通知：** 第 2 次失败和放弃时会发送桌面通知。

### 浏览器复用与健康检查

启用浏览器复用时，每次登录前检查：
- `browser.is_connected()` — 浏览器进程是否存活
- `not page.is_closed()` — 页面是否仍然打开

检查失败则关闭旧浏览器并创建新的。

### 可中断等待

`_wait_interruptible(seconds, step)` 以 5 秒为单位分段休眠，每段检查 `self.monitoring` 标志。如果监控在等待期间被停止，立即返回 `False`，实现优雅退出。

---

## 截图机制

### 自动失败截图

当 `on_failure.screenshot` 不为 `false`（默认 `true`）时，任务失败会自动截图：

- 保存目录：`debug/{YYYY-MM-DD}/`
- 文件名格式：`{task_id}_{YYYYMMDD_HHMMSS_microseconds}.png`
- 截图方式：`page.screenshot(path=..., full_page=True)`
- 返回 URL 路径如 `/debug/2026-05-09/taskid_20260509_143022_123456.png`，追加到失败消息中

### 手动截图步骤

任务中的 `screenshot` 步骤：
- 保存目录同上
- 指定 `path` 时仅取文件名（目录由系统管理）
- 未指定时自动生成 `{task_id}_{step_id}_{timestamp}.png`

### 调试模式截图

逐步调试时，每步执行完成后都会自动截图，用于在调试面板中展示每步的页面状态。

---

## 校验规则

### 任务级校验

| 规则 | 错误信息 |
|------|----------|
| 必须包含 `name` 字段 | "任务必须包含 'name' 字段" |
| 必须包含 `steps` 字段 | "任务必须包含 'steps' 字段" |
| `steps` 必须是数组 | "'steps' 必须是数组" |

### 步骤级校验

每个步骤必须包含 `id` 和 `type` 字段。`type` 必须是以下之一：

`navigate`（已废弃，请使用任务的 `url` 字段）、`custom_js`（已废弃，请使用 `eval`）、`input`、`click`、`select`、`click_select`、`wait`、`wait_url`、`eval`、`screenshot`、`sleep`、`ocr`

各类型的额外必填字段：

| 类型 | 必填字段 |
|------|----------|
| `navigate`（已废弃，请使用任务的 `url` 字段） | `url` |
| `input` | `selector` |
| `click` | `selector` |
| `select` | `selector` |
| `click_select` | `selector` |
| `wait` | `selector` |
| `wait_url` | `pattern` |
| `eval` | `script`（兼容已废弃的 `code`） |
| `screenshot` | 无 |
| `sleep` | 无 |
| `ocr` | `selector` |

### 成功判断

系统统一使用网络连通性检测判断任务成功与否（详见 [任务编写指南](task-writing-guide.md)）。原有 `success_conditions` 字段仅保留兼容性，不再参与判断。

### 危险步骤检测

`eval` 步骤会被标记为危险步骤。后端保存时会记录警告日志（包含代码内容，截断至 2000 字符），前端会弹出安全确认对话框。此检测不会阻止保存，仅做提醒。

### Task ID 校验

正则：`^[A-Za-z][A-Za-z0-9_]*$`（必须以字母开头，只能包含字母、数字、下划线）。

---

## 任务文件管理

### 存储结构

```
tasks/
├── browser/              # 浏览器任务（JSON）
│   ├── default.json      # 内置默认任务
│   └── *.json            # 用户自定义任务
├── scripts/              # 脚本任务（JSON 或 .py）
│   └── *.json / *.py
└── scheduled/            # 定时任务（JSON）
    └── *.json
```

### TaskManager 操作

| 方法 | 说明 |
|------|------|
| `load_task(task_id)` | 加载指定任务，返回 `TaskConfig` 对象 |
| `save_task(task_id, config)` | 校验后保存任务 JSON（`ensure_ascii=False, indent=2`） |
| `list_tasks()` | 列出所有任务的 `{id, name, description}` |
| `get_active_task()` | 通过 API 获取当前活动任务 ID，不存在时返回 `"default"` |
| `set_active_task(task_id)` | 通过 `POST /api/tasks/active/{task_id}` 设置活动任务 |
| `delete_task(task_id)` | 删除任务文件，`"default"` 不可删除 |

### 安全措施

路径遍历防护：`_safe_task_path()` 解析路径后验证是否在 `tasks_dir` 范围内，防止 `../` 攻击。

---

## API 参考

详见 [api-doc.md](api-doc.md)。

---

## 环境变量参考

应用配置已统一迁移至 `config/settings.json`，通过 Web 控制台管理。以下仅列出仍在使用的环境变量：

| 变量 | 说明 |
|------|------|
| `CAMPUS_AUTH_PROJECT_ROOT` | 覆盖项目根目录路径 |
| `CAMPUS_AUTH_START_EXECUTABLE` | 覆盖自启动时的可执行文件路径 |
| `AUTO_INSTALL_PLAYWRIGHT` | 启用/禁用自动安装 Chromium |
| `PLAYWRIGHT_DOWNLOAD_HOST` | Playwright 下载镜像 URL |
| `APP_PORT` | 覆盖 Web 控制台端口 |
