# 修复 execute_login_async 死锁风险实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use subagent-driven-development (recommended) or executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 修复 `TaskExecutor.execute_login_async` 中的死锁风险，将 `add_done_callback` 移到锁外

**Architecture:** 将回调注册操作移到 `with self._login_lock:` 块外，避免在锁内注册回调导致的时序问题

**Tech Stack:** Python, threading, concurrent.futures

---

## 文件结构

### 修改文件
- `app/services/task_executor.py`：第 208-219 行，修改 `execute_login_async` 方法

---

### Task 1: 修复 execute_login_async 死锁风险

**Files:**
- Modify: `app/services/task_executor.py:208-219`

- [ ] **Step 1: 查看当前代码**

```bash
cat -n app/services/task_executor.py | sed -n '195,225p'
```

- [ ] **Step 2: 修改 execute_login_async 方法**

将第 208-219 行的代码：

```python
    def execute_login_async(
        self, cancel_event: threading.Event | None = None
    ) -> Future:
        """异步执行登录（提交到 login_pool），带去重。

        如果已有登录任务在执行中，返回已有的 Future 而非重复提交。

        Args:
            cancel_event: 取消事件，设置后登录流程应尽快退出

        Returns:
            Future 对象（新的或已有的）
        """
        with self._login_lock:
            # 检查是否已有登录在进行
            if self._login_future is not None and not self._login_future.done():
                # 去重：返回已有 Future，不设置调用方的 cancel_event
                logger.debug("登录任务已在执行中，跳过重复提交")
                return self._login_future

            # 提交新的登录任务
            future = self._login_pool.submit(self.execute_login, cancel_event)
            self._login_future = future
            future.add_done_callback(self._on_login_done)
            return future
```

修改为：

```python
    def execute_login_async(
        self, cancel_event: threading.Event | None = None
    ) -> Future:
        """异步执行登录（提交到 login_pool），带去重。

        如果已有登录任务在执行中，返回已有的 Future 而非重复提交。

        Args:
            cancel_event: 取消事件，设置后登录流程应尽快退出

        Returns:
            Future 对象（新的或已有的）
        """
        future = None
        with self._login_lock:
            # 检查是否已有登录在进行
            if self._login_future is not None and not self._login_future.done():
                # 去重：返回已有 Future，不设置调用方的 cancel_event
                logger.debug("登录任务已在执行中，跳过重复提交")
                return self._login_future

            # 提交新的登录任务
            future = self._login_pool.submit(self.execute_login, cancel_event)
            self._login_future = future

        # 锁外注册回调，避免时序问题
        future.add_done_callback(self._on_login_done)
        return future
```

- [ ] **Step 3: 运行现有测试确认无回归**

```bash
pytest tests/test_services/test_task_executor*.py -v
```

Expected: 所有测试通过

- [ ] **Step 4: 运行集成测试确认无回归**

```bash
pytest tests/test_integration/test_login_flow.py -v
```

Expected: 所有测试通过

- [ ] **Step 5: 提交修复**

```bash
git add app/services/task_executor.py
git commit -m "fix: 修复 execute_login_async 死锁风险，将回调注册移到锁外"
```

---

## 验证与收尾

### Task 2: 整体验证

- [ ] **Step 1: 运行完整测试套件**

```bash
pytest tests/ -q
```

Expected: 所有测试通过

- [ ] **Step 2: 检查覆盖率**

```bash
pytest tests/test_services/test_task_executor*.py --cov=app/services/task_executor --cov-report=term-missing
```

Expected: 覆盖率保持不变或提升

- [ ] **Step 3: 提交最终状态**

```bash
git add -A
git commit -m "fix: 完成死锁修复，所有测试通过"
```

---

**计划版本**：v1.0
**创建日期**：2026-06-15
**预计完成时间**：5 分钟
