# 后端死代码清理 实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 清理后端代码审查报告中验证属实的 ~40 处死代码，减少代码噪音、降低维护负担。

**Architecture:** 按文件/模块分组逐个清理，每组独立可提交。删除死代码后运行测试确认无回归。部分死函数在测试中有调用，需同步清理仅测试死代码的测试用例。

**Tech Stack:** Python, pytest, ruff

---

## 范围说明

**在范围内：** 经 grep 验证属实的死代码（整文件、死函数、死常量、未使用路由、冗余 import）。

**不在范围内（验证后排除）：**
- `ThreadPoolExecutor` 双层设计 — 验证确认是编排层 vs 探测层的合理分层，非冗余
- `application.py` 的 `import contextlib` — `contextlib.suppress()` 需要，非冗余
- `_safe_detect()` / `_handle_stop(cmd)` — 风格问题，非死代码
- `tasks/__init__.py` 冗余导出 — 低优先级，不影响运行时

---

## Task 1: 删除 `app/network/diagnostics.py` 整文件

**Files:**
- Delete: `app/network/diagnostics.py`
- Modify: `tests/test_core/test_network_probes.py:585-623`

- [ ] **Step 1: 删除 diagnostics.py**

```bash
rm app/network/diagnostics.py
```

- [ ] **Step 2: 删除测试中对 diagnostics 的引用**

`tests/test_core/test_network_probes.py` 中 `TestNetworkTestImports` 类（L588-623）整个删除，因为该类仅测试 diagnostics shim 的导出兼容性。

- [ ] **Step 3: 运行测试确认无回归**

```bash
uv run pytest tests/test_core/test_network_probes.py -v
```

- [ ] **Step 4: 运行全量测试确认**

```bash
uv run pytest --timeout=30
```

- [ ] **Step 5: 提交**

```bash
git add -A app/network/diagnostics.py tests/test_core/test_network_probes.py
git commit -m "refactor: 删除 diagnostics.py shim 文件及对应测试"
```

---

## Task 2: 清理 `app/api/__init__.py` 死代码

**Files:**
- Modify: `app/api/__init__.py`

- [ ] **Step 1: 清理 __init__.py**

将 `app/api/__init__.py` 清空为仅保留模块文档字符串。`logged_action()` 及其依赖的 `_api_logger`、`ActionResponse` 导入、`get_logger` 导入全部删除。

```python
"""路由包 — 按功能领域拆分的 API 路由模块。"""
```

- [ ] **Step 2: 确认无其他模块依赖**

确认 `app/application.py` 仅导入子模块（`from app.api import autostart, config, ...`），不使用 `logged_action`。

- [ ] **Step 3: 运行测试**

```bash
uv run pytest tests/ -v --timeout=30
```

- [ ] **Step 4: 提交**

```bash
git add app/api/__init__.py
git commit -m "refactor: 清理 api/__init__.py 中未使用的 logged_action 装饰器"
```

---

## Task 3: 清理 `app/constants.py` 零引用常量

**Files:**
- Modify: `app/constants.py:33,42,43,46`

- [ ] **Step 1: 删除 4 个零引用常量**

删除以下行：
- L33: `MONITOR_THREAD_JOIN_TIMEOUT = 8`
- L42: `DEBUG_LOG_MAXLEN = 1000`
- L43: `CMD_QUEUE_MAXSIZE = 50`
- L46: `DEFAULT_APP_PORT = 50721`

注意：保留注释行 `# ── 容量常量 ──` 和 `# ── 默认端口 ──` 的上下文，如果删除后空行过多则清理。

- [ ] **Step 2: 运行测试**

```bash
uv run pytest tests/ -v --timeout=30
```

- [ ] **Step 3: 提交**

```bash
git add app/constants.py
git commit -m "refactor: 删除 constants.py 中 4 个零引用常量"
```

---

## Task 4: 清理 `app/services/monitor_service.py` 死代码

**Files:**
- Modify: `app/services/monitor_service.py`
- Modify: `tests/test_core/test_monitor.py`（删除仅测试死函数的用例）

- [ ] **Step 1: 删除 `NETWORK_CHECK_TIMEOUT_SECONDS`（L40）**

删除 `NETWORK_CHECK_TIMEOUT_SECONDS = 2` 这一行。

- [ ] **Step 2: 删除 `update_status_after_login()`（L290-304）**

删除整个方法。

- [ ] **Step 3: 删除 `_close_browser_if_needed()`（L310-322）**

删除整个方法。

- [ ] **Step 4: 处理 `_get_retry_config()`（L324-336）**

该方法在生产代码中无调用（`engine.py` 有自己的同名方法），仅在测试中被调用。删除方法，并删除 `tests/test_core/test_monitor.py` 中调用它的测试用例。

搜索 `tests/test_core/test_monitor.py` 中包含 `_get_retry_config` 的测试函数，整个函数删除。

- [ ] **Step 5: 修复 `_check_profile_switch()` 误导注释（L395-397）**

将：
```python
                else:
                    # 方案切换成功，设置标志位并停止监控循环
                    pass
```
改为：
```python
                else:
                    # 方案切换成功（日志已在上方输出）
```

- [ ] **Step 6: 运行测试**

```bash
uv run pytest tests/test_core/test_monitor.py -v
uv run pytest tests/ -v --timeout=30
```

- [ ] **Step 7: 提交**

```bash
git add app/services/monitor_service.py tests/test_core/test_monitor.py
git commit -m "refactor: 清理 monitor_service.py 中 4 处死代码和误导注释"
```

---

## Task 5: 清理 `app/services/engine.py` 死代码

**Files:**
- Modify: `app/services/engine.py:38,539`

- [ ] **Step 1: 删除 `MONITOR_STOP_TIMEOUT_S` 别名（L38）**

删除 `MONITOR_STOP_TIMEOUT_S = MONITOR_STOP_TIMEOUT` 这一行。保留上方的 `MONITOR_STOP_TIMEOUT` 导入（L20）。

- [ ] **Step 2: 将循环内 `import json` 移到模块顶部（L539）**

在文件顶部的 import 区域添加 `import json`，然后将 L539 的 `import json as _json` 改为直接使用 `json.dumps()`。

顶部 import 区域（在 `import re` 之后）添加：
```python
import json
```

`drain_ws_queue` 方法中将：
```python
                import json as _json

                await self._ws_manager.broadcast(_json.dumps(data))
```
改为：
```python
                await self._ws_manager.broadcast(json.dumps(data))
```

- [ ] **Step 3: 运行测试**

```bash
uv run pytest tests/ -v --timeout=30
```

- [ ] **Step 4: 提交**

```bash
git add app/services/engine.py
git commit -m "refactor: engine.py 移除死常量、将循环内 import 移至模块顶部"
```

---

## Task 6: 清理 `app/services/` 其他死代码

**Files:**
- Modify: `app/services/profile_service.py:34-35`
- Modify: `app/services/runtime_config.py:17-29`
- Modify: `app/services/task_registry.py:206-216`

- [ ] **Step 1: 删除 `profile_service.py` 的 `invalidate_cache()`**

删除 `invalidate_cache()` 方法。该方法仅在测试中使用，删除后需同步删除 `tests/test_app/test_backend_services.py` 中调用它的测试。

- [ ] **Step 2: 删除 `runtime_config.py` 的 `_PROTECTED_KEYS`**

删除 `_PROTECTED_KEYS = frozenset({...})` 整个定义（L17-29）。

- [ ] **Step 3: 删除 `task_registry.py` 的 `_update_index()`**

删除 `_update_index()` 方法（L206-216）。

- [ ] **Step 4: 运行测试**

```bash
uv run pytest tests/ -v --timeout=30
```

- [ ] **Step 5: 提交**

```bash
git add app/services/profile_service.py app/services/runtime_config.py app/services/task_registry.py
git commit -m "refactor: 清理 services 层 3 处死代码"
```

---

## Task 7: 清理 `app/utils/` 死代码

**Files:**
- Modify: `app/utils/config_utils.py:101-124`
- Modify: `app/utils/logging.py:48`
- Modify: `app/utils/repo_proxy.py:46-91`
- Modify: `app/utils/crypto.py` — 不删除 `is_encrypted()`（仅测试使用但函数本身有用）

- [ ] **Step 1: 删除 `config_utils.py` 的 `validate_profile_fields()`**

删除整个函数（L101-124）。无任何调用方。

- [ ] **Step 2: 删除 `logging.py` 的 `_WEBSOCKET_FORMAT`**

删除 L48 的 `_WEBSOCKET_FORMAT` 定义。

- [ ] **Step 3: 删除 `repo_proxy.py` 同步版函数**

删除以下函数：
- `repo_get()`（L46-53）
- `repo_fetch_json()`（L66-91）

仅保留异步版 `async_repo_get()` 和 `async_repo_fetch_json()`。同步版仅在测试中使用。

同步删除 `tests/test_services/test_repo_proxy.py` 中测试同步版函数的用例。

- [ ] **Step 4: 关于 `crypto.py` 的 `is_encrypted()`**

**保留不删除。** 虽然生产代码内联了 `startswith("ENC:")`，但 `is_encrypted()` 是一个有意义的工具函数，测试验证了其行为。如果要清理，更合理的做法是让生产代码改用 `is_encrypted()` 而非删除它。此处跳过。

- [ ] **Step 5: 运行测试**

```bash
uv run pytest tests/ -v --timeout=30
```

- [ ] **Step 6: 提交**

```bash
git add app/utils/config_utils.py app/utils/logging.py app/utils/repo_proxy.py
git commit -m "refactor: 清理 utils 层 3 处死代码（config_utils, logging, repo_proxy）"
```

---

## Task 8: 清理 `app/tasks/` 死代码

**Files:**
- Modify: `app/tasks/models.py:17`
- Modify: `app/tasks/__init__.py:11,40`
- Modify: `app/tasks/browser_runner.py:293-312`

- [ ] **Step 1: 删除 `models.py` 的重复 `PROJECT_ROOT`**

删除 `app/tasks/models.py` L17 的 `PROJECT_ROOT = Path(__file__).resolve().parents[2]`。

- [ ] **Step 2: 更新 `__init__.py` 移除 PROJECT_ROOT 导出**

从 `__init__.py` 的 import 和 `__all__` 中移除 `PROJECT_ROOT`。

从 L11 删除 `PROJECT_ROOT,`，从 `__all__` 中删除 `"PROJECT_ROOT",`。

- [ ] **Step 3: 删除 `browser_runner.py` 的 `execute_remaining()`**

删除 `execute_remaining()` 方法（L293-312）。

- [ ] **Step 4: 运行测试**

```bash
uv run pytest tests/ -v --timeout=30
```

- [ ] **Step 5: 提交**

```bash
git add app/tasks/models.py app/tasks/__init__.py app/tasks/browser_runner.py
git commit -m "refactor: 清理 tasks 层死代码（重复 PROJECT_ROOT, execute_remaining）"
```

---

## Task 9: 清理 `app/network/decision.py` 死函数

**Files:**
- Modify: `app/network/decision.py:308-320`

- [ ] **Step 1: 删除 `check_campus_network_status()`**

删除该函数（L308-320）。注释说"供 API 调用"但无任何 endpoint 使用。

- [ ] **Step 2: 运行测试**

```bash
uv run pytest tests/test_core/test_network_probes.py -v
```

- [ ] **Step 3: 提交**

```bash
git add app/network/decision.py
git commit -m "refactor: 删除 decision.py 中未使用的 check_campus_network_status"
```

---

## Task 10: 清理 `app/workers/playwright_bootstrap.py` 死函数

**Files:**
- Modify: `app/workers/playwright_bootstrap.py:176-183`
- Modify: `tests/test_utils/test_src_utils.py:1075-1089`

- [ ] **Step 1: 删除两个死函数**

删除 `is_bootstrap_skipped()`（L176-178）和 `is_bootstrap_done()`（L181-183）。

- [ ] **Step 2: 删除对应测试**

删除 `tests/test_utils/test_src_utils.py` 中 `test_is_bootstrap_skipped` 和 `test_is_bootstrap_done` 两个测试方法。

- [ ] **Step 3: 运行测试**

```bash
uv run pytest tests/test_utils/test_src_utils.py -v
```

- [ ] **Step 4: 提交**

```bash
git add app/workers/playwright_bootstrap.py tests/test_utils/test_src_utils.py
git commit -m "refactor: 删除 playwright_bootstrap 中两个零引用查询函数及对应测试"
```

---

## Task 11: 清理 `app/container.py` 死代码

**Files:**
- Modify: `app/container.py:14,29`

- [ ] **Step 1: 移除 `NullTaskExecutor` 导入**

将 L14 的：
```python
from app.services.task_executor import NullTaskExecutor, TaskExecutor
```
改为：
```python
from app.services.task_executor import TaskExecutor
```

- [ ] **Step 2: 删除 `self._logs_dir` 赋值**

删除 L29 的 `self._logs_dir = project_root / "logs"`。

- [ ] **Step 3: 运行测试**

```bash
uv run pytest tests/ -v --timeout=30
```

- [ ] **Step 4: 提交**

```bash
git add app/container.py
git commit -m "refactor: 移除 container.py 中未使用的 NullTaskExecutor 导入和 _logs_dir 属性"
```

---

## Task 12: 清理 `app/schemas.py` 重复 import

**Files:**
- Modify: `app/schemas.py:280`

- [ ] **Step 1: 删除方法内重复的 `import re`**

`app/schemas.py` L4 已有模块级 `import re`，L280 在 `validate_custom_variables` 方法内重复导入。删除 L280 的 `import re`。

- [ ] **Step 2: 运行测试**

```bash
uv run pytest tests/ -v --timeout=30
```

- [ ] **Step 3: 提交**

```bash
git add app/schemas.py
git commit -m "refactor: 删除 schemas.py 方法内重复的 import re"
```

---

## Task 13: 删除未使用的 API 路由

**Files:**
- Modify: `app/api/config.py:57-67`
- Modify: `app/api/debug.py:44-48`
- Modify: `app/api/profiles.py:51-61`
- Modify: `app/api/scheduled_tasks.py:115-124`

- [ ] **Step 1: 删除 `DELETE /api/config/source-level/{source}` 路由**

删除 `app/api/config.py` 中对应的路由处理函数。

- [ ] **Step 2: 删除 `GET /api/debug/status` 路由**

删除 `app/api/debug.py` 中对应的路由处理函数。

- [ ] **Step 3: 删除 `GET /api/profiles/active` 路由**

删除 `app/api/profiles.py` 中对应的路由处理函数。注意：`POST /api/profiles/active/{profile_id}` 保留。

- [ ] **Step 4: 删除 `GET /api/scheduled-tasks/{task_id}` 路由**

删除 `app/api/scheduled_tasks.py` 中对应的路由处理函数。

- [ ] **Step 5: 运行测试**

```bash
uv run pytest tests/ -v --timeout=30
```

- [ ] **Step 6: 提交**

```bash
git add app/api/config.py app/api/debug.py app/api/profiles.py app/api/scheduled_tasks.py
git commit -m "refactor: 删除 4 个前端未调用的 API 路由"
```

---

## Task 14: 最终验证

- [ ] **Step 1: 运行 ruff 检查**

```bash
uv run ruff check .
uv run ruff format --check .
```

- [ ] **Step 2: 运行全量测试**

```bash
uv run pytest --timeout=30 -v
```

- [ ] **Step 3: 确认无遗留问题**

检查是否有因删除代码而产生的未使用 import（ruff 会报 F401）。

---

## 附：不修改的项目（验证后排除）

| 项目 | 原因 |
|------|------|
| `application.py` `import contextlib` | `contextlib.suppress()` 需要此导入，非冗余 |
| `_decision_executor` vs `probes.executor` | 编排层 vs 探测层的分层设计，非重复 |
| `_safe_detect()` | 风格问题，非死代码 |
| `_handle_stop(cmd)` 参数 | 风格问题，非死代码 |
| `tasks/__init__.py` 冗余导出 | 低优先级，不影响运行时 |
| `crypto.py` `is_encrypted()` | 有意义的工具函数，应保留 |
| `system_tray.py` `update_status()` | 功能已实现，仅需接入（非删除） |
