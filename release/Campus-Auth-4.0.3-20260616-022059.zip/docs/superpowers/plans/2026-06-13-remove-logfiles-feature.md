# 删除日志文件查看器功能 实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 删除日志文件查看器（logfiles）功能的全部前后端代码

**Architecture:** 删除 4 个前端文件 + 1 个后端文件 + 1 个测试文件，清理 6 个文件中的引用。日志文件本身不受影响（`LOGS_DIR` 保留，loguru 仍在写入）。

**Tech Stack:** Vue 3 (UMD)、FastAPI、pytest

---

## 文件变更总览

| 操作 | 文件 |
|------|------|
| 删除 | `frontend/partials/pages/logfiles.html` |
| 删除 | `frontend/styles/pages/logfiles.css` |
| 删除 | `frontend/js/data/logfiles.js` |
| 删除 | `frontend/js/methods/logfiles.js` |
| 删除 | `app/api/logfiles.py` |
| 删除 | `tests/test_api/test_api_logfiles_routes.py` |
| 删除 | `docs/2026-06-13-log-restructure-design.md` |
| 删除 | `docs/2026-06-13-log-restructure-plan.md` |
| 修改 | `frontend/index.html`（移除 CSS 和 HTML 引用） |
| 修改 | `frontend/partials/sidebar.html`（移除导航链接） |
| 修改 | `frontend/js/app-options.js`（移除 import、data、computed、watch、methods） |
| 修改 | `frontend/js/components.js`（移除 logfiles prop） |
| 修改 | `frontend/styles/components.css`（移除 .custom-select.logfiles 样式） |
| 修改 | `frontend/js/constants.js`（移除 LOG_FILE_FETCH_LIMIT） |
| 修改 | `app/application.py`（移除 router 注册） |
| 修改 | `docs/api-doc.md`（移除 logfiles API 文档） |

保留的常量（dashboard 日志仍在使用）：
- `LOG_LEVELS` — dashboard 日志级别筛选
- `LOG_SOURCES` — dashboard 日志来源筛选
- `LOGS_DIR` — loguru 文件轮转需要

---

### Task 1: 删除前端文件

**Files:**
- Delete: `frontend/partials/pages/logfiles.html`
- Delete: `frontend/styles/pages/logfiles.css`
- Delete: `frontend/js/data/logfiles.js`
- Delete: `frontend/js/methods/logfiles.js`

- [ ] **Step 1: 删除 4 个前端文件**

```bash
rm frontend/partials/pages/logfiles.html
rm frontend/styles/pages/logfiles.css
rm frontend/js/data/logfiles.js
rm frontend/js/methods/logfiles.js
```

- [ ] **Step 2: 提交**

```bash
git add -A frontend/partials/pages/logfiles.html frontend/styles/pages/logfiles.css frontend/js/data/logfiles.js frontend/js/methods/logfiles.js
git commit -m "chore: 删除日志文件查看器前端文件"
```

---

### Task 2: 清理 index.html 和 sidebar.html

**Files:**
- Modify: `frontend/index.html`
- Modify: `frontend/partials/sidebar.html`

- [ ] **Step 1: 从 index.html 移除 CSS 和 HTML 引用**

删除以下两行：
```html
<link rel="stylesheet" href="/static/styles/pages/logfiles.css" />
```
```html
<div data-include="/static/partials/pages/logfiles.html"></div>
```

- [ ] **Step 2: 从 sidebar.html 移除导航链接**

删除"日志"按钮（在"更多"菜单内）：
```html
<button class="nav-item" :class="{ active: currentPage === 'logs' }" @click="currentPage = 'logs'">
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="nav-icon">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
    <polyline points="14 2 14 8 20 8"/>
    <line x1="16" y1="13" x2="8" y2="13"/>
    <line x1="16" y1="17" x2="8" y2="17"/>
    <polyline points="10 9 9 9 8 9"/>
  </svg>
  <span>日志</span>
</button>
```

同时检查 sidebar 中 `showMoreNav` 的 active 判断是否引用了 `'logs'`，如有则移除。

- [ ] **Step 3: 提交**

```bash
git add frontend/index.html frontend/partials/sidebar.html
git commit -m "chore: 从 index.html 和 sidebar 移除日志查看器引用"
```

---

### Task 3: 清理 app-options.js

**Files:**
- Modify: `frontend/js/app-options.js`

- [ ] **Step 1: 移除 import**

删除：
```javascript
import { logFileMethods } from './methods/logfiles.js';
```
```javascript
import { logFileData } from './data/logfiles.js';
```

- [ ] **Step 2: 从 data() 移除 logFileData**

删除：
```javascript
...logFileData(),
```

- [ ] **Step 3: 移除 computed 属性**

删除 `logFileOptions` computed：
```javascript
logFileOptions() {
  return this.currentLogFiles.map(f => ({
    value: f.name,
    label: f.name + ' (' + this.formatFileSize(f.size) + ')',
  }));
},
```

删除 `currentLogFiles` computed：
```javascript
currentLogFiles() {
  const group = this.logFileGroups.find(g => g.date === this.logViewer.date);
  return group?.files || [];
},
```

- [ ] **Step 4: 从 pageTitle 移除 'logs'**

删除：
```javascript
logs: '日志查看器',
```

- [ ] **Step 5: 从 currentPage watch 移除 logfiles 逻辑**

删除：
```javascript
if (newPage === 'logs' && !this.logFileGroups.length) {
  this.fetchLogFileGroups();
}
```

- [ ] **Step 6: 从 methods 移除 logFileMethods**

删除：
```javascript
...logFileMethods,
```

- [ ] **Step 7: 提交**

```bash
git add frontend/js/app-options.js
git commit -m "chore: 从 app-options.js 移除日志查看器相关代码"
```

---

### Task 4: 清理 components.js 和 components.css

**Files:**
- Modify: `frontend/js/components.js`
- Modify: `frontend/styles/components.css`

- [ ] **Step 1: 从 CustomSelect 移除 logfiles prop**

删除 prop 声明：
```javascript
logfiles: { type: Boolean, default: false },
```

从模板中移除 `logfiles` class 绑定：
```html
<!-- 修改前 -->
<div class="custom-select" :class="{ open, compact, logfiles, disabled }">
<!-- 修改后 -->
<div class="custom-select" :class="{ open, compact, disabled }">
```

- [ ] **Step 2: 从 components.css 移除 logfiles 样式**

删除 `.custom-select.logfiles` 相关样式块：
```css
/* 日志文件场景的样式 */
.custom-select.logfiles .custom-select-trigger { ... }
.custom-select.logfiles .custom-select-arrow { ... }
```

- [ ] **Step 3: 提交**

```bash
git add frontend/js/components.js frontend/styles/components.css
git commit -m "chore: 从 CustomSelect 移除 logfiles prop 和样式"
```

---

### Task 5: 清理 constants.js

**Files:**
- Modify: `frontend/js/constants.js`

- [ ] **Step 1: 移除 LOG_FILE_FETCH_LIMIT**

从 `LIMITS` 对象中删除：
```javascript
LOG_FILE_FETCH_LIMIT: 2000,    // 日志文件内容获取条数
```

保留 `LOG_LEVELS` 和 `LOG_SOURCES`（dashboard 日志仍在使用）。

- [ ] **Step 2: 提交**

```bash
git add frontend/js/constants.js
git commit -m "chore: 移除 LOG_FILE_FETCH_LIMIT 常量"
```

---

### Task 6: 删除后端文件和测试

**Files:**
- Delete: `app/api/logfiles.py`
- Delete: `tests/test_api/test_api_logfiles_routes.py`

- [ ] **Step 1: 删除文件**

```bash
rm app/api/logfiles.py
rm tests/test_api/test_api_logfiles_routes.py
```

- [ ] **Step 2: 从 application.py 移除 router 注册**

删除 import：
```python
from app.api import ... logfiles ...
```

删除 router 注册：
```python
_app.include_router(logfiles.router)
```

- [ ] **Step 3: 运行测试确认无破坏**

```bash
uv run pytest tests/ -x --ignore=tests/test_api/test_api_logfiles_routes.py -q
```

预期：全部通过（logfiles 测试已删除，其余测试不依赖 logfiles）。

- [ ] **Step 4: 提交**

```bash
git add -A app/api/logfiles.py app/application.py tests/test_api/test_api_logfiles_routes.py
git commit -m "chore: 删除日志文件查看器后端 API、路由注册和测试"
```

---

### Task 7: 清理文档

**Files:**
- Delete: `docs/2026-06-13-log-restructure-design.md`
- Delete: `docs/2026-06-13-log-restructure-plan.md`
- Modify: `docs/api-doc.md`
- Modify: `README.md`（如有 logfiles 引用）

- [ ] **Step 1: 删除过期的设计文档**

```bash
rm docs/2026-06-13-log-restructure-design.md
rm docs/2026-06-13-log-restructure-plan.md
```

- [ ] **Step 2: 从 api-doc.md 移除 logfiles API 文档**

删除 `GET /api/logfiles/list` 和 `GET /api/logfiles/content` 的文档段落。

- [ ] **Step 3: 检查 README.md**

搜索 `logfiles` 引用，如有则从项目结构树中移除。

- [ ] **Step 4: 提交**

```bash
git add -A docs/ README.md
git commit -m "chore: 清理日志查看器相关文档"
```

---

### Task 8: 更新修改日志

**Files:**
- Modify: `dev/change.md`

- [ ] **Step 1: 在 change.md 顶部添加记录**

```markdown
### refactor: 删除日志文件查看器功能

删除前端日志文件查看器（logfiles）的全部代码，包括：
- 前端：HTML 模板、CSS 样式、JS 数据/方法模块、侧边栏导航、路由引用
- 后端：API 路由（/api/logfiles/list、/api/logfiles/content）、路由注册
- 测试：37 个测试用例
- 文档：过期的设计文档和 API 文档

保留的共享资源（dashboard 日志仍在使用）：LOG_LEVELS、LOG_SOURCES 常量
日志文件本身不受影响：LOGS_DIR 保留，loguru 仍在写入日志文件
```

- [ ] **Step 2: 提交**

```bash
git add dev/change.md
git commit -m "docs: 记录日志查看器功能删除"
```
