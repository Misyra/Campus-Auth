# 轻量模式托盘支持 + 自启动独立卡片 实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use subagent-driven-development (recommended) or executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 为轻量模式添加独立的托盘开关，支持点击"打开控制台"按需唤醒 WebUI，并将自启动设置独立为醒目的卡片。

**Architecture:** 新增 `lightweight_tray` 配置字段控制轻量模式托盘；修改 `SystemTray` 支持自定义"打开控制台"回调；轻量模式下点击托盘时在子线程启动 FastAPI+Uvicorn；前端自启动部分提取为独立卡片。

**Tech Stack:** Python, FastAPI, Uvicorn, pystray, Vue.js

---

## 文件结构

| 文件 | 操作 | 说明 |
|------|------|------|
| `app/schemas.py` | 修改 | 新增 `lightweight_tray` 字段，修改 `get_runtime_features()` |
| `app/ui/system_tray.py` | 修改 | 新增 `on_open_console` 回调参数 |
| `main.py` | 修改 | `_run_lightweight()` 支持按需启动 Web 服务 |
| `frontend/partials/pages/settings/settings-system.html` | 修改 | 自启动独立为卡片，新增轻量模式托盘开关 |
| `frontend/js/constants.js` | 修改 | `DEFAULT_CONFIG` 新增 `lightweight_tray` |

---

### Task 1: 后端 — 新增 `lightweight_tray` 配置字段

**Files:**
- Modify: `app/schemas.py:204-217`

- [ ] **Step 1: 在 GlobalSettings 中新增字段**

在 `app/schemas.py` 的 `GlobalSettings` 类中，`autostart_lightweight` 字段后新增：

```python
autostart_lightweight: bool = Field(default=True)
lightweight_tray: bool = Field(default=True, description="轻量模式显示系统托盘")
```

- [ ] **Step 2: 修改 AppConfig dataclass**

在 `app/schemas.py:56-62` 的 `AppConfig` 中新增字段：

```python
@dataclass
class AppConfig:
    config_version: int = 2
    startup_action: StartupAction = StartupAction.NONE
    runtime_mode: RuntimeMode = RuntimeMode.FULL
    minimize_to_tray: bool = True
    lightweight_tray: bool = True
    auto_open_browser: bool = False
```

- [ ] **Step 3: 修改 get_runtime_features() 函数**

修改 `app/schemas.py:411-425` 的 `get_runtime_features()`：

```python
def get_runtime_features(
    mode: RuntimeMode | str, minimize_to_tray: bool, auto_open_browser: bool,
    lightweight_tray: bool = True
) -> RuntimeFeatures:
    """根据运行模式派生特性标志"""
    if mode == RuntimeMode.LIGHTWEIGHT:
        return RuntimeFeatures(
            web_enabled=False,
            browser_enabled=False,
            tray_enabled=lightweight_tray,
        )
    return RuntimeFeatures(
        web_enabled=True,
        browser_enabled=auto_open_browser,
        tray_enabled=minimize_to_tray,
    )
```

- [ ] **Step 4: 运行测试验证**

Run: `cd E:/Campus-Auth && python -m pytest tests/test_schemas.py -v`
Expected: PASS（如有相关测试）

- [ ] **Step 5: Commit**

```bash
git add app/schemas.py
git commit -m "feat: 新增 lightweight_tray 配置字段"
```

---

### Task 2: 后端 — 修改 SystemTray 支持自定义回调

**Files:**
- Modify: `app/ui/system_tray.py:10-19`

- [ ] **Step 1: 修改 SystemTray 构造函数**

修改 `app/ui/system_tray.py` 的 `SystemTray.__init__()`：

```python
class SystemTray:
    def __init__(self, port: int = 50721, on_exit=None, on_open_console=None):
        self.port = port
        self.on_exit = on_exit
        self.on_open_console = on_open_console
        self.icon = None
        self._thread = None
        self._monitoring = False
        self._pystray = None
        self._Image = None
```

- [ ] **Step 2: 修改 _create_menu() 使用回调**

修改 `app/ui/system_tray.py:48-66` 的 `_create_menu()`：

```python
def _create_menu(self):
    """创建托盘菜单（需要先调用 start() 初始化模块）。"""
    def _open_console(icon, item):
        if self.on_open_console:
            self.on_open_console()
        else:
            webbrowser.open(f"http://127.0.0.1:{self.port}")

    return self._pystray.Menu(
        self._pystray.MenuItem(
            "打开控制台",
            _open_console,
            default=True,
        ),
        self._pystray.MenuItem(
            self._get_status_label,
            lambda: None,
            enabled=False,
        ),
        self._pystray.Menu.SEPARATOR,
        self._pystray.MenuItem(
            "退出",
            self._quit,
        ),
    )
```

- [ ] **Step 3: Commit**

```bash
git add app/ui/system_tray.py
git commit -m "feat: SystemTray 支持 on_open_console 回调"
```

---

### Task 3: 后端 — 修改 _build_app_config() 读取新配置

**Files:**
- Modify: `main.py:245-286`

- [ ] **Step 1: 修改 _build_app_config() 读取 lightweight_tray**

修改 `main.py` 的 `_build_app_config()` 函数，在读取 `minimize_to_tray` 后新增：

```python
config.minimize_to_tray = bool(getattr(_sys, "minimize_to_tray", True))
config.lightweight_tray = bool(getattr(_sys, "lightweight_tray", True))
```

- [ ] **Step 2: Commit**

```bash
git add main.py
git commit -m "feat: _build_app_config 读取 lightweight_tray"
```

---

### Task 4: 后端 — 修改 _run_lightweight() 支持按需启动 Web 服务

**Files:**
- Modify: `main.py:342-388`

- [ ] **Step 1: 重写 _run_lightweight() 函数**

替换 `main.py:342-388` 的 `_run_lightweight()`：

```python
def _run_lightweight(ctx: ApplicationContext, logger):
    """轻量模式：始终启动监控 + 定时任务，可选托盘，支持按需唤醒 WebUI。"""
    from app.container import ServiceContainer
    from app.utils.ports import resolve_port

    container = ServiceContainer(
        Path(__file__).parent.resolve(), mode="lightweight"
    )
    container.engine.boot()
    if container.engine.has_enabled_tasks():
        container.engine.start_scheduler()
    logger.info("轻量模式启动: 仅监控 + 定时任务，按 Ctrl+C 停止")

    # Web 服务状态
    _web_server_state = {"started": False, "server_ref": [None]}

    def _start_web_server():
        """按需启动 Web 服务（在子线程中运行）。"""
        if _web_server_state["started"]:
            return
        _web_server_state["started"] = True

        def _worker():
            try:
                from app.application import run
                run(
                    existing_container=container,
                    server_ref=_web_server_state["server_ref"],
                )
            except Exception as e:
                logger.error("Web 服务启动失败: {}", e)
                _web_server_state["started"] = False

        threading.Thread(target=_worker, daemon=True).start()

    def _open_console():
        """托盘回调：启动 Web 服务并打开浏览器。"""
        port = resolve_port()
        _start_web_server()
        # 等待服务就绪
        for _ in range(30):
            if is_local_port_in_use(port):
                break
            time.sleep(0.5)
        webbrowser.open(f"http://127.0.0.1:{port}")

    # 系统托盘（可选）
    features = get_runtime_features(
        RuntimeMode.LIGHTWEIGHT,
        ctx.config.minimize_to_tray,
        ctx.config.auto_open_browser,
        ctx.config.lightweight_tray,
    )
    tray_icon = None
    if features.tray_enabled:
        try:
            from app.ui.system_tray import SystemTray

            port = resolve_port()
            tray_icon = SystemTray(
                port=port,
                on_exit=lambda: (
                    os.kill(os.getpid(), signal.SIGTERM) if hasattr(signal, "SIGTERM") else os._exit(0)
                ),
                on_open_console=_open_console,
            )
            tray_icon.start()
            logger.info("系统托盘已启动")
        except Exception as e:
            logger.warning("启动系统托盘失败: {}", e)

    try:
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        logger.info("收到退出信号，正在关闭服务...")
    finally:
        if tray_icon:
            tray_icon.stop()
        loop = asyncio.new_event_loop()
        loop.run_until_complete(container.shutdown())
        loop.close()
```

- [ ] **Step 2: Commit**

```bash
git add main.py
git commit -m "feat: 轻量模式支持按需唤醒 WebUI"
```

---

### Task 5: 前端 — 新增 lightweight_tray 默认配置

**Files:**
- Modify: `frontend/js/constants.js`

- [ ] **Step 1: 在 DEFAULT_CONFIG 中新增字段**

在 `frontend/js/constants.js` 的 `DEFAULT_CONFIG` 对象中新增：

```javascript
lightweight_tray: true,
```

- [ ] **Step 2: Commit**

```bash
git add frontend/js/constants.js
git commit -m "feat: 前端 DEFAULT_CONFIG 新增 lightweight_tray"
```

---

### Task 6: 前端 — 自启动独立卡片 + 轻量模式托盘开关

**Files:**
- Modify: `frontend/partials/pages/settings/settings-system.html`

- [ ] **Step 1: 重构 settings-system.html**

将自启动部分从"系统策略"面板中提取出来，作为独立卡片。在 `</div>` 结束标签（第 108 行）后、第二个 `<section>` 前插入新卡片：

替换整个文件内容为：

```html
<div v-if="currentSettingsTab === 'system'" class="settings-panel-grid">
  <section class="card settings-panel">
    <div class="card-header">
      <h2>系统策略</h2>
    </div>
    <div class="card-body">
      <h4 class="settings-section-heading">日志管理</h4>
      <div class="form-row">
        <div class="form-group">
          <div class="field-label-row">
            <label for="settings-log-retention">日志保留天数</label>
            <span class="field-help" tabindex="0" role="note" data-tip="日志和失败截图按天归档，超过设定天数的整日归档（含日志和截图）会自动清理。设为 7 可平衡排查需求与磁盘占用。">?</span>
          </div>
          <input id="settings-log-retention" v-model.number="config.log_retention_days" type="number" min="1" max="365" />
        </div>
      </div>
      <div class="toggle-group">
        <div class="toggle-with-help">
          <label class="toggle toggle-help-inline">
            <input type="checkbox" v-model="config.access_log" />
            <span class="toggle-slider"></span>
            <span class="toggle-label">显示 HTTP 请求日志</span>
            <span class="field-help" tabindex="0" role="note" data-tip="开启后会记录每次 API 请求的方法、路径和耗时。调试时有用，日常使用建议关闭以减少日志量。">?</span>
          </label>
        </div>
      </div>

      <div class="settings-section-divider"></div>
      <h4 class="settings-section-heading">日志级别</h4>
      <div class="form-group">
        <div class="field-label-row">
          <label>全局日志级别</label>
          <span class="field-help" tabindex="0" role="note" data-tip="设置所有日志来源的默认级别。低于该级别的日志将被过滤。">?</span>
        </div>
        <custom-select
          v-model="logLevels.global_level"
          :options="logLevelOptions"
          @change="(val) => setSourceLevel('global', val)"
        ></custom-select>
      </div>

      <div class="settings-section-divider"></div>
      <h4 class="settings-section-heading">启动行为</h4>
      <div class="form-group">
        <div class="field-label-row">
          <label for="settings-startup-action">启动后执行</label>
          <span class="field-help" tabindex="0" role="note" data-tip="选择程序启动后自动执行的操作。">?</span>
        </div>
        <custom-select
          id="settings-startup-action"
          v-model="config.startup_action"
          :options="loginActionOptions"
        ></custom-select>
        <span class="hint">{{ startupActionHint }}</span>
      </div>

      <div class="settings-section-divider"></div>
      <h4 class="settings-section-heading">界面行为</h4>
      <div class="toggle-group">
        <div class="toggle-with-help">
          <label class="toggle toggle-help-inline">
            <input type="checkbox" v-model="config.minimize_to_tray" :disabled="config.startup_action === 'login_once'" />
            <span class="toggle-slider"></span>
            <span class="toggle-label">最小化到系统托盘</span>
            <span class="field-help" tabindex="0" role="note" data-tip="关闭窗口时最小化到系统托盘，可通过托盘图标重新打开界面。关闭此选项后关闭窗口程序仍在后台运行，但只能手动输入地址访问。">?</span>
          </label>
        </div>
      </div>
      <div class="toggle-group">
        <div class="toggle-with-help">
          <label class="toggle toggle-help-inline">
            <input type="checkbox" :checked="!config.auto_open_browser" @change="config.auto_open_browser = !$event.target.checked" />
            <span class="toggle-slider"></span>
            <span class="toggle-label">静默启动</span>
            <span
              class="field-help"
              tabindex="0"
              role="note"
              data-tip="开启后启动软件时不自动打开网页界面。如果你希望开机后后台静默运行，建议开启。"
            >?</span>
          </label>
        </div>
      </div>
    </div>
  </section>

  <section class="card settings-panel settings-panel--accent">
    <div class="card-header">
      <h2>开机自启动</h2>
    </div>
    <div class="card-body">
      <div class="toggle-group">
        <div class="toggle-with-help">
          <label class="toggle toggle-help-inline">
            <input type="checkbox" :checked="autostart.enabled" @change="autostart.enabled ? disableAutostart() : enableAutostart()" :disabled="busy.autostart" />
            <span class="toggle-slider"></span>
            <span class="toggle-label">开机自启动</span>
            <span v-if="autostart.method !== '-'" class="autostart-method-badge">{{ autostart.method }}</span>
            <span class="field-help" tabindex="0" role="note" data-tip="开机时自动启动 Campus-Auth。配合「启动后开始监控」可持续监控网络，或配合「自动登录，成功后退出」实现开机自动认证。">?</span>
          </label>
        </div>
      </div>
      <div class="form-group" v-if="autostart.enabled">
        <div class="field-label-row">
          <label>自启动模式</label>
          <span class="field-help" tabindex="0" role="note" data-tip="轻量模式仅后台监控，不启动 Web 界面；完整模式启动 Web 管理界面。">?</span>
        </div>
        <custom-select
          v-model="autostart.lightweight"
          :options="autostartModeOptions"
          @change="setAutostartMode"
        ></custom-select>
      </div>

      <div class="settings-section-divider"></div>
      <h4 class="settings-section-heading">轻量模式托盘</h4>
      <div class="toggle-group">
        <div class="toggle-with-help">
          <label class="toggle toggle-help-inline">
            <input type="checkbox" v-model="config.lightweight_tray" />
            <span class="toggle-slider"></span>
            <span class="toggle-label">显示系统托盘</span>
            <span class="field-help" tabindex="0" role="note" data-tip="轻量模式下显示系统托盘图标。点击托盘中的「打开控制台」可唤醒 Web 管理界面。">?</span>
          </label>
        </div>
      </div>
      <span class="hint">开启后可通过托盘图标唤醒 Web 控制台</span>
    </div>
  </section>

  <section class="card settings-panel">
    <div class="card-header">
      <h2>网络与端口</h2>
    </div>
    <div class="card-body">
      <div class="form-group">
        <div class="field-label-row">
          <label for="settings-app-port">控制台端口</label>
          <span class="field-help" tabindex="0" role="note" data-tip="Web 控制台的监听端口。修改后需要重启服务器才能生效。默认 50721，范围 1024~65535。">?</span>
        </div>
        <input
          id="settings-app-port"
          v-model.number="config.app_port"
          type="number"
          min="1024"
          max="65535"
        />
      </div>
      <div class="form-group">
        <div class="field-label-row">
          <label for="settings-proxy">网络代理</label>
          <span class="field-help" tabindex="0" role="note" data-tip="用于远程仓库导入等网络请求的代理地址。留空则不使用代理。支持 HTTP 和 SOCKS5 协议，例如 http://127.0.0.1:7897 或 socks5://127.0.0.1:7890。">?</span>
        </div>
        <input
          id="settings-proxy"
          v-model.trim="config.proxy"
          type="text"
          placeholder="留空不使用代理，例如 http://127.0.0.1:7897"
        />
      </div>
      <div class="form-group">
        <div class="field-label-row">
          <label for="settings-shell">Shell 路径</label>
          <span class="field-help" tabindex="0" role="note" data-tip="定时任务执行 Shell 命令时使用的 Shell。留空使用系统默认（Windows 优先 PowerShell，Linux/macOS 使用 bash）。">?</span>
        </div>
        <custom-select v-model="shellPathMode" :options="shellPathOptions"></custom-select>
        <div v-if="shellPathMode === '__custom__' || shellCustomMode" class="shell-custom-input">
          <input
            v-model.trim="config.shell_path"
            type="text"
            placeholder="输入 Shell 可执行文件的完整路径"
          />
          <button type="button" class="btn btn-sm btn-secondary" @click="$refs.shellFileInput.click()">浏览...</button>
          <input
            ref="shellFileInput"
            type="file"
            accept=".exe,.bat,.cmd,.ps1,.sh"
            style="display:none"
            @change="onShellFileSelected"
          />
        </div>
        <span class="hint" v-if="config.shell_path && shellPathMode !== '__custom__'">当前: {{ config.shell_path }}</span>
        <span class="hint" v-else-if="!config.shell_path">默认: {{ defaultShell }}</span>
      </div>
    </div>
  </section>
</div>
```

- [ ] **Step 2: 添加卡片强调样式**

在前端 CSS 文件中添加 `.settings-panel--accent` 样式（如果不存在）。检查 `frontend/css/` 目录下的样式文件，添加：

```css
.settings-panel--accent {
  border-left: 3px solid var(--accent-color, #22d3ee);
}
```

- [ ] **Step 3: Commit**

```bash
git add frontend/partials/pages/settings/settings-system.html frontend/css/
git commit -m "feat: 自启动独立卡片 + 轻量模式托盘开关"
```

---

### Task 7: 验证与清理

- [ ] **Step 1: 运行后端测试**

```bash
cd E:/Campus-Auth && python -m pytest tests/ -v --tb=short
```

- [ ] **Step 2: 手动测试 — 轻量模式不带托盘**

```bash
cd E:/Campus-Auth && python main.py --runtime-mode lightweight --no-tray --force
```

验证：进程正常启动，无托盘图标，Ctrl+C 可退出。

- [ ] **Step 3: 手动测试 — 轻量模式带托盘**

```bash
cd E:/Campus-Auth && python main.py --runtime-mode lightweight --tray --force
```

验证：托盘图标出现，点击"打开控制台"启动 Web 服务并打开浏览器。

- [ ] **Step 4: 手动测试 — 完整模式不受影响**

```bash
cd E:/Campus-Auth && python main.py --force
```

验证：完整模式行为不变。

- [ ] **Step 5: 最终 Commit**

```bash
git add -A
git commit -m "feat: 轻量模式托盘支持 + 自启动独立卡片完成"
```
