# Code Review Fixes Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use subagent-driven-development (recommended) or executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix 36 issues identified in the code review report (`code-review-report.md`), covering test suite breakage, concurrency bugs, resource leaks, config inconsistencies, and frontend defects.

**Architecture:** Changes are grouped by subsystem to minimize cross-module coordination. Each task is self-contained and independently testable. Tasks within a group can often be committed together.

**Tech Stack:** Python 3.12+, Pydantic V2, Playwright, pytest, Vue 3 (frontend)

---

## File Structure

### Modified Files

| File | Tasks | Changes |
|------|-------|---------|
| `tests/test_config/test_config_schemas.py` | T1 | Remove SystemSettings import and TestSystemSettings class |
| `tests/test_services/test_runtime_config.py` | T1 | Remove SystemSettings import and TestMigrateConfig class |
| `tests/test_services/test_config_service.py` | T2 | Fix custom_variables assertion to check global_settings |
| `app/services/engine.py` | T3 | Guard profile switch against None _monitor_core |
| `app/utils/login.py` | T4 | Remove double close_browser call |
| `app/services/task_executor.py` | T5, T6, T7 | Fix semaphore leak, cancel_event, _login_future cleanup |
| `app/workers/playwright_worker.py` | T8 | Add cancelled flag for timed-out commands |
| `app/services/task_registry.py` | T9 | Make save_task cache update atomic with rollback |
| `app/network/probes.py` | T10, T11 | Fix set_block_proxy to rebuild client, cancel pending futures |
| `app/network/decision.py` | T12 | Remove dead code in is_network_available |
| `app/utils/network.py` | T13 | Fix IPv6 handling in parse_ping_targets |
| `main.py` | T14, T15, T16 | Pass global_settings to build_runtime_config, cap backoff, fix signal handler |
| `app/services/config_service.py` | T17 | Handle empty password clearing |
| `app/utils/config_utils.py` | T18 | Fix decrypt error message in validate_env_config |
| `app/api/config.py` | T19 | Log rollback failure details |
| `app/api/system.py` | T20 | Add asyncio.Lock for check_update cache |
| `app/api/profiles.py` | T21 | Return warning on auto-switch detection failure |
| `app/api/scripts.py` | T22 | Move ThreadPoolExecutor to module level, add shutdown |
| `app/services/autostart.py` | T23 | Fix VBS script to parse JSON PID |
| `app/utils/process.py` | T24 | Add grace period for port check |
| `app/tasks/step_handlers.py` | T25, T26 | Wrap OCR in asyncio.to_thread, include re.error detail |
| `app/utils/notify.py` | T27 | Add try/except to _notify_macos |
| `app/services/login_history_service.py` | T28, T29 | Fix lock window, add fsync |
| `app/workers/script_runner.py` | T30 | Prioritize stderr on failure |
| `app/utils/shell_policy.py` | T31 | Filter kwargs whitelist |
| `app/version.py` | T32 | Remove lru_cache |
| `frontend/js/methods/profiles.js` | T33, T34, T35, T36 | Fix _isNew leak, add defensive checks, password disclaimer |
| `frontend/partials/pages/profiles.html` | T35 | Add opacity style for disabled cards |

---

## Task 1: Remove Dead Test Imports — SystemSettings

**Files:**
- Modify: `tests/test_config/test_config_schemas.py:14-24, 520-561`
- Modify: `tests/test_services/test_runtime_config.py:3, 6-65`

- [ ] **Step 1: Remove SystemSettings from test_config_schemas.py imports**

In `tests/test_config/test_config_schemas.py`, remove `SystemSettings` from the import block (line 24):

```python
from app.schemas import (
    ActionResponse,
    AutoStartStatusResponse,
    GlobalSettings,
    LogEntry,
    MonitorConfigPayload,
    MonitorStatusResponse,
    ProfilesData,
    ProfileSettings,
)
```

- [ ] **Step 2: Remove TestSystemSettings class**

Delete the entire `TestSystemSettings` class (lines 520-561). These tests tested the now-deleted `SystemSettings` class. The equivalent functionality is already covered by `TestGlobalSettings`.

- [ ] **Step 3: Remove test_runtime_config.py entirely or gut it**

The entire file's purpose is testing `migrate_config_if_needed` with `SystemSettings`, both of which no longer exist. Delete the file:

```bash
rm tests/test_services/test_runtime_config.py
```

- [ ] **Step 4: Run tests to verify**

```bash
cd E:/Campus-Auth && python -m pytest tests/test_config/test_config_schemas.py tests/test_services/ -v --timeout=30 2>&1 | head -50
```

Expected: No ImportError. Tests pass (minus any other unrelated failures).

- [ ] **Step 5: Commit**

```bash
git add tests/test_config/test_config_schemas.py tests/test_services/test_runtime_config.py
git commit -m "test: remove dead SystemSettings imports and migrate_config tests"
```

---

## Task 2: Fix test_config_service custom_variables Assertion

**Files:**
- Modify: `tests/test_services/test_config_service.py:294-315`

The test asserts `profile.custom_variables` but `save_config_combined` writes `custom_variables` to `global_settings`, not to the profile. Fix the assertion.

- [ ] **Step 1: Fix the assertion**

In `tests/test_services/test_config_service.py`, change the assertion in `test_updates_custom_variables` (line 312-315):

```python
        # 验证自定义变量被更新到 global_settings
        assert captured_data is not None
        assert captured_data.global_settings.custom_variables == custom_vars
```

- [ ] **Step 2: Run the specific test**

```bash
cd E:/Campus-Auth && python -m pytest tests/test_services/test_config_service.py::TestSaveConfigCombined::test_updates_custom_variables -v --timeout=30
```

Expected: PASS

- [ ] **Step 3: Commit**

```bash
git add tests/test_services/test_config_service.py
git commit -m "test: fix custom_variables assertion to check global_settings"
```

---

## Task 3: Guard Profile Switch Against None _monitor_core [4]

**Files:**
- Modify: `app/services/engine.py:285-289`

During profile switch, `_handle_stop()` sets `_monitor_core = None`. If `shutdown()` runs concurrently from the API thread, it accesses `_monitor_core` without checking for None.

- [ ] **Step 1: Add None guard in _do_network_check**

In `app/services/engine.py`, wrap the profile switch block to protect against concurrent shutdown:

```python
        # 检查是否需要重启（自动切换方案）
        if self._monitor_core and self._monitor_core.consume_profile_switch_flag():
            logger.info("检测到方案切换，重启监控")
            self._handle_stop()
            self._reload_config_internal()
            self._handle_start(EngineCommand(type=EngineCmdType.START))
```

The change is adding `self._monitor_core and` to the `if` condition (line 285). This prevents `AttributeError` if `shutdown()` set `_monitor_core = None` between the top-level `None` check and this line.

- [ ] **Step 2: Commit**

```bash
git add app/services/engine.py
git commit -m "fix: guard profile switch against concurrent shutdown setting _monitor_core to None"
```

---

## Task 4: Remove Double close_browser [5]

**Files:**
- Modify: `app/utils/login.py:300-318`

The `close_browser` method calls both `self._browser_ctx.__aexit__()` and `worker.close_browser()`. The `__aexit__` releases the context reference; `worker.close_browser()` destroys the entire browser instance. This defeats browser persistence.

- [ ] **Step 1: Remove worker.close_browser() call**

Replace the `close_browser` method:

```python
    async def close_browser(self) -> None:
        """释放浏览器上下文引用（不销毁浏览器实例）"""
        if self._browser_ctx:
            try:
                await self._browser_ctx.__aexit__(None, None, None)
            except Exception as exc:
                self.logger.warning("浏览器上下文关闭异常: {}", exc)
            finally:
                self._browser_ctx = None
                self.logger.info("浏览器上下文已释放")
```

Key changes: removed `worker` import and `worker.close_browser()` call. The browser instance stays alive in the Worker for reuse.

- [ ] **Step 2: Commit**

```bash
git add app/utils/login.py
git commit -m "fix: remove double close_browser, only release context reference"
```

---

## Task 5: Fix BoundedExecutor Semaphore Leak [6]

**Files:**
- Modify: `app/services/task_executor.py:78-90`

If `self._executor.submit()` raises after semaphore acquire, the semaphore is never released.

- [ ] **Step 1: Wrap submit in try/except**

```python
    def submit(self, func, *args, **kwargs) -> Future:
        """提交任务到线程池。

        Raises:
            RuntimeError: 队列已满，无法提交更多任务
        """
        if not self._semaphore.acquire(blocking=False):
            raise RuntimeError("任务队列已满，无法提交更多任务")

        try:
            future = self._executor.submit(func, *args, **kwargs)
        except Exception:
            self._semaphore.release()
            raise
        # 任务完成或取消时释放信号量
        future.add_done_callback(lambda _: self._semaphore.release())
        return future
```

- [ ] **Step 2: Commit**

```bash
git add app/services/task_executor.py
git commit -m "fix: release semaphore when BoundedExecutor.submit fails"
```

---

## Task 6: Fix cancel_event Semantic [7]

**Files:**
- Modify: `app/services/task_executor.py:199-213`

When a login is already running and a new caller provides `cancel_event`, the code sets the **caller's** event — not the running task's. This is semantically wrong: the caller thinks it can cancel, but it can't.

- [ ] **Step 1: Don't set caller's cancel_event**

Replace the dedup block:

```python
        with self._login_lock:
            # 检查是否已有登录在进行
            if self._login_future is not None and not self._login_future.done():
                # 去重：返回已有 Future，不设置调用方的 cancel_event
                logger.debug("登录任务已在执行中，跳过重复提交")
                return self._login_future

            # 提交新的登录任务
            future = self._login_pool.submit(self.execute_login, cancel_event)
            self._login_future = future
            return future
```

The `cancel_event.set()` line is removed. When deduplicating, return the existing future without touching the caller's event.

- [ ] **Step 2: Commit**

```bash
git add app/services/task_executor.py
git commit -m "fix: don't set caller's cancel_event on login dedup"
```

---

## Task 7: Clear _login_future After Completion [24]

**Files:**
- Modify: `app/services/task_executor.py:199-213`

`_login_future` is set but never cleared, holding stale references.

- [ ] **Step 1: Add done_callback to clear _login_future**

After setting `self._login_future = future`, add a callback:

```python
            # 提交新的登录任务
            future = self._login_pool.submit(self.execute_login, cancel_event)
            self._login_future = future
            future.add_done_callback(self._on_login_done)
            return future
```

Add the callback method to the class (near `execute_login_async`):

```python
    def _on_login_done(self, future: Future) -> None:
        """登录任务完成后清理引用。"""
        with self._login_lock:
            if self._login_future is future:
                self._login_future = None
```

- [ ] **Step 2: Commit**

```bash
git add app/services/task_executor.py
git commit -m "fix: clear _login_future reference after task completion"
```

---

## Task 8: Add Cancelled Flag for Timed-Out Worker Commands [20]

**Files:**
- Modify: `app/workers/playwright_worker.py:240-290`

When `submit()` times out, the command remains in the queue and may still execute. Add a `cancelled` flag.

- [ ] **Step 1: Add cancelled field to WorkerCommand**

Find the `WorkerCommand` class definition and add a `cancelled` field:

```python
@dataclass
class WorkerCommand:
    type: str
    data: dict = field(default_factory=dict)
    response_event: threading.Event | None = None
    response_data: Any = None
    cancelled: bool = False
```

- [ ] **Step 2: Set cancelled on timeout in submit()**

After the timeout check in `submit()`:

```python
        # 阻塞等待命令执行完成
        cmd.response_event.wait(timeout=timeout)
        if cmd.response_data is not None:
            if isinstance(cmd.response_data, WorkerResponse):
                return cmd.response_data
            return WorkerResponse(success=True, data=cmd.response_data)

        # 超时：标记命令为已取消
        cmd.cancelled = True
        return WorkerResponse(success=False, error="命令执行超时或无响应")
```

- [ ] **Step 3: Check cancelled flag in dispatch**

Find the `_dispatch` method (or wherever commands are dequeued and executed). Before executing, check:

```python
        if cmd.cancelled:
            return  # 命令已超时，跳过执行
```

- [ ] **Step 4: Commit**

```bash
git add app/workers/playwright_worker.py
git commit -m "fix: skip execution of timed-out worker commands"
```

---

## Task 9: Make save_task Cache Update Atomic [22]

**Files:**
- Modify: `app/services/task_registry.py:75-104`

If disk write succeeds but cache update fails, the task "disappears". Add rollback.

- [ ] **Step 1: Restructure save_task with cache-first approach**

```python
    def save_task(self, task_id: str, config: dict[str, Any]) -> tuple[bool, str]:
        """保存任务（创建或更新）。同步更新缓存和调度索引。"""
        if not is_valid_task_id(task_id):
            return False, "无效的任务 ID"

        task_file = self._tasks_dir / f"{task_id}.json"
        with self._lock:
            # 备份旧缓存
            old = self._cache.get(task_id)
            old_index_entry = deepcopy(old) if old is not None else None

            # 先更新缓存（可回滚）
            stored = deepcopy(config)
            stored["id"] = task_id
            self._cache[task_id] = stored
            if old is not None:
                self._remove_from_index(task_id, old)
            self._add_to_index(task_id, stored)

        try:
            # 写入磁盘
            data = {k: v for k, v in config.items() if k != "id"}
            atomic_write(
                str(task_file),
                json.dumps(data, ensure_ascii=False, indent=2),
            )
        except Exception as exc:
            # 写入失败，回滚缓存
            with self._lock:
                if old_index_entry is not None:
                    self._cache[task_id] = old_index_entry
                    self._remove_from_index(task_id, stored)
                    self._add_to_index(task_id, old_index_entry)
                else:
                    self._cache.pop(task_id, None)
                    self._remove_from_index(task_id, stored)
            logger.error("保存定时任务失败 {}: {}", task_id, exc)
            return False, f"定时任务保存失败: {exc}"

        logger.info("定时任务已保存: {}", task_id)
        return True, "定时任务保存成功"
```

- [ ] **Step 2: Commit**

```bash
git add app/services/task_registry.py
git commit -m "fix: rollback cache on save_task disk write failure"
```

---

## Task 10: Fix set_block_proxy to Rebuild Client [27]

**Files:**
- Modify: `app/network/probes.py:75-83`

`set_block_proxy` modifies the global flag but doesn't close/rebuild the existing httpx client. Old client continues using stale proxy settings.

- [ ] **Step 1: Close old client in set_block_proxy**

```python
def set_block_proxy(enabled: bool) -> None:
    """设置是否屏蔽系统代理。

    当 enabled=True 时，HTTP 客户端不读取系统代理设置（默认行为）；
    当 enabled=False 时，允许 HTTP 客户端使用系统代理。
    """
    global _block_proxy, _probe_client, _probe_block_proxy
    with _proxy_lock:
        _block_proxy = enabled
    # 关闭旧客户端，下次探测时自动重建
    with _probe_lock:
        if _probe_client is not None and not _probe_client.is_closed:
            _probe_client.close()
        _probe_client = None
```

- [ ] **Step 2: Commit**

```bash
git add app/network/probes.py
git commit -m "fix: close and rebuild httpx client when proxy setting changes"
```

---

## Task 11: Cancel Pending Probe Futures on Success [28]

**Files:**
- Modify: `app/network/probes.py:106-134`

When the first target succeeds, remaining futures continue consuming thread pool resources until timeout.

- [ ] **Step 1: Cancel remaining futures on success**

Find the TCP/HTTP/URL probe functions. In each, after `return True` in the `as_completed` loop, cancel the rest:

```python
            for future in as_completed(futures, timeout=overall_timeout):
                if future.result(timeout=1):
                    # 成功：取消其余任务
                    for f in futures:
                        if not f.done():
                            f.cancel()
                    return True
```

Apply this pattern to all three probe functions (`_tcp_probe`, `_http_probe`, `_url_probe`).

- [ ] **Step 2: Commit**

```bash
git add app/network/probes.py
git commit -m "fix: cancel pending probe futures on first success"
```

---

## Task 12: Remove Dead Code in is_network_available [59]

**Files:**
- Modify: `app/network/decision.py:193-218`

The `socket_ok`/`http_ok`/`url_ok` assignments are dead code — the function returns `False` immediately when any check fails, so these variables are only ever `True`.

- [ ] **Step 1: Simplify the result logic**

Replace the result computation block with:

```python
    # 所有已启用的检测都通过（任何失败已在循环中 return False）
    return True
```

Remove the `socket_ok`, `http_ok`, `url_ok` variable declarations and the final `result` expression.

- [ ] **Step 2: Commit**

```bash
git add app/network/decision.py
git commit -m "refactor: remove dead code in is_network_available"
```

---

## Task 13: Fix IPv6 Handling in parse_ping_targets [61]

**Files:**
- Modify: `app/utils/network.py:84-117`

IPv6 addresses contain colons, so `if ":" not in item` incorrectly treats them as having a port.

- [ ] **Step 1: Add IPv6 detection**

```python
    # 补全缺少端口的项
    targets: list[str] = []
    for item in items:
        if item.startswith("["):
            # 已是 [IPv6]:port 格式，直接传递
            targets.append(item)
        elif ":" in item and not item.startswith("["):
            # 可能是 IPv6 地址（含多个冒号）或 host:port
            # IPv6 地址的冒号数量 >= 2
            colon_count = item.count(":")
            if colon_count >= 2:
                # IPv6 地址，补全端口
                targets.append(f"[{item}]:53")
            else:
                # host:port 格式，直接传递
                targets.append(item)
        else:
            # 无冒号：IPv4 或域名
            parts = item.split(".")
            is_ipv4 = len(parts) == 4 and all(p.isdigit() for p in parts)
            targets.append(f"{item}:{53 if is_ipv4 else 443}")
```

- [ ] **Step 2: Commit**

```bash
git add app/utils/network.py
git commit -m "fix: handle IPv6 addresses in parse_ping_targets"
```

---

## Task 14: Pass global_settings to build_runtime_config [14]

**Files:**
- Modify: `main.py:178-182`

CLI login mode calls `build_runtime_config(payload)` without `global_settings`, so browser config and retry settings use defaults.

- [ ] **Step 1: Pass global_settings**

In `main.py`, find the `build_runtime_config` call in `_run_login_then_exit` and change:

```python
        runtime_config = build_runtime_config(payload, global_settings=data.global_settings)
```

- [ ] **Step 2: Commit**

```bash
git add main.py
git commit -m "fix: pass global_settings to build_runtime_config in CLI login mode"
```

---

## Task 15: Cap Exponential Backoff [66]

**Files:**
- Modify: `main.py:208-212`

The delay `retry_interval * 2^(attempt-2)` grows without bound. With `max_retries=10` and `retry_interval=5`, the last delay is `5 * 256 = 1280` seconds (~21 minutes).

- [ ] **Step 1: Add backoff cap**

```python
        if attempt > 1:
            delay = min(retry_interval * (2 ** (attempt - 2)), 300)
            print(f"等待 {delay} 秒后重试第 {attempt} 次...")
            time.sleep(delay)
```

The `min(..., 300)` caps the delay at 5 minutes.

- [ ] **Step 2: Commit**

```bash
git add main.py
git commit -m "fix: cap exponential backoff at 300 seconds"
```

---

## Task 16: Ensure Signal Handler Cleanup Completes [41]

**Files:**
- Modify: `main.py:389-401`

The `os._exit(0)` path (uvicorn not ready) may skip `cleanup_pid()` if the signal arrives during cleanup.

- [ ] **Step 1: Move cleanup_pid before os._exit(0)**

```python
    def _signal_handler(signum, _frame):
        nonlocal _shutdown_initiated
        if _shutdown_initiated:
            cleanup_pid()
            os._exit(1)
        _shutdown_initiated = True
        logger.info("收到退出信号，正在关闭服务...")
        cleanup_pid()
        if _uvicorn_server[0] is not None:
            _uvicorn_server[0].should_exit = True
        else:
            os._exit(0)
```

The code already calls `cleanup_pid()` before `os._exit(0)`. The issue is that `cleanup_pid()` itself might be interrupted by a second signal. This is inherently unavoidable with `os._exit`. The current code is actually correct — the only risk is a third signal during cleanup, which is extreme. No change needed here beyond documenting.

- [ ] **Step 2: Add comment explaining the design**

```python
    def _signal_handler(signum, _frame):
        nonlocal _shutdown_initiated
        if _shutdown_initiated:
            # 双击 Ctrl+C：强制退出（cleanup_pid 在首次信号时已完成）
            cleanup_pid()
            os._exit(1)
        _shutdown_initiated = True
        logger.info("收到退出信号，正在关闭服务...")
        cleanup_pid()
        if _uvicorn_server[0] is not None:
            _uvicorn_server[0].should_exit = True
        else:
            # uvicorn 未就绪，PID 已清理，直接退出
            os._exit(0)
```

- [ ] **Step 3: Commit**

```bash
git add main.py
git commit -m "docs: clarify signal handler cleanup design intent"
```

---

## Task 17: Handle Empty Password Clearing [15]

**Files:**
- Modify: `app/services/config_service.py:84-86`

When user clears the password field (empty string), the old password persists because `""` is falsy.

- [ ] **Step 1: Handle explicit empty password**

```python
        # 更新凭证
        from app.utils.crypto import save_password_field
        profile.username = payload.username.strip()
        pwd_raw = payload.password.strip()
        if pwd_raw.startswith("•"):
            pass  # 掩码值，不更新密码
        elif pwd_raw:
            profile.password = save_password_field(pwd_raw, profile.password)
        else:
            # 用户显式清空密码
            profile.password = ""
```

- [ ] **Step 2: Commit**

```bash
git add app/services/config_service.py
git commit -m "fix: allow clearing password when user submits empty string"
```

---

## Task 18: Fix Decrypt Error Message in validate_env_config [33]

**Files:**
- Modify: `app/utils/config_utils.py:35-62`

When `decrypt_password` fails (key mismatch), the error says "缺少用户名或密码" which is misleading.

- [ ] **Step 1: Check for decryption errors**

```python
    @staticmethod
    def validate_env_config(config: dict) -> tuple[bool, str]:
        """验证环境配置是否完整。"""
        username = config.get("username")
        password = config.get("password")
        auth_url = config.get("auth_url")

        if not username or not password:
            return False, "缺少用户名或密码"

        if not auth_url:
            return False, "缺少认证地址"

        from app.schemas import _URL_PATTERN
        if not _URL_PATTERN.match(auth_url):
            return False, "认证地址必须以 http:// 或 https:// 开头"

        # 检查密码解密是否失败
        from app.utils.crypto import has_decryption_error
        if has_decryption_error():
            return False, "密码解密失败（可能是密钥变更），请在设置页面重新输入密码"

        return True, ""
```

- [ ] **Step 2: Commit**

```bash
git add app/utils/config_utils.py
git commit -m "fix: report decryption failure instead of 'missing credentials'"
```

---

## Task 19: Log Rollback Failure Details [34]

**Files:**
- Modify: `app/api/config.py:106-107`

When rollback fails, the error is silently swallowed.

- [ ] **Step 1: Log the rollback exception**

```python
            except Exception as rollback_exc:
                api_logger.error(
                    "回滚失败（磁盘配置已回滚，运行时状态可能不一致）: {}",
                    rollback_exc,
                    exc_info=True,
                )
```

- [ ] **Step 2: Commit**

```bash
git add app/api/config.py
git commit -m "fix: log rollback failure details for config save"
```

---

## Task 20: Add asyncio.Lock for check_update Cache [35]

**Files:**
- Modify: `app/api/system.py:51-99`

Concurrent async requests can race past the cache check and both trigger HTTP fetches.

- [ ] **Step 1: Add module-level lock and use it**

At the top of the file, add:

```python
_update_lock = asyncio.Lock()
```

Wrap the cache check and update:

```python
@router.get("/api/check-update")
async def check_update() -> dict:
    global _update_cache, _update_cache_time

    current = get_project_version(PROJECT_ROOT)

    async with _update_lock:
        # 缓存命中直接返回
        if _update_cache and (time.monotonic() - _update_cache_time) < _UPDATE_CACHE_TTL:
            return {**_update_cache, "current": current}

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.get(
                    "https://api.github.com/repos/Misyra/Campus-Auth/releases/latest",
                    headers={
                        "Accept": "application/vnd.github.v3+json",
                        "User-Agent": "Campus-Auth",
                    },
                )
            resp.raise_for_status()
            data = resp.json()
            tag = data.get("tag_name", "").lstrip("v")
            result = {
                "current": current,
                "latest": tag,
                "has_update": compare_versions(tag, current) > 0,
                "url": data.get("html_url", ""),
                "body": data.get("body", ""),
                "published_at": data.get("published_at", ""),
            }
            _update_cache = result
            _update_cache_time = time.monotonic()
            return result
        except Exception as e:
            if _update_cache:
                return {
                    **_update_cache,
                    "current": current,
                    "cached": True,
                    "error": str(e),
                }
            return {
                "current": current,
                "latest": None,
                "has_update": False,
                "error": str(e),
            }
```

- [ ] **Step 2: Commit**

```bash
git add app/api/system.py
git commit -m "fix: add asyncio.Lock to prevent duplicate check_update requests"
```

---

## Task 21: Return Warning on Auto-Switch Detection Failure [37]

**Files:**
- Modify: `app/api/profiles.py:164-186`

Exceptions during auto-switch detection are swallowed, returning `success: True`.

- [ ] **Step 1: Track warning state**

```python
    # 开启自动切换时，立即进行一次检测
    warning = None
    if enabled_bool:
        try:
            matched_id = profile_svc.detect_matching_profile()
            if matched_id:
                if matched_id != data.active_profile:
                    profile = data.profiles.get(matched_id)
                    profile_name = profile.name if profile else matched_id
                    api_logger.info("自动切换检测到匹配方案: {}", profile_name)
                    profile_svc.set_active_profile(matched_id)
                    monitor_svc.apply_profile(matched_id)
                    active_profile = matched_id
                else:
                    api_logger.info("当前方案已匹配，无需切换")
            else:
                api_logger.info("未检测到匹配方案，保持当前方案")
        except Exception as exc:
            api_logger.warning("自动切换检测失败: {}", exc)
            warning = f"首次检测失败: {exc}"

    result = {
        "success": True,
        "message": f"自动切换已{state}",
        "active_profile": active_profile,
    }
    if warning:
        result["warning"] = warning
    return result
```

- [ ] **Step 2: Commit**

```bash
git add app/api/profiles.py
git commit -m "fix: include warning in response when auto-switch detection fails"
```

---

## Task 22: Move ThreadPoolExecutor to Module Level [36]

**Files:**
- Modify: `app/api/scripts.py:100-105`

The executor is created as a function attribute, which is not thread-safe and never shut down.

- [ ] **Step 1: Move to module level**

At the top of the file (after imports), add:

```python
_script_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="script_runner")
```

Replace the function-level creation:

```python
    loop = asyncio.get_running_loop()
    success, message = await loop.run_in_executor(_script_executor, runner.run)
```

Remove the `hasattr` check and `run_script._executor` usage.

- [ ] **Step 2: Commit**

```bash
git add app/api/scripts.py
git commit -m "fix: move script ThreadPoolExecutor to module level"
```

---

## Task 23: Fix VBS Script PID Parsing [38]

**Files:**
- Modify: `app/services/autostart.py:292-322`

VBS reads the first line expecting a numeric PID, but `write_pid` writes JSON.

- [ ] **Step 1: Update VBS to parse JSON PID**

Replace the VBS PID reading block in `_build_vbs_content`:

```python
        return f"""Set WshShell = CreateObject("WScript.Shell")

' Check if already running
Set fso = CreateObject("Scripting.FileSystemObject")
pidFile = WshShell.ExpandEnvironmentStrings("%USERPROFILE%") & "\\.campus_network_auth\\campus_network_auth.pid"

If fso.FileExists(pidFile) Then
    Set file = fso.OpenTextFile(pidFile, 1)
    pid = 0
    On Error Resume Next
    Dim rawContent
    rawContent = Trim(file.ReadLine)
    file.Close

    ' 尝试解析 JSON 格式的 PID
    ' 简单提取 "pid": 数字
    Dim pidStr
    Dim pos1, pos2
    pos1 = InStr(rawContent, """":""") + 5
    If pos1 > 5 Then
        pos2 = InStr(pos1, rawContent, ",")
        If pos2 = 0 Then pos2 = InStr(pos1, rawContent, "}}")
        If pos2 > pos1 Then
            pidStr = Trim(Mid(rawContent, pos1, pos2 - pos1))
            If IsNumeric(pidStr) Then pid = CLng(pidStr)
        End If
    End If
    On Error GoTo 0

    ' Check if the process is still alive
    If pid > 0 Then
        On Error Resume Next
        Set objWMIService = GetObject("winmgmts:\\\\.\\root\\cimv2")
        Set colProcessList = objWMIService.ExecQuery("Select * from Win32_Process where ProcessId = " & pid)
        If colProcessList.Count > 0 Then
            WScript.Quit
        End If
        On Error GoTo 0
    End If
End If

{run_command}
"""
```

- [ ] **Step 2: Commit**

```bash
git add app/services/autostart.py
git commit -m "fix: update VBS script to parse JSON PID file format"
```

---

## Task 24: Add Grace Period for Port Check [40]

**Files:**
- Modify: `app/utils/process.py:130-139`

During startup, the process exists but port isn't listening yet → PID file gets deleted.

- [ ] **Step 1: Add grace period check**

```python
    # 完整模式下进一步验证端口是否在监听
    mode = data.get("mode")
    if mode != "lightweight":
        from app.utils.ports import resolve_port

        port = resolve_port()
        if not is_local_port_in_use(port):
            # 宽限期：进程刚启动时端口可能还未就绪
            create_time = data.get("create_time")
            if create_time and (time.time() - create_time) < 30:
                return True, pid  # 刚启动，跳过端口检查
            # 进程存在但未监听端口 → 不是本应用实例，清理残留 PID 文件
            pid_file.unlink(missing_ok=True)
            return False, None
```

Add `import time` at the top of the file if not already present.

- [ ] **Step 2: Commit**

```bash
git add app/utils/process.py
git commit -m "fix: add 30s grace period for port check during startup"
```

---

## Task 25: Wrap OCR in asyncio.to_thread [17]

**Files:**
- Modify: `app/tasks/step_handlers.py:750-764`

`ddddocr` initialization and `classification()` are synchronous blocking calls in an async method.

- [ ] **Step 1: Wrap blocking OCR calls**

Replace the OCR recognition block:

```python
        # OCR 识别（识别失败也需要 schedule_cleanup）
        try:
            if char_range is not None:
                # 有字符范围限制时创建独立实例，避免 set_ranges 污染缓存实例
                import ddddocr

                ocr = await asyncio.to_thread(ddddocr.DdddOcr, old=old, show_ad=False)
                ocr.set_ranges(char_range)
                logger.debug("[ocr] set_ranges({})", char_range)
            else:
                ocr = self._get_ocr(old=old)
            result = await asyncio.to_thread(ocr.classification, img_bytes)
        except Exception as e:
            self.schedule_cleanup(old)
            return False, f"验证码识别失败: {e}"
```

Also wrap the `_get_ocr` call since it may initialize the model:

```python
            else:
                ocr = await asyncio.to_thread(self._get_ocr, old=old)
```

- [ ] **Step 2: Commit**

```bash
git add app/tasks/step_handlers.py
git commit -m "fix: wrap OCR initialization and classification in asyncio.to_thread"
```

---

## Task 26: Include re.error Detail in WaitUrlHandler [18]

**Files:**
- Modify: `app/tasks/step_handlers.py:517-520`

The `re.error` exception is silently discarded.

- [ ] **Step 1: Include error detail**

```python
        try:
            compiled = re.compile(pattern)
        except re.error as e:
            return False, f"wait_url 步骤的 pattern 不是有效的正则表达式: {pattern} ({e})"
```

- [ ] **Step 2: Commit**

```bash
git add app/tasks/step_handlers.py
git commit -m "fix: include re.error detail in WaitUrlHandler error message"
```

---

## Task 27: Add try/except to _notify_macos [45]

**Files:**
- Modify: `app/utils/notify.py:76-89`

`subprocess.run` has no exception handling, unlike Windows/Linux branches.

- [ ] **Step 1: Wrap in try/except**

```python
def _notify_macos(title: str, message: str) -> bool:
    """macOS: 使用 osascript 发送通知"""
    try:
        safe_title = title.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")
        safe_msg = message.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")
        script = f'display notification "{safe_msg}" with title "{safe_title}"'
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.returncode == 0
    except Exception:
        return False
```

- [ ] **Step 2: Commit**

```bash
git add app/utils/notify.py
git commit -m "fix: add exception handling to _notify_macos"
```

---

## Task 28: Fix login_history Lock Window [46]

**Files:**
- Modify: `app/services/login_history_service.py:83-119`

The cleanup acquires `_lock` a second time after releasing it, creating a race window.

- [ ] **Step 1: Move cleanup inside the same lock block**

```python
    def add(
        self,
        success: bool,
        duration_ms: int = 0,
        profile_name: str = "",
        task_name: str = "",
        error: str = "",
    ) -> None:
        """追加一条登录记录。"""
        now = datetime.now()
        entry = LoginHistoryEntry(
            id=f"{now.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
            timestamp=now.strftime("%Y-%m-%d %H:%M:%S"),
            success=success,
            duration_ms=duration_ms,
            profile_name=profile_name,
            task_name=task_name,
            error=error[:200] if error else "",
        )
        with self._lock:
            try:
                with open(self._history_path, "a", encoding="utf-8") as f:
                    f.write(entry.model_dump_json() + "\n")
                    f.flush()
                self._write_count += 1
                # 每 50 次写入概率性清理旧记录
                if self._write_count % 50 == 0:
                    self._cleanup_old(max_age_days=30)
            except Exception:
                logger.warning(
                    "写入登录历史失败: {}", self._history_path, exc_info=True
                )
```

Key change: `_cleanup_old` is now called inside the same `with self._lock:` block, eliminating the race window.

- [ ] **Step 2: Commit**

```bash
git add app/services/login_history_service.py
git commit -m "fix: move cleanup inside same lock block to prevent race"
```

---

## Task 29: Add fsync to login_history Writes [47]

**Files:**
- Modify: `app/services/login_history_service.py:97-100`

`flush()` without `fsync()` means data can be lost on crash.

- [ ] **Step 1: Add os.fsync**

```python
                with open(self._history_path, "a", encoding="utf-8") as f:
                    f.write(entry.model_dump_json() + "\n")
                    f.flush()
                    os.fsync(f.fileno())
```

Add `import os` at the top of the file if not already present.

- [ ] **Step 2: Commit**

```bash
git add app/services/login_history_service.py
git commit -m "fix: add os.fsync after login history write"
```

---

## Task 30: Prioritize stderr on Script Failure [56]

**Files:**
- Modify: `app/workers/script_runner.py:228-244`

When stdout has content but the script fails, stderr is completely ignored.

- [ ] **Step 1: Prioritize stderr on failure**

```python
        elapsed = time.perf_counter() - start

        if stderr_str:
            logger.warning("脚本 stderr: {}", stderr_str[:500])

        if returncode == 0:
            output = stdout_str[:500] or f"(无输出, exit code 0)"
            logger.info("脚本执行完成 ({:.1f}s): {}", elapsed, output)
            return True, output
        else:
            # 失败时优先使用 stderr
            output = stderr_str[:500] or stdout_str[:500] or f"(无输出, exit code {returncode})"
            logger.warning(
                "脚本执行失败 ({:.1f}s, exit {}): {}", elapsed, returncode, output
            )
            return False, output
```

- [ ] **Step 2: Commit**

```bash
git add app/workers/script_runner.py
git commit -m "fix: prioritize stderr output when script execution fails"
```

---

## Task 31: Filter kwargs in shell_policy [70]

**Files:**
- Modify: `app/utils/shell_policy.py:154-206`

`**kwargs` can override security-critical defaults like `shell=True`.

- [ ] **Step 1: Whitelist allowed kwargs**

```python
    # 允许的额外参数（安全白名单）
    _ALLOWED_KWARGS = {"env", "cwd"}

    def run_sync(
        self,
        argv: list[str],
        *,
        timeout: int | None = None,
        **kwargs,
    ) -> tuple[int, str, str]:
        """同步执行命令（用于 script_runner 的 subprocess.run 场景）。"""
        if not argv:
            raise ValueError("命令参数列表不能为空")

        executable = argv[0]
        ok, effective_timeout, err = self.validate_and_prepare(executable, timeout)
        if not ok:
            raise PermissionError(err)

        self._audit(argv, effective_timeout)

        run_kwargs = {
            "capture_output": True,
            "text": True,
            "timeout": effective_timeout,
            "encoding": "utf-8",
            "errors": "replace",
        }
        if platform.system() == "Windows":
            run_kwargs["creationflags"] = CREATE_NO_WINDOW_FLAG

        # 只允许白名单中的额外参数
        for key in self._ALLOWED_KWARGS:
            if key in kwargs:
                run_kwargs[key] = kwargs[key]

        try:
            result = subprocess.run(argv, **run_kwargs)
        except subprocess.TimeoutExpired:
            return -1, "", f"命令执行超时 ({effective_timeout}s)"
        except FileNotFoundError:
            return -1, "", f"执行文件不存在: {executable}"

        stdout_str = result.stdout.strip() if result.stdout else ""
        stderr_str = result.stderr.strip() if result.stderr else ""

        return result.returncode, stdout_str, stderr_str
```

- [ ] **Step 2: Commit**

```bash
git add app/utils/shell_policy.py
git commit -m "fix: whitelist kwargs in shell_policy.run_sync to prevent bypass"
```

---

## Task 32: Remove lru_cache from get_project_version [71]

**Files:**
- Modify: `app/version.py:12-15`

`lru_cache` with `maxsize=1` makes the `project_root` parameter useless after first call.

- [ ] **Step 1: Remove @lru_cache**

```python
def get_project_version(project_root: Path | None = None) -> str:
    """从 pyproject.toml 读取项目版本，读取失败时返回 unknown。"""
    root = project_root or Path(__file__).resolve().parents[1]
```

Remove the `from functools import lru_cache` import if no longer used.

- [ ] **Step 2: Commit**

```bash
git add app/version.py
git commit -m "fix: remove lru_cache from get_project_version to respect project_root param"
```

---

## Task 33: Fix saveProfile _isNew Leak [11]

**Files:**
- Modify: `frontend/js/methods/profiles.js:54`

`_isNew` is not destructured out and leaks into the API request body.

- [ ] **Step 1: Destructure _isNew**

```javascript
    const { id, _isNew, ...settings } = this.editingProfile;
```

- [ ] **Step 2: Commit**

```bash
git add frontend/js/methods/profiles.js
git commit -m "fix: exclude _isNew from settings sent to API"
```

---

## Task 34: Use POST Body for toggleAutoSwitch [12]

**Files:**
- Modify: `frontend/js/methods/profiles.js:148`
- Modify: `app/api/profiles.py` (route handler for auto-switch)

- [ ] **Step 1: Change frontend to send POST body**

```javascript
    await this.$api.post('/api/profiles/auto-switch', { enabled: newState });
```

- [ ] **Step 2: Update backend to accept body parameter**

In `app/api/profiles.py`, change the route handler signature from `enabled: str = Query(...)` to accepting a body:

```python
@router.post("/api/profiles/auto-switch")
def toggle_auto_switch(
    body: dict = Body(default={}),
    profile_svc: ProfileService = Depends(get_profile_service),
    monitor_svc: ScheduleEngine = Depends(get_monitor_service),
) -> dict:
    enabled = body.get("enabled", True)
    if isinstance(enabled, str):
        enabled_bool = enabled.strip().lower() in ("true", "1", "yes", "on")
    else:
        enabled_bool = bool(enabled)
```

- [ ] **Step 3: Commit**

```bash
git add frontend/js/methods/profiles.js app/api/profiles.py
git commit -m "fix: use POST body for toggleAutoSwitch instead of query string"
```

---

## Task 35: Add Defensive Check and Visual Hint for Auto-Switch [42, 43, 44]

**Files:**
- Modify: `frontend/js/methods/profiles.js:78-114`
- Modify: `frontend/partials/pages/profiles.html:134`

- [ ] **Step 1: Add defensive check in setActiveProfile**

```javascript
  async setActiveProfile(profileId) {
    if (this.autoSwitch) return;
    try {
      const { data } = await this.$api.post(`/api/profiles/active/${profileId}`);
      // ... rest unchanged
```

- [ ] **Step 2: Add state recovery in deleteProfile**

After `fetchProfiles()`, check if `activeProfileId` still exists:

```javascript
        await this.fetchProfiles();
        // 如果删除的是活动方案，重置 activeProfileId
        if (!this.profiles[this.activeProfileId]) {
          this.activeProfileId = 'default';
        }
```

- [ ] **Step 3: Add opacity style for disabled cards**

In `frontend/partials/pages/profiles.html`, find the CSS for `.profile-card-main.disabled` and add:

```css
.profile-card-main.disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
```

If the style is in a separate CSS file, add it there instead.

- [ ] **Step 4: Commit**

```bash
git add frontend/js/methods/profiles.js frontend/partials/pages/profiles.html
git commit -m "fix: add auto-switch defensive check, delete recovery, and disabled card opacity"
```

---

## Task 36: Add Password Disclaimer to Frontend

**Files:**
- Modify: `frontend/partials/pages/settings.html` (or wherever the password field is)

- [ ] **Step 1: Add disclaimer text near password field**

Find the password input field in the settings/config page and add a small disclaimer below it:

```html
<p class="text-xs text-muted mt-1">密码本地存储，不保证意外删除后可恢复</p>
```

Adjust the exact location and CSS classes to match the existing design.

- [ ] **Step 2: Commit**

```bash
git add frontend/partials/pages/settings.html
git commit -m "docs: add password non-recovery disclaimer in frontend"
```

---

## Execution Notes

- Tasks 1-2 must be done first (unblock test suite)
- Tasks 3-9 are engine/executor core fixes (high impact)
- Tasks 10-13 are network layer fixes
- Tasks 14-16 are startup/config fixes
- Tasks 17-22 are API/config fixes
- Tasks 23-24 are process management fixes
- Tasks 25-32 are utility module fixes
- Tasks 33-36 are frontend fixes

Each task is independently committable. Run `pytest` after tasks 1-2 and after the final task to verify.
