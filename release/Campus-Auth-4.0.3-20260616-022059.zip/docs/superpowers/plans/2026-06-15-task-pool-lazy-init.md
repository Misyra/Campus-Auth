# TaskExecutor 定时任务线程池懒初始化

> **For agentic workers:** REQUIRED SUB-SKILL: Use subagent-driven-development (recommended) or executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 定时任务线程池改为懒初始化，无定时任务时不创建线程，减少资源占用。

**Architecture:** `_task_pool` 初始为 `None`，首次调用 `execute_task_async` 时才创建。`_login_pool` 保持立即创建（自动登录需要）。`shutdown` 时检查池是否存在再关闭。

**Tech Stack:** Python, pytest

---

## 文件变更清单

| 文件 | 变更类型 | 说明 |
|------|----------|------|
| `app/services/task_executor.py:101-142,178-187,506-511` | 修改 | 懒初始化 `_task_pool` |
| `tests/test_services/test_task_executor_fix.py` | 修改 | 补充懒初始化测试 |

---

### Task 1: 实现懒初始化

**Files:**
- Modify: `app/services/task_executor.py:101-142,178-187,506-511`
- Test: `tests/test_services/test_task_executor_fix.py`

- [ ] **Step 1: 编写懒初始化测试**

`tests/test_services/test_task_executor_fix.py` 末尾添加：

```python
class TestTaskPoolLazyInit:
    """定时任务线程池懒初始化测试。"""

    def test_task_pool_initially_none(self, tmp_path):
        """初始化时 _task_pool 应为 None。"""
        from app.services.task_executor import TaskExecutor

        registry = MagicMock()
        registry.has_enabled_tasks.return_value = False
        history_store = MagicMock()

        executor = TaskExecutor(
            registry=registry,
            history_store=history_store,
            worker_getter=MagicMock(),
        )
        assert executor._task_pool is None

    def test_task_pool_created_on_first_use(self, tmp_path):
        """首次调用 execute_task_async 时创建 _task_pool。"""
        from app.services.task_executor import TaskExecutor

        registry = MagicMock()
        registry.get_task.return_value = {
            "type": "script",
            "target_id": "test",
            "timeout": 60,
        }
        history_store = MagicMock()

        executor = TaskExecutor(
            registry=registry,
            history_store=history_store,
            worker_getter=MagicMock(),
        )
        assert executor._task_pool is None

        # Mock execute_task 避免实际执行
        executor.execute_task = MagicMock(return_value=(True, "ok"))
        executor.execute_task_async("test")

        assert executor._task_pool is not None

    def test_shutdown_without_task_pool(self, tmp_path):
        """无 _task_pool 时 shutdown 不报错。"""
        from app.services.task_executor import TaskExecutor

        registry = MagicMock()
        history_store = MagicMock()

        executor = TaskExecutor(
            registry=registry,
            history_store=history_store,
            worker_getter=MagicMock(),
        )
        assert executor._task_pool is None
        # 不应抛出异常
        executor.shutdown()
```

- [ ] **Step 2: 运行测试验证失败**

Run: `pytest tests/test_services/test_task_executor_fix.py::TestTaskPoolLazyInit -v`
Expected: FAIL（`_task_pool` 不是 `None`）

- [ ] **Step 3: 修改 `__init__` — `_task_pool` 初始为 `None`**

`app/services/task_executor.py` 第 127-132 行：

```python
        # 双线程池
        self._login_pool = ThreadPoolExecutor(
            max_workers=1,
            thread_name_prefix="login-exec",
        )
        self._task_pool = BoundedExecutor(max_workers=2, queue_size=50)
```

改为：

```python
        # 线程池：登录池立即创建，任务池懒初始化（无定时任务时不创建线程）
        self._login_pool = ThreadPoolExecutor(
            max_workers=1,
            thread_name_prefix="login-exec",
        )
        self._task_pool: BoundedExecutor | None = None
```

- [ ] **Step 4: 新增 `_ensure_task_pool` 方法**

`app/services/task_executor.py` 在 `set_runtime_config_getter` 方法之后添加：

```python
    def _ensure_task_pool(self) -> BoundedExecutor:
        """确保定时任务线程池存在（懒初始化）。"""
        if self._task_pool is None:
            self._task_pool = BoundedExecutor(max_workers=2, queue_size=50)
        return self._task_pool
```

- [ ] **Step 5: 修改 `execute_task_async` 使用懒初始化**

`app/services/task_executor.py` 第 178-187 行：

```python
    def execute_task_async(self, task_id: str) -> Future:
        """异步执行定时任务（提交到 task_pool）。

        Returns:
            Future 对象，调用方可选择等待结果

        Raises:
            RuntimeError: 任务队列已满
        """
        return self._task_pool.submit(self.execute_task, task_id)
```

改为：

```python
    def execute_task_async(self, task_id: str) -> Future:
        """异步执行定时任务（提交到 task_pool）。

        Returns:
            Future 对象，调用方可选择等待结果

        Raises:
            RuntimeError: 任务队列已满
        """
        return self._ensure_task_pool().submit(self.execute_task, task_id)
```

- [ ] **Step 6: 修改 `shutdown` 检查池是否存在**

`app/services/task_executor.py` 第 506-511 行：

```python
    def shutdown(self, wait: bool = True) -> None:
        """关闭两个线程池。"""
        logger.info("TaskExecutor 开始关闭...")
        self._task_pool.shutdown(wait=wait)
        self._login_pool.shutdown(wait=wait)
        logger.info("TaskExecutor 已关闭")
```

改为：

```python
    def shutdown(self, wait: bool = True) -> None:
        """关闭线程池。"""
        logger.info("TaskExecutor 开始关闭...")
        if self._task_pool is not None:
            self._task_pool.shutdown(wait=wait)
        self._login_pool.shutdown(wait=wait)
        logger.info("TaskExecutor 已关闭")
```

- [ ] **Step 7: 更新类文档字符串**

`app/services/task_executor.py` 第 101-109 行：

```python
class TaskExecutor:
    """任务执行中心 — 双线程池 + 登录去重。

    Attributes:
        _login_pool: 登录专用线程池（1 个工作线程）
        _task_pool: 定时任务线程池（2 个工作线程，队列上限 50）
        _login_future: 当前登录 Future，用于去重
        _login_lock: 保护 _login_future 的锁
    """
```

改为：

```python
class TaskExecutor:
    """任务执行中心 — 双线程池 + 登录去重。

    Attributes:
        _login_pool: 登录专用线程池（1 个工作线程，立即创建）
        _task_pool: 定时任务线程池（懒初始化，无定时任务时不创建）
        _login_future: 当前登录 Future，用于去重
        _login_lock: 保护 _login_future 的锁
    """
```

- [ ] **Step 8: 运行测试验证通过**

Run: `pytest tests/test_services/test_task_executor_fix.py::TestTaskPoolLazyInit -v`
Expected: PASS

- [ ] **Step 9: 运行全量测试确保无回归**

Run: `pytest tests/ -v --tb=short -q`
Expected: 全部 PASS

- [ ] **Step 10: 提交**

```bash
git add app/services/task_executor.py tests/test_services/test_task_executor_fix.py
git commit -m "perf: 定时任务线程池懒初始化，无任务时不创建线程"
```

---

## 自检清单

- [x] **规格覆盖：** 懒初始化、首次使用创建、shutdown 安全检查
- [x] **占位符扫描：** 无 TBD/TODO，所有代码完整
- [x] **类型一致性：** `_task_pool: BoundedExecutor | None` 类型正确
- [x] **测试覆盖：** 初始为 None、首次使用创建、shutdown 安全
