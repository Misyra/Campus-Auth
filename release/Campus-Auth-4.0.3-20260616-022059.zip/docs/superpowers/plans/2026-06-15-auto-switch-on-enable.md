# 开启自动切换时立即检测实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use subagent-driven-development (recommended) or executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 开启自动切换开关时，立即进行一次网络检测并切换到匹配的方案

**Architecture:** 修改 `toggle_auto_switch` API，开启时触发一次 `_check_profile_switch()` 检测

**Tech Stack:** Python, FastAPI

---

## 文件结构

### 修改的文件
- `app/api/profiles.py` - 修改 toggle_auto_switch 接口

---

### Task 1: 修改 toggle_auto_switch 接口

**Files:**
- Modify: `app/api/profiles.py`

- [ ] **Step 1: 修改 toggle_auto_switch 函数**

在 `app/api/profiles.py` 中，修改 `toggle_auto_switch` 函数：

```python
@router.post("/api/profiles/auto-switch", response_model=ActionResponse)
def toggle_auto_switch(
    enabled: str = Query(default="true"),
    profile_svc: ProfileService = Depends(get_profile_service),
    monitor_svc: ScheduleEngine = Depends(get_monitor_service),
) -> ActionResponse:
    enabled_bool = enabled.strip().lower() in ("true", "1", "yes", "on")
    profile_svc.set_auto_switch(enabled_bool)
    state = "开启" if enabled_bool else "关闭"
    api_logger.info("自动切换 {}", state)

    # 开启自动切换时，立即进行一次检测
    if enabled_bool:
        try:
            # 触发一次方案检测
            matched_id = profile_svc.detect_matching_profile()
            if matched_id:
                data = profile_svc.load()
                if matched_id != data.active_profile:
                    profile = data.profiles.get(matched_id)
                    profile_name = profile.name if profile else matched_id
                    api_logger.info("自动切换检测到匹配方案: {}", profile_name)
                    profile_svc.set_active_profile(matched_id)
                    monitor_svc.apply_profile(matched_id)
                else:
                    api_logger.info("当前方案已匹配，无需切换")
            else:
                api_logger.info("未检测到匹配方案，保持当前方案")
        except Exception as exc:
            api_logger.warning("自动切换检测失败: {}", exc)

    return ActionResponse(success=True, message=f"自动切换已{state}")
```

- [ ] **Step 2: 运行测试**

Run: `PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest tests/test_api/test_api_profiles_routes.py -v`
Expected: 所有测试通过

- [ ] **Step 3: 提交**

```bash
git add app/api/profiles.py
git commit -m "feat: 开启自动切换时立即检测并切换方案"
```

---

## 验证方法

1. 开启自动切换 → 立即检测并切换到匹配方案
2. 开启自动切换但无匹配 → 保持当前方案
3. 关闭自动切换 → 恢复手动切换
4. 当前方案保持 active 样式
5. 其他方案不可点击
