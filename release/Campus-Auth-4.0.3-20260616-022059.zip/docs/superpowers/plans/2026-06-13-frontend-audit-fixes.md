# 前端审查问题修复 实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 修复前端全面审查中发现的 12 个实际问题（2 高优、8 中优、2 低优）

**Architecture:** 纯前端修复，涉及 JS 方法清理、CSS 主题覆盖、HTML 模板交互改进。无后端变更，无新依赖。

**Tech Stack:** Vue 3 (UMD)、原生 CSS、HTML partials

---

## 文件变更总览

| 文件 | 责任 |
|------|------|
| `frontend/js/methods/ui.js` | 删除重复方法定义、修复焦点陷阱泄漏 |
| `frontend/js/app-options.js` | config watcher 优化、编辑器关闭确认逻辑 |
| `frontend/styles/pages/about.css` | color-mix 回退值 |
| `frontend/styles/pages/profiles.css` | 浅色主题 hover 修复 |
| `frontend/styles/pages/logfiles.css` | font-family 改用 CSS 变量 |
| `frontend/styles/base.css` | 浅色主题 border-accent 覆盖 |
| `frontend/styles/pages/scheduled_tasks.css` | failure → failed class 名统一 |
| `frontend/partials/pages/dashboard.html` | 清空日志确认 |
| `frontend/partials/pages/tasks.html` | 编辑器关闭确认 |
| `frontend/partials/pages/scripts.html` | 编辑器关闭确认 |

---

### Task 1: 删除 `ui.js` 重复方法定义

**Files:**
- Modify: `frontend/js/methods/ui.js:46-75`

`uiMethods` 对象中第 46-69 行的 `_showToast` 方法体实际是 `_trapFocus` 的复制粘贴错误代码，第 70-75 行的 `_releaseFocusTrap` 是第 28-33 行的重复定义。JS 对象后定义覆盖前定义，运行结果正确，但 30 行死代码降低可维护性。

- [ ] **Step 1: 读取 ui.js 确认当前结构**

```bash
# 确认第 46-75 行是重复代码
head -80 frontend/js/methods/ui.js
```

预期：第 46 行开始是错误的 `_showToast`（内容为焦点陷阱代码），第 76 行开始是正确的 `_showToast`。

- [ ] **Step 2: 删除第 46-75 行的重复代码**

从 `uiMethods` 对象中删除以下内容：
- 第 46-69 行：错误的 `_showToast` 定义（实际是 `_trapFocus` 代码）
- 第 70-75 行：重复的 `_releaseFocusTrap` 定义

保留正确的：
- 第 28-33 行：正确的 `_releaseFocusTrap`
- 第 76 行起：正确的 `_showToast`

- [ ] **Step 3: 验证文件结构正确**

确认 `uiMethods` 对象中方法定义顺序为：
1. `_trapFocus`
2. `_releaseFocusTrap`
3. `openModal`
4. `closeModal`
5. `_showToast`
6. `toastOnly`
7. 其余方法...

- [ ] **Step 4: 提交**

```bash
git add frontend/js/methods/ui.js
git commit -m "fix: 删除 ui.js 中重复的 _showToast 和 _releaseFocusTrap 定义"
```

---

### Task 2: 修复焦点陷阱监听器泄漏

**Files:**
- Modify: `frontend/js/methods/ui.js:4-6`

`_trapFocus` 向 `document` 注册 `keydown` 监听器，但如果在弹窗未关闭时打开新弹窗（如 `showDangerConfirm` 在编辑器内调用），旧监听器引用丢失无法移除。

- [ ] **Step 1: 在 `_trapFocus` 开头添加旧监听器清理**

在 `_trapFocus` 方法的第一行（`if (!container) return;` 之前）添加：

```javascript
_trapFocus(container) {
    this._releaseFocusTrap(); // 清理旧监听器，防止泄漏
    if (!container) return;
    // ... 其余代码不变
```

- [ ] **Step 2: 验证逻辑**

确认流程：`_trapFocus` → `_releaseFocusTrap()`（清理旧的）→ 注册新的。同一时间只有一个焦点陷阱监听器活跃。

- [ ] **Step 3: 提交**

```bash
git add frontend/js/methods/ui.js
git commit -m "fix: 焦点陷阱在连续打开弹窗时清理旧监听器，防止泄漏"
```

---

### Task 3: 编辑器关闭时添加未保存提醒

**Files:**
- Modify: `frontend/partials/pages/tasks.html:97`
- Modify: `frontend/partials/pages/scripts.html:78`
- Modify: `frontend/js/app-options.js`（添加 computed 或方法）

任务编辑器和脚本编辑器的关闭按钮直接设置 `editingTask = null`，不检查是否有未保存修改。

- [ ] **Step 1: 在 `app-options.js` 中添加 `hasUnsavedChanges` computed**

在 `computed` 部分添加：

```javascript
hasUnsavedChanges() {
  if (this.editingTask) return true; // 有打开的编辑器即视为有未保存
  return false;
},
```

- [ ] **Step 2: 添加 `closeEditor` 方法**

在 `uiMethods`（`frontend/js/methods/ui.js`）中添加：

```javascript
closeEditor() {
  if (this.editingTask && !confirm('当前有未保存的修改，确定要关闭吗？')) return;
  this.editingTask = null;
  this.jsonError = '';
},
```

- [ ] **Step 3: 更新 tasks.html 关闭按钮**

将 `tasks.html` 中任务编辑器的关闭按钮从：
```html
<button ... @click="editingTask = null; jsonError = ''">
```
改为：
```html
<button ... @click="closeEditor">
```

- [ ] **Step 4: 更新 scripts.html 关闭按钮**

将 `scripts.html` 中脚本编辑器的关闭按钮同样改为 `@click="closeEditor"`。

- [ ] **Step 5: 提交**

```bash
git add frontend/js/methods/ui.js frontend/partials/pages/tasks.html frontend/partials/pages/scripts.html
git commit -m "fix: 编辑器关闭时检查未保存修改，防止误操作丢失"
```

---

### Task 4: `about.css` 中 `color-mix()` 添加回退值

**Files:**
- Modify: `frontend/styles/pages/about.css:142-187`

`.tech-badge` 系列全部使用 `color-mix()` 无回退值，旧版 Firefox（< 113）徽章无背景色。

- [ ] **Step 1: 为每个 `color-mix` 规则添加回退行**

示例（`.tech-badge-python`）：

```css
/* 修改前 */
.tech-badge-python {
  background: color-mix(in srgb, #3776ab 12%, transparent);
  border-color: color-mix(in srgb, #3776ab 25%, transparent);
  color: #3776ab;
}

/* 修改后 */
.tech-badge-python {
  background: rgba(55, 118, 171, 0.12);
  background: color-mix(in srgb, #3776ab 12%, transparent);
  border-color: rgba(55, 118, 171, 0.25);
  border-color: color-mix(in srgb, #3776ab 25%, transparent);
  color: #3776ab;
}
```

对所有 `.tech-badge-*` 类执行相同模式：在 `color-mix` 行前添加对应的 `rgba` 回退值。

- [ ] **Step 2: 提交**

```bash
git add frontend/styles/pages/about.css
git commit -m "fix: about.css tech-badge 添加 color-mix 回退值，兼容旧版 Firefox"
```

---

### Task 5: 修复浅色主题下 profiles hover 破相

**Files:**
- Modify: `frontend/styles/pages/profiles.css`

`.profile-card:hover` 使用硬编码深色背景 `rgba(51, 65, 85, 0.4)`，浅色主题下出现深灰色 hover。

- [ ] **Step 1: 将硬编码色改为 CSS 变量**

```css
/* 修改前 */
.profile-card:hover {
  background: rgba(51, 65, 85, 0.4);
}

/* 修改后 */
.profile-card:hover {
  background: var(--bg-hover);
}
```

- [ ] **Step 2: 检查 profiles.css 中其他硬编码深色值**

搜索 `rgba(51, 65, 85` 和 `rgba(30, 41, 59`，将浅色主题下会"破相"的硬编码值替换为对应的 CSS 变量。

- [ ] **Step 3: 提交**

```bash
git add frontend/styles/pages/profiles.css
git commit -m "fix: profiles.css 浅色主题 hover 改用 CSS 变量，修复深色硬编码"
```

---

### Task 6: `logfiles.css` font-family 改用 CSS 变量

**Files:**
- Modify: `frontend/styles/pages/logfiles.css:110`

硬编码 `'Cascadia Code', 'Fira Code', 'Consolas', 'Monaco', monospace` 与 `base.css` 定义的 `--font-mono` 顺序不同且缺少 JetBrains Mono。

- [ ] **Step 1: 替换为 CSS 变量**

```css
/* 修改前 */
font-family: 'Cascadia Code', 'Fira Code', 'Consolas', 'Monaco', monospace;

/* 修改后 */
font-family: var(--font-mono);
```

- [ ] **Step 2: 提交**

```bash
git add frontend/styles/pages/logfiles.css
git commit -m "fix: logfiles.css font-family 改用 --font-mono 变量，统一字体"
```

---

### Task 7: 浅色主题补充 border-accent 变量覆盖

**Files:**
- Modify: `frontend/styles/base.css`（`[data-theme="light"]` 块内）

`--border-accent`、`--border-accent-hover`、`--border-accent-strong`、`--text-tertiary`、`--purple` 在浅色主题下未覆盖。

- [ ] **Step 1: 在 `[data-theme="light"]` 块末尾添加缺失变量**

```css
[data-theme="light"] {
  /* ... 已有变量 ... */
  --border-accent: rgba(56, 189, 248, 0.2);
  --border-accent-hover: rgba(56, 189, 248, 0.3);
  --border-accent-strong: rgba(56, 189, 248, 0.4);
  --text-tertiary: #94a3b8;
  --purple: #8b5cf6;
}
```

- [ ] **Step 2: 提交**

```bash
git add frontend/styles/base.css
git commit -m "fix: 浅色主题补充 border-accent、text-tertiary、purple 变量覆盖"
```

---

### Task 8: 统一 failure/failed class 名

**Files:**
- Modify: `frontend/styles/pages/scheduled_tasks.css:85-89`

`scheduled_tasks.css` 使用 `.failure`，`dashboard.css` 使用 `.failed`。统一为 `failed`。

- [ ] **Step 1: 修改 scheduled_tasks.css**

```css
/* 修改前 */
.scheduled-tasks-page .history-item.failure { ... }

/* 修改后 */
.scheduled-tasks-page .history-item.failed { ... }
```

- [ ] **Step 2: 修改 scheduled_tasks.html 中的 class 绑定**

搜索 `record.status` 绑定，确认后端返回值是 `failure` 还是 `failed`。如果是 `failure`，在前端做映射：

```html
:class="record.status === 'failure' ? 'failed' : record.status"
```

或直接改后端返回值（如果可控）。

- [ ] **Step 3: 提交**

```bash
git add frontend/styles/pages/scheduled_tasks.css frontend/partials/pages/scheduled_tasks.html
git commit -m "fix: 统一 history-item 状态 class 名为 failed"
```

---

### Task 9: Toast 添加队列防覆盖

**Files:**
- Modify: `frontend/js/methods/ui.js`（`_showToast` 方法）

`_showToast` 每次重置定时器并覆盖上一条消息，快速连续操作时前面的提示会被覆盖。

- [ ] **Step 1: 在 `data/ui.js` 中添加 toast 队列**

```javascript
// data/ui.js 中添加
toastQueue: [],
```

- [ ] **Step 2: 修改 `_showToast` 为队列模式**

```javascript
_showToast(success, message) {
  // 如果当前正在显示 toast，排入队列
  if (this.toast.message && !this.toast.leaving) {
    if (this.toastQueue.length < 3) { // 最多排队 3 条
      this.toastQueue.push({ success, message });
    }
    return;
  }
  this._displayToast(success, message);
},
_displayToast(success, message) {
  this.toast = { success, message, leaving: false };
  if (this._toastTimer) clearTimeout(this._toastTimer);
  if (this._toastLeavingTimer) clearTimeout(this._toastLeavingTimer);
  this._toastTimer = setTimeout(() => {
    this.toast.leaving = true;
    this._toastLeavingTimer = setTimeout(() => {
      this.toast.message = '';
      this.toast.leaving = false;
      // 显示队列中的下一条
      if (this.toastQueue.length) {
        const next = this.toastQueue.shift();
        this.$nextTick(() => this._displayToast(next.success, next.message));
      }
    }, TIMING.TOAST_LEAVE_DELAY);
  }, TIMING.TOAST_DURATION);
},
```

- [ ] **Step 3: 提交**

```bash
git add frontend/js/methods/ui.js frontend/js/data/ui.js
git commit -m "fix: Toast 添加队列机制，防止快速连续操作时消息被覆盖"
```

---

### Task 10: 清空日志添加确认提示

**Files:**
- Modify: `frontend/partials/pages/dashboard.html:178`

"清空日志"按钮直接执行 `logs = []`，无确认。

- [ ] **Step 1: 添加 `clearLogs` 方法**

在 `frontend/js/methods/ui.js` 中添加：

```javascript
clearLogs() {
  if (!this.logs.length) return;
  if (!confirm(`确定要清空当前 ${this.logs.length} 条日志显示吗？\n（后端日志文件不受影响）`)) return;
  this.logs = [];
  this.newLogCount = 0;
},
```

- [ ] **Step 2: 修改 dashboard.html 按钮**

```html
<!-- 修改前 -->
@click="logs = []; newLogCount = 0"

<!-- 修改后 -->
@click="clearLogs"
```

- [ ] **Step 3: 提交**

```bash
git add frontend/js/methods/ui.js frontend/partials/pages/dashboard.html
git commit -m "fix: 清空日志添加确认提示，说明后端日志不受影响"
```

---

### Task 11: config watcher 防抖增大

**Files:**
- Modify: `frontend/js/app-options.js:276`

config deep watcher 防抖 150ms，用户逐字输入时每秒触发 2-4 次 `JSON.stringify`。

- [ ] **Step 1: 将防抖从 150ms 增大到 300ms**

```javascript
// 修改前
this._configDirtyTimer = setTimeout(() => { ... }, 150);

// 修改后
this._configDirtyTimer = setTimeout(() => { ... }, 300);
```

- [ ] **Step 2: 提交**

```bash
git add frontend/js/app-options.js
git commit -m "perf: config dirty 检测防抖从 150ms 增大到 300ms，减少 JSON.stringify 频率"
```

---

### Task 12: 日志文件查看器限制从 5000 降到 2000

**Files:**
- Modify: `frontend/js/constants.js:45`

`LOG_FILE_FETCH_LIMIT: 5000` 导致大量 DOM 节点。

- [ ] **Step 1: 修改常量值**

```javascript
// 修改前
LOG_FILE_FETCH_LIMIT: 5000,

// 修改后
LOG_FILE_FETCH_LIMIT: 2000,
```

- [ ] **Step 2: 提交**

```bash
git add frontend/js/constants.js
git commit -m "perf: 日志文件获取限制从 5000 降到 2000，减少 DOM 节点数"
```
