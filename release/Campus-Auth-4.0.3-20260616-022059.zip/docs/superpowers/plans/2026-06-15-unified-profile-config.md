# 统一 Profile 配置实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use subagent-driven-development (recommended) or executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将账号、密码、运营商、任务、认证地址等业务字段从 SystemSettings 移到 ProfileSettings，让 Profile 成为配置的唯一数据源，简化代码逻辑。

**Architecture:**
1. 创建 GlobalSettings 类，只保留系统配置
2. 扩展 ProfileSettings 类，包含所有业务配置
3. 实现迁移逻辑，将旧配置自动迁移到新格式
4. 简化配置加载/保存逻辑，删除 use_global_* 相关代码

**Tech Stack:** Python, Pydantic, FastAPI, Vue.js

---

## 文件结构

### 修改的文件
- `app/schemas.py` - 数据模型定义
- `app/services/runtime_config.py` - 配置加载逻辑
- `app/services/config_service.py` - 配置保存逻辑
- `app/services/profile_service.py` - Profile 服务
- `app/utils/config_utils.py` - 配置工具函数
- `tests/test_schemas.py` - Schema 测试
- `tests/test_services/test_runtime_config.py` - 配置加载测试
- `tests/test_services/test_config_service.py` - 配置保存测试

---

### Task 1: 创建 GlobalSettings 类

**Files:**
- Modify: `app/schemas.py`
- Test: `tests/test_schemas.py`

- [ ] **Step 1: 创建 GlobalSettings 类**

在 `app/schemas.py` 中，在 `_SystemFieldsMixin` 之后添加：

```python
class GlobalSettings(BaseModel):
    """全局系统配置 — 仅系统级设置，不包含业务逻辑"""

    # 日志配置
    backend_log_level: str = Field(default="INFO")
    frontend_log_level: str = Field(default="INFO")
    access_log: bool = Field(default=False, description="Uvicorn HTTP 请求日志")
    log_retention_days: int = Field(default=7, ge=1, le=365, description="日志保留天数")

    # UI 配置
    minimize_to_tray: bool = Field(default=True, description="最小化到系统托盘")
    auto_open_browser: bool = Field(default=False, description="启动后自动打开浏览器")
    startup_action: StartupAction = Field(default=StartupAction.NONE)
    autostart_lightweight: bool = Field(default=True)

    # 网络配置
    proxy: str = Field(default="", description="网络代理地址")
    block_proxy: bool = Field(default=True, description="屏蔽系统代理")

    # 应用配置
    app_port: int = Field(default=50721, ge=1024, le=65535)
    shell_path: str = Field(default="", description="自定义 Shell 路径")
    pure_mode: bool = Field(default=True, description="纯净模式")

    # 重试配置
    max_retries: int = Field(default=3, ge=0, le=10)
    retry_interval: int = Field(default=5, ge=1, le=300, description="重试间隔（秒）")

    # Source 级别配置
    source_levels: dict[str, str] = {}

    @field_validator("backend_log_level", "frontend_log_level")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        v = v.upper().strip()
        if v and v not in VALID_LOG_LEVELS:
            raise ValueError(
                f"无效的日志级别: {v}，可选值: {', '.join(VALID_LOG_LEVELS)}"
            )
        return v
```

- [ ] **Step 2: 添加测试**

在 `tests/test_schemas.py` 中添加：

```python
class TestGlobalSettings:
    def test_default_values(self):
        """测试默认值"""
        settings = GlobalSettings()
        assert settings.backend_log_level == "INFO"
        assert settings.frontend_log_level == "INFO"
        assert settings.access_log is False
        assert settings.log_retention_days == 7
        assert settings.minimize_to_tray is True
        assert settings.auto_open_browser is False
        assert settings.proxy == ""
        assert settings.block_proxy is True
        assert settings.app_port == 50721
        assert settings.pure_mode is True
        assert settings.max_retries == 3
        assert settings.retry_interval == 5

    def test_custom_values(self):
        """测试自定义值"""
        settings = GlobalSettings(
            backend_log_level="DEBUG",
            app_port=8080,
            max_retries=5,
        )
        assert settings.backend_log_level == "DEBUG"
        assert settings.app_port == 8080
        assert settings.max_retries == 5

    def test_invalid_log_level(self):
        """测试无效日志级别"""
        with pytest.raises(ValueError, match="无效的日志级别"):
            GlobalSettings(backend_log_level="INVALID")

    def test_log_level_normalization(self):
        """测试日志级别归一化"""
        settings = GlobalSettings(backend_log_level="debug")
        assert settings.backend_log_level == "DEBUG"
```

- [ ] **Step 3: 运行测试**

Run: `PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest tests/test_schemas.py::TestGlobalSettings -v`
Expected: 所有测试通过

- [ ] **Step 4: 提交**

```bash
git add app/schemas.py tests/test_schemas.py
git commit -m "feat: 添加 GlobalSettings 类"
```

---

### Task 2: 扩展 ProfileSettings 类

**Files:**
- Modify: `app/schemas.py`
- Test: `tests/test_schemas.py`

- [ ] **Step 1: 扩展 ProfileSettings 类**

在 `app/schemas.py` 中，修改 `ProfileSettings` 类，添加浏览器配置字段：

```python
class ProfileSettings(BaseModel):
    """方案配置 — 所有业务配置的唯一数据源"""

    # 基本信息
    name: str = Field(default="默认方案")
    match_gateway_ip: str = Field(default="", description="匹配的网关 IP")
    match_ssid: str = Field(default="", description="匹配的 WiFi SSID")

    # 凭证配置
    username: str = Field(default="", description="校园网用户名")
    password: str = Field(default="", description="校园网密码（加密存储）")
    carrier: str = Field(default="无", description="运营商")
    carrier_custom: str = Field(default="", description="自定义运营商关键字")
    auth_url: str = Field(default="", description="认证地址")
    active_task: str = Field(default="", description="活动任务")

    # 监控配置
    check_interval_seconds: int = Field(default=300, ge=10, le=86400)
    pause_enabled: bool = Field(default=True)
    pause_start_hour: int = Field(default=0, ge=0, le=23)
    pause_end_hour: int = Field(default=6, ge=0, le=23)
    network_targets: str = Field(default=DEFAULT_NETWORK_TARGETS)
    http_targets: str = Field(default=DEFAULT_HTTP_TARGETS)
    enable_tcp_check: bool = Field(default=False)
    enable_http_check: bool = Field(default=False)
    enable_local_check: bool = Field(default=True)
    check_auth_url: bool = Field(default=False)
    auth_url_targets: str = Field(default="")
    url_check_urls: str = Field(default="http://captive.apple.com/hotspot-detect.html|Success\nhttp://www.msftconnecttest.com/connecttest.txt|Microsoft Connect Test\nhttp://detectportal.firefox.com/success.txt|success")
    network_check_timeout: int = Field(default=2, ge=1, le=30)

    # 浏览器配置
    headless: bool = Field(default=True)
    browser_timeout: int = Field(default=8, ge=1, le=60)
    browser_navigation_timeout: int = Field(default=30, ge=1, le=120)
    login_timeout: int = Field(default=60, ge=10, le=600)
    browser_user_agent: str = Field(default="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36")
    browser_low_resource_mode: bool = Field(default=False)
    browser_disable_web_security: bool = Field(default=False)
    browser_extra_headers_json: str = Field(default="")
    browser_args: str = Field(default=BROWSER_ARGS_DEFAULT)
    stealth_mode: bool = Field(default=False)
    stealth_custom_script: str = Field(default="")
    browser_locale: str = Field(default="zh-CN")
    browser_timezone: str = Field(default="Asia/Shanghai")
    browser_viewport_width: int = Field(default=1280)
    browser_viewport_height: int = Field(default=720)

    # 自定义变量
    custom_variables: dict[str, str] = Field(default_factory=dict)

    @field_validator("auth_url")
    @classmethod
    def validate_auth_url(cls, v: str) -> str:
        return _validate_auth_url(v)

    @field_validator("browser_extra_headers_json")
    @classmethod
    def validate_extra_headers_json(cls, v: str) -> str:
        if not v.strip():
            return ""
        try:
            parsed = json.loads(v)
        except json.JSONDecodeError as e:
            raise ValueError(
                f"浏览器请求头格式不正确，请确认输入的是合法的 JSON 对象: {e}"
            ) from e
        if not isinstance(parsed, dict):
            raise ValueError(
                '浏览器请求头格式不正确，应为键值对形式，例如: {"Referer": "https://example.com"}'
            )
        return json.dumps(parsed, ensure_ascii=False, separators=(",", ":"))
```

- [ ] **Step 2: 添加测试**

在 `tests/test_schemas.py` 中添加：

```python
class TestProfileSettings:
    def test_default_values(self):
        """测试默认值"""
        profile = ProfileSettings()
        assert profile.name == "默认方案"
        assert profile.username == ""
        assert profile.password == ""
        assert profile.carrier == "无"
        assert profile.auth_url == ""
        assert profile.check_interval_seconds == 300
        assert profile.pause_enabled is True
        assert profile.headless is True
        assert profile.browser_timeout == 8

    def test_custom_values(self):
        """测试自定义值"""
        profile = ProfileSettings(
            name="测试方案",
            username="testuser",
            password="testpass",
            carrier="移动",
            auth_url="http://example.com",
            check_interval_seconds=600,
            headless=False,
        )
        assert profile.name == "测试方案"
        assert profile.username == "testuser"
        assert profile.password == "testpass"
        assert profile.carrier == "移动"
        assert profile.auth_url == "http://example.com"
        assert profile.check_interval_seconds == 600
        assert profile.headless is False

    def test_invalid_auth_url(self):
        """测试无效认证地址"""
        with pytest.raises(ValueError, match="认证地址格式不正确"):
            ProfileSettings(auth_url="not-a-url")
```

- [ ] **Step 3: 运行测试**

Run: `PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest tests/test_schemas.py::TestProfileSettings -v`
Expected: 所有测试通过

- [ ] **Step 4: 提交**

```bash
git add app/schemas.py tests/test_schemas.py
git commit -m "feat: 扩展 ProfileSettings 类，添加浏览器配置字段"
```

---

### Task 3: 更新 ProfilesData 类

**Files:**
- Modify: `app/schemas.py`
- Test: `tests/test_schemas.py`

- [ ] **Step 1: 更新 ProfilesData 类**

在 `app/schemas.py` 中，修改 `ProfilesData` 类：

```python
class ProfilesData(BaseModel):
    """Top-level structure of settings.json"""

    auto_switch: bool = Field(default=False, description="是否根据网关 IP 自动切换方案")
    active_profile: str = Field(default="default")
    global_settings: GlobalSettings = Field(default_factory=GlobalSettings)
    profiles: dict[str, ProfileSettings] = Field(default_factory=dict)

    @model_validator(mode="after")
    def ensure_default_profile(self) -> "ProfilesData":
        """确保 default profile 存在"""
        if "default" not in self.profiles:
            self.profiles["default"] = ProfileSettings()
        return self
```

- [ ] **Step 2: 添加测试**

在 `tests/test_schemas.py` 中添加：

```python
class TestProfilesData:
    def test_default_profile_auto_created(self):
        """测试自动创建 default profile"""
        data = ProfilesData()
        assert "default" in data.profiles
        assert data.profiles["default"].name == "默认方案"

    def test_global_settings_default(self):
        """测试 GlobalSettings 默认值"""
        data = ProfilesData()
        assert isinstance(data.global_settings, GlobalSettings)
        assert data.global_settings.backend_log_level == "INFO"

    def test_custom_profiles(self):
        """测试自定义 profiles"""
        data = ProfilesData(
            profiles={
                "default": ProfileSettings(name="默认"),
                "custom": ProfileSettings(name="自定义"),
            }
        )
        assert len(data.profiles) == 2
        assert data.profiles["default"].name == "默认"
        assert data.profiles["custom"].name == "自定义"
```

- [ ] **Step 3: 运行测试**

Run: `PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest tests/test_schemas.py::TestProfilesData -v`
Expected: 所有测试通过

- [ ] **Step 4: 提交**

```bash
git add app/schemas.py tests/test_schemas.py
git commit -m "feat: 更新 ProfilesData 类，使用 GlobalSettings 替代 SystemSettings"
```

---

### Task 4: 实现迁移逻辑

**Files:**
- Modify: `app/services/runtime_config.py`
- Test: `tests/test_services/test_runtime_config.py`

- [ ] **Step 1: 实现迁移函数**

在 `app/services/runtime_config.py` 中添加：

```python
def migrate_config_if_needed(data: ProfilesData) -> ProfilesData:
    """迁移旧配置到新格式

    将 SystemSettings 中的凭证迁移到 default profile。
    """
    from app.utils.logging import get_logger
    logger = get_logger("config_migration", source="backend")

    # 检查是否有旧的 system 字段需要迁移
    # 注意：旧格式使用 data.system，新格式使用 data.global_settings
    if not hasattr(data, 'system'):
        return data

    system = data.system

    # 检查是否有凭证需要迁移
    has_credentials = any([
        getattr(system, 'username', None),
        getattr(system, 'password', None),
        getattr(system, 'auth_url', None),
        getattr(system, 'carrier', None) and getattr(system, 'carrier', None) != "无",
        getattr(system, 'active_task', None),
    ])

    if has_credentials:
        # 确保 default profile 存在
        if "default" not in data.profiles:
            data.profiles["default"] = ProfileSettings()

        default_profile = data.profiles["default"]

        # 迁移凭证到 default profile
        if getattr(system, 'username', None) and not default_profile.username:
            default_profile.username = system.username
        if getattr(system, 'password', None) and not default_profile.password:
            default_profile.password = system.password
        if getattr(system, 'auth_url', None) and not default_profile.auth_url:
            default_profile.auth_url = system.auth_url
        if getattr(system, 'carrier', None) and system.carrier != "无":
            default_profile.carrier = system.carrier
            default_profile.carrier_custom = getattr(system, 'carrier_custom', '')
        if getattr(system, 'active_task', None) and not default_profile.active_task:
            default_profile.active_task = system.active_task

        # 清空 system 中的凭证
        system.username = ""
        system.password = ""
        system.auth_url = ""
        system.carrier = "无"
        system.carrier_custom = ""
        system.active_task = ""

        logger.info("已迁移凭证到 default profile")

    return data
```

- [ ] **Step 2: 添加测试**

在 `tests/test_services/test_runtime_config.py` 中添加：

```python
class TestMigrateConfig:
    def test_migrate_credentials_to_default_profile(self):
        """测试迁移凭证到 default profile"""
        from app.services.runtime_config import migrate_config_if_needed
        from app.schemas import ProfilesData, ProfileSettings, SystemSettings

        # 创建旧格式的数据
        system = SystemSettings()
        system.username = "testuser"
        system.password = "testpass"
        system.auth_url = "http://example.com"
        system.carrier = "移动"

        data = ProfilesData(system=system)

        # 执行迁移
        result = migrate_config_if_needed(data)

        # 验证迁移结果
        assert result.profiles["default"].username == "testuser"
        assert result.profiles["default"].password == "testpass"
        assert result.profiles["default"].auth_url == "http://example.com"
        assert result.profiles["default"].carrier == "移动"

        # 验证 system 中的凭证已清空
        assert result.system.username == ""
        assert result.system.password == ""
        assert result.system.auth_url == ""
        assert result.system.carrier == "无"

    def test_no_migration_if_no_credentials(self):
        """测试没有凭证时不执行迁移"""
        from app.services.runtime_config import migrate_config_if_needed
        from app.schemas import ProfilesData, SystemSettings

        system = SystemSettings()
        data = ProfilesData(system=system)

        result = migrate_config_if_needed(data)

        # 验证没有变化
        assert result.profiles["default"].username == ""

    def test_migration_preserves_existing_profile(self):
        """测试迁移保留现有 profile 配置"""
        from app.services.runtime_config import migrate_config_if_needed
        from app.schemas import ProfilesData, ProfileSettings, SystemSettings

        system = SystemSettings()
        system.username = "global_user"
        system.password = "global_pass"

        existing_profile = ProfileSettings(
            username="profile_user",
            password="profile_pass",
        )

        data = ProfilesData(
            system=system,
            profiles={"default": existing_profile},
        )

        result = migrate_config_if_needed(data)

        # 验证保留了现有的 profile 配置
        assert result.profiles["default"].username == "profile_user"
        assert result.profiles["default"].password == "profile_pass"
```

- [ ] **Step 3: 运行测试**

Run: `PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest tests/test_services/test_runtime_config.py::TestMigrateConfig -v`
Expected: 所有测试通过

- [ ] **Step 4: 提交**

```bash
git add app/services/runtime_config.py tests/test_services/test_runtime_config.py
git commit -m "feat: 实现配置迁移逻辑"
```

---

### Task 5: 简化配置加载逻辑

**Files:**
- Modify: `app/services/runtime_config.py`
- Test: `tests/test_services/test_runtime_config.py`

- [ ] **Step 1: 简化 _build_config_payload 函数**

在 `app/services/runtime_config.py` 中，重写 `_build_config_payload` 函数：

```python
def _build_config_payload(
    profile_service: ProfileService,
    data: ProfilesData | None = None,
    *,
    apply_overrides: bool = False,
) -> tuple[MonitorConfigPayload, bool]:
    """构建配置 payload 的通用逻辑。

    Args:
        profile_service: 方案服务
        data: 已加载的方案数据（为 None 时自动加载）
        apply_overrides: 是否应用活动方案的覆盖值（运行时配置）

    Returns:
        (MonitorConfigPayload, has_decrypt_error)
    """
    if data is None:
        data = profile_service.load()

    # 执行迁移（如果需要）
    data = migrate_config_if_needed(data)

    # 获取活动 profile
    profile = data.profiles.get(data.active_profile)
    if profile is None:
        profile = data.profiles.get("default", ProfileSettings())

    config_logger.debug("加载配置: profile={}", data.active_profile)

    # 从 profile 构建 payload
    payload_dict = profile.model_dump()

    # 处理密码
    any_error = False
    if apply_overrides:
        pwd, err = _decrypt_password_field(profile.password)
        payload_dict["password"] = pwd
        any_error = err
    else:
        payload_dict["password"] = mask_password(profile.password)

    # 合并 global_settings 中的系统配置
    payload_dict.update({
        "backend_log_level": data.global_settings.backend_log_level,
        "frontend_log_level": data.global_settings.frontend_log_level,
        "access_log": data.global_settings.access_log,
        "log_retention_days": data.global_settings.log_retention_days,
        "minimize_to_tray": data.global_settings.minimize_to_tray,
        "auto_open_browser": data.global_settings.auto_open_browser,
        "startup_action": data.global_settings.startup_action,
        "autostart_lightweight": data.global_settings.autostart_lightweight,
        "proxy": data.global_settings.proxy,
        "block_proxy": data.global_settings.block_proxy,
        "app_port": data.global_settings.app_port,
        "shell_path": data.global_settings.shell_path,
        "pure_mode": data.global_settings.pure_mode,
        "max_retries": data.global_settings.max_retries,
        "retry_interval": data.global_settings.retry_interval,
        "source_levels": data.global_settings.source_levels,
    })

    # 归一化
    payload_dict["backend_log_level"] = normalize_level(
        payload_dict.get("backend_log_level", "INFO"), "WARNING"
    )
    payload_dict["frontend_log_level"] = normalize_level(
        payload_dict.get("frontend_log_level", "INFO"), "WARNING"
    )

    result = MonitorConfigPayload(**payload_dict)
    return (result, any_error)
```

- [ ] **Step 2: 运行测试**

Run: `PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest tests/test_services/test_runtime_config.py -v`
Expected: 所有测试通过

- [ ] **Step 3: 提交**

```bash
git add app/services/runtime_config.py
git commit -m "refactor: 简化配置加载逻辑，删除 use_global_* 相关代码"
```

---

### Task 6: 简化配置保存逻辑

**Files:**
- Modify: `app/services/config_service.py`
- Test: `tests/test_services/test_config_service.py`

- [ ] **Step 1: 简化 _update_system_settings 函数**

在 `app/services/config_service.py` 中，重写 `_update_system_settings` 函数为 `_update_global_settings`：

```python
def _update_global_settings(
    global_settings: GlobalSettings, payload: MonitorConfigPayload
) -> None:
    """更新全局系统设置（不包含凭证）"""
    global_settings.backend_log_level = normalize_level(
        payload.backend_log_level, "WARNING"
    )
    global_settings.frontend_log_level = normalize_level(
        payload.frontend_log_level, "WARNING"
    )
    global_settings.access_log = payload.access_log
    global_settings.log_retention_days = payload.log_retention_days
    global_settings.minimize_to_tray = payload.minimize_to_tray
    global_settings.auto_open_browser = payload.auto_open_browser
    global_settings.startup_action = payload.startup_action
    global_settings.autostart_lightweight = payload.autostart_lightweight
    global_settings.proxy = payload.proxy.strip()
    global_settings.block_proxy = payload.block_proxy
    global_settings.app_port = payload.app_port
    global_settings.shell_path = payload.shell_path
    global_settings.pure_mode = payload.pure_mode
    global_settings.max_retries = payload.max_retries
    global_settings.retry_interval = payload.retry_interval
```

- [ ] **Step 2: 更新 save_config_combined 函数**

在 `app/services/config_service.py` 中，更新 `save_config_combined` 函数：

```python
def save_config_combined(
    payload: MonitorConfigPayload,
    profile_service: ProfileService,
) -> None:
    """原子化保存配置到活动 profile 和 global_settings。"""

    def _apply(data: ProfilesData) -> None:
        # 更新全局设置（不包含凭证）
        _update_global_settings(data.global_settings, payload)

        # 确保活动 profile 存在
        active_profile = data.active_profile
        if active_profile not in data.profiles:
            data.profiles[active_profile] = ProfileSettings()
            config_logger.info("已自动初始化活动方案: {}", active_profile)

        # 更新活动 profile
        profile = data.profiles[active_profile]

        # 更新凭证
        from app.utils.crypto import save_password_field
        profile.username = payload.username.strip()
        pwd_raw = payload.password.strip()
        if pwd_raw and not pwd_raw.startswith("•"):
            profile.password = save_password_field(pwd_raw, profile.password)
        profile.auth_url = payload.auth_url.strip()
        profile.carrier = str(payload.carrier or "无").strip()
        profile.carrier_custom = str(payload.carrier_custom or "").strip()
        profile.active_task = payload.active_task.strip()

        # 更新监控配置
        profile.check_interval_seconds = payload.check_interval_seconds
        profile.pause_enabled = payload.pause_enabled
        profile.pause_start_hour = payload.pause_start_hour
        profile.pause_end_hour = payload.pause_end_hour
        profile.network_targets = payload.network_targets
        profile.http_targets = payload.http_targets
        profile.enable_tcp_check = payload.enable_tcp_check
        profile.enable_http_check = payload.enable_http_check
        profile.enable_local_check = payload.enable_local_check
        profile.check_auth_url = payload.check_auth_url
        profile.auth_url_targets = payload.auth_url_targets
        profile.url_check_urls = payload.url_check_urls
        profile.network_check_timeout = payload.network_check_timeout

        # 更新浏览器配置
        profile.headless = payload.headless
        profile.browser_timeout = payload.browser_timeout
        profile.browser_navigation_timeout = payload.browser_navigation_timeout
        profile.login_timeout = payload.login_timeout
        profile.browser_user_agent = payload.browser_user_agent
        profile.browser_low_resource_mode = payload.browser_low_resource_mode
        profile.browser_disable_web_security = payload.browser_disable_web_security
        profile.browser_extra_headers_json = payload.browser_extra_headers_json
        profile.browser_args = payload.browser_args
        profile.stealth_mode = payload.stealth_mode
        profile.stealth_custom_script = payload.stealth_custom_script
        profile.browser_locale = payload.browser_locale
        profile.browser_timezone = payload.browser_timezone
        profile.browser_viewport_width = payload.browser_viewport_width
        profile.browser_viewport_height = payload.browser_viewport_height

        # 更新自定义变量
        profile.custom_variables = payload.custom_variables

        config_logger.info(
            "配置已保存: profile={}, 用户={}",
            active_profile,
            profile.username,
        )

    profile_service.update(_apply)
```

- [ ] **Step 3: 运行测试**

Run: `PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest tests/test_services/test_config_service.py -v`
Expected: 所有测试通过

- [ ] **Step 4: 提交**

```bash
git add app/services/config_service.py
git commit -m "refactor: 简化配置保存逻辑，凭证保存到 profile"
```

---

### Task 7: 更新 ProfileService

**Files:**
- Modify: `app/services/profile_service.py`
- Test: `tests/test_services/test_profile_service.py`

- [ ] **Step 1: 更新 load 方法**

在 `app/services/profile_service.py` 中，确保 `load` 方法返回 `ProfilesData`：

```python
def load(self) -> ProfilesData:
    """加载配置数据"""
    if not self._settings_path.exists():
        return ProfilesData()

    try:
        data = json.loads(self._settings_path.read_text(encoding="utf-8"))
        return ProfilesData.model_validate(data)
    except Exception as e:
        logger.error("加载配置失败: {}", e)
        return ProfilesData()
```

- [ ] **Step 2: 更新 save 方法**

在 `app/services/profile_service.py` 中，确保 `save` 方法保存 `ProfilesData`：

```python
def save(self, data: ProfilesData) -> None:
    """保存配置数据"""
    self._settings_path.write_text(
        data.model_dump_json(indent=2),
        encoding="utf-8",
    )
```

- [ ] **Step 3: 运行测试**

Run: `PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest tests/test_services/test_profile_service.py -v`
Expected: 所有测试通过

- [ ] **Step 4: 提交**

```bash
git add app/services/profile_service.py
git commit -m "refactor: 更新 ProfileService 支持新的 ProfilesData 结构"
```

---

### Task 8: 更新 config_utils

**Files:**
- Modify: `app/utils/config_utils.py`
- Test: `tests/test_utils/test_config_utils.py`

- [ ] **Step 1: 更新 PROFILE_FIELDS**

在 `app/utils/config_utils.py` 中，更新 `PROFILE_FIELDS` 常量：

```python
# ProfileSettings 中的所有字段
PROFILE_FIELDS: tuple[str, ...] = (
    "username",
    "password",
    "auth_url",
    "carrier",
    "carrier_custom",
    "active_task",
    "check_interval_seconds",
    "headless",
    "browser_timeout",
    "browser_navigation_timeout",
    "login_timeout",
    "browser_user_agent",
    "browser_low_resource_mode",
    "browser_disable_web_security",
    "browser_extra_headers_json",
    "browser_args",
    "stealth_mode",
    "stealth_custom_script",
    "browser_locale",
    "browser_timezone",
    "pause_enabled",
    "pause_start_hour",
    "pause_end_hour",
    "network_targets",
    "http_targets",
    "enable_tcp_check",
    "enable_http_check",
    "enable_local_check",
    "check_auth_url",
    "auth_url_targets",
    "url_check_urls",
    "custom_variables",
    "block_proxy",
    "network_check_timeout",
    "browser_viewport_width",
    "browser_viewport_height",
)

# GlobalSettings 中的字段
GLOBAL_FIELDS: tuple[str, ...] = (
    "backend_log_level",
    "frontend_log_level",
    "access_log",
    "log_retention_days",
    "minimize_to_tray",
    "auto_open_browser",
    "startup_action",
    "autostart_lightweight",
    "proxy",
    "app_port",
    "shell_path",
    "pure_mode",
    "max_retries",
    "retry_interval",
    "source_levels",
)
```

- [ ] **Step 2: 运行测试**

Run: `PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest tests/test_utils/test_config_utils.py -v`
Expected: 所有测试通过

- [ ] **Step 3: 提交**

```bash
git add app/utils/config_utils.py
git commit -m "refactor: 更新 PROFILE_FIELDS 和 GLOBAL_FIELDS"
```

---

### Task 9: 运行所有测试并验证

- [ ] **Step 1: 运行所有测试**

Run: `PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest -q`
Expected: 所有测试通过

- [ ] **Step 2: 运行代码检查**

Run: `./.venv/Scripts/python.exe -m ruff check app/schemas.py app/services/runtime_config.py app/services/config_service.py app/services/profile_service.py app/utils/config_utils.py`
Expected: 无错误

- [ ] **Step 3: 更新修改日志**

在 `dev/change.md` 中添加修改记录：

```markdown
## 2026-06-15

### refactor
- 统一 Profile 配置架构
  - 创建 GlobalSettings 类，只保留系统配置
  - 扩展 ProfileSettings 类，包含所有业务配置
  - 删除 use_global_* 标志
  - 简化配置加载/保存逻辑
  - 实现自动迁移逻辑
```

- [ ] **Step 4: 最终提交**

```bash
git add dev/change.md
git commit -m "docs: 更新修改日志"
```

---

## 验证方法

1. 启动应用，检查配置是否正确加载
2. 修改凭证配置，保存后检查是否正确持久化
3. 切换方案，检查凭证是否正确切换
4. 检查旧配置是否正确迁移到新格式
5. 运行所有测试，确保无回归
