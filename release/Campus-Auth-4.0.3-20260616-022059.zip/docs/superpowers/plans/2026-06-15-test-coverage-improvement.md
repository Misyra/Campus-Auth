# 测试覆盖率改进实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use subagent-driven-development (recommended) or executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将整体测试覆盖率从 77% 提升至 85%+，重点补充核心模块的单元测试和集成测试

**Architecture:** 采用分层递进法，按模块依赖关系自底向上补充测试。第一层工具函数，第二层核心服务，第三层集成测试。使用 Mock 隔离外部依赖，确保测试快速可靠。

**Tech Stack:** pytest, pytest-asyncio, pytest-cov, unittest.mock, tmp_path

---

## 文件结构

### 新增文件
- `tests/test_utils/test_ports.py` - 端口工具测试
- `tests/test_utils/test_retry.py` - 重试工具测试
- `tests/test_services/test_engine.py` - 调度引擎测试
- `tests/test_services/test_debug_service.py` - 调试服务测试
- `tests/test_services/test_login_history_service.py` - 登录历史服务测试
- `tests/test_services/test_websocket_manager.py` - WebSocket 管理器测试
- `tests/test_integration/test_app_startup.py` - 应用启动集成测试
- `tests/test_integration/test_login_flow.py` - 登录流程集成测试
- `tests/test_integration/test_scheduled_task.py` - 定时任务集成测试

### 修改文件
- `tests/test_utils/test_crypto.py` - 提升加密工具覆盖率
- `tests/test_utils/test_login.py` - 提升登录工具覆盖率
- `tests/test_utils/test_process.py` - 提升进程工具覆盖率
- `tests/test_services/test_task_executor.py` - 提升任务执行器覆盖率

---

## 第一层：工具函数测试

### Task 1: 端口工具测试 (ports.py)

**Files:**
- Create: `tests/test_utils/test_ports.py`
- Source: `app/utils/ports.py`

- [ ] **Step 1: 查看源码了解接口**

```bash
cat app/utils/ports.py
```

- [ ] **Step 2: 创建测试文件框架**

```python
"""app/utils/ports.py 的单元测试"""

import socket
from unittest.mock import MagicMock, patch

import pytest

from app.utils.ports import resolve_port, is_port_available


class TestResolvePort:
    """测试 resolve_port 函数"""

    def test_resolve_port_default_range(self):
        """测试默认端口范围分配"""
        # 测试在默认范围内找到可用端口
        pass

    def test_resolve_port_custom_range(self):
        """测试自定义端口范围"""
        pass

    def test_resolve_port_all_ports_busy(self):
        """测试所有端口都占用时的处理"""
        pass

    def test_resolve_port_first_port_available(self):
        """测试第一个端口就可用的情况"""
        pass


class TestIsPortAvailable:
    """测试 is_port_available 函数"""

    def test_port_available(self):
        """测试端口可用的情况"""
        pass

    def test_port_occupied(self):
        """测试端口被占用的情况"""
        pass

    @pytest.mark.parametrize("port", [80, 443, 8080, 3000])
    def test_various_ports(self, port):
        """参数化测试各种端口"""
        pass
```

- [ ] **Step 3: 运行测试确认框架正确**

```bash
pytest tests/test_utils/test_ports.py -v
```

Expected: 测试文件可以被发现，测试函数被收集（可能因为 pass 而通过）

- [ ] **Step 4: 实现完整测试用例**

```python
"""app/utils/ports.py 的单元测试"""

import socket
from unittest.mock import MagicMock, patch, call

import pytest

from app.utils.ports import resolve_port, is_port_available


class TestResolvePort:
    """测试 resolve_port 函数"""

    @patch("app.utils.ports.is_port_available")
    def test_resolve_port_default_range(self, mock_is_available):
        """测试在默认范围内找到可用端口"""
        # 模拟第一个端口就可用
        mock_is_available.return_value = True

        result = resolve_port()

        # 验证返回了有效端口
        assert result is not None
        assert isinstance(result, int)
        # 验证在默认范围内（通常是 8000-9000）
        assert 8000 <= result <= 9000

    @patch("app.utils.ports.is_port_available")
    def test_resolve_port_custom_range(self, mock_is_available):
        """测试自定义端口范围"""
        mock_is_available.return_value = True

        result = resolve_port(start=3000, end=3010)

        assert result is not None
        assert 3000 <= result <= 3010

    @patch("app.utils.ports.is_port_available")
    def test_resolve_port_first_available(self, mock_is_available):
        """测试找到第一个可用端口"""
        # 模拟前两个端口不可用，第三个可用
        mock_is_available.side_effect = [False, False, True]

        result = resolve_port(start=8000, end=8010)

        assert result == 8002
        assert mock_is_available.call_count == 3

    @patch("app.utils.ports.is_port_available")
    def test_resolve_port_all_busy(self, mock_is_available):
        """测试所有端口都占用时返回 None"""
        mock_is_available.return_value = False

        result = resolve_port(start=8000, end=8005)

        assert result is None

    @patch("app.utils.ports.is_port_available")
    def test_resolve_port_single_port_range(self, mock_is_available):
        """测试单端口范围"""
        mock_is_available.return_value = True

        result = resolve_port(start=8080, end=8080)

        assert result == 8080


class TestIsPortAvailable:
    """测试 is_port_available 函数"""

    @patch("app.utils.ports.socket.socket")
    def test_port_available(self, mock_socket_class):
        """测试端口可用的情况"""
        mock_socket = MagicMock()
        mock_socket_class.return_value = mock_socket
        mock_socket.connect_ex.return_value = 1  # 连接失败表示端口可用

        result = is_port_available(8080)

        assert result is True
        mock_socket.connect_ex.assert_called_once_with(("127.0.0.1", 8080))
        mock_socket.close.assert_called_once()

    @patch("app.utils.ports.socket.socket")
    def test_port_occupied(self, mock_socket_class):
        """测试端口被占用的情况"""
        mock_socket = MagicMock()
        mock_socket_class.return_value = mock_socket
        mock_socket.connect_ex.return_value = 0  # 连接成功表示端口被占用

        result = is_port_available(8080)

        assert result is False

    @patch("app.utils.ports.socket.socket")
    def test_socket_exception(self, mock_socket_class):
        """测试 socket 异常时的处理"""
        mock_socket_class.side_effect = socket.error("Socket error")

        # 根据实现，可能返回 False 或抛出异常
        # 这里假设返回 False
        try:
            result = is_port_available(8080)
            assert result is False
        except socket.error:
            pass  # 如果实现是抛出异常，这也是可接受的

    @pytest.mark.parametrize("port", [80, 443, 8080, 3000, 5000])
    @patch("app.utils.ports.socket.socket")
    def test_various_ports(self, mock_socket_class, port):
        """参数化测试各种端口"""
        mock_socket = MagicMock()
        mock_socket_class.return_value = mock_socket
        mock_socket.connect_ex.return_value = 1

        result = is_port_available(port)

        assert isinstance(result, bool)
        mock_socket.connect_ex.assert_called_once_with(("127.0.0.1", port))
```

- [ ] **Step 5: 运行测试确认全部通过**

```bash
pytest tests/test_utils/test_ports.py -v
```

Expected: 所有测试通过

- [ ] **Step 6: 检查覆盖率**

```bash
pytest tests/test_utils/test_ports.py --cov=app/utils/ports --cov-report=term-missing
```

Expected: 覆盖率 ≥ 85%

- [ ] **Step 7: 提交**

```bash
git add tests/test_utils/test_ports.py
git commit -m "test: 添加 ports.py 单元测试，覆盖端口检测和分配逻辑"
```

---

### Task 2: 重试工具测试 (retry.py)

**Files:**
- Create: `tests/test_utils/test_retry.py`
- Source: `app/utils/retry.py`

- [ ] **Step 1: 查看源码了解接口**

```bash
cat app/utils/retry.py
```

- [ ] **Step 2: 创建测试文件**

```python
"""app/utils/retry.py 的单元测试"""

import time
from unittest.mock import MagicMock, patch

import pytest

from app.utils.retry import retry


class TestRetryDecorator:
    """测试 retry 装饰器"""

    def test_retry_success_first_attempt(self):
        """测试第一次尝试就成功"""
        call_count = 0

        @retry(max_attempts=3, delay=0.1)
        def successful_function():
            nonlocal call_count
            call_count += 1
            return "success"

        result = successful_function()

        assert result == "success"
        assert call_count == 1

    def test_retry_success_after_failures(self):
        """测试失败后重试成功"""
        call_count = 0

        @retry(max_attempts=3, delay=0.01)
        def eventually_successful():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("Not yet")
            return "success"

        result = eventually_successful()

        assert result == "success"
        assert call_count == 3

    def test_retry_exhausted(self):
        """测试重试次数用尽"""
        call_count = 0

        @retry(max_attempts=3, delay=0.01)
        def always_fails():
            nonlocal call_count
            call_count += 1
            raise ValueError("Always fails")

        with pytest.raises(ValueError, match="Always fails"):
            always_fails()

        assert call_count == 3

    def test_retry_with_specific_exceptions(self):
        """测试只重试特定异常"""
        call_count = 0

        @retry(max_attempts=3, delay=0.01, exceptions=(ValueError,))
        def raises_type_error():
            nonlocal call_count
            call_count += 1
            raise TypeError("Wrong type")

        with pytest.raises(TypeError):
            raises_type_error()

        # 只调用一次，因为 TypeError 不在重试列表中
        assert call_count == 1

    @patch("app.utils.retry.time.sleep")
    def test_retry_delay(self, mock_sleep):
        """测试重试延迟"""
        call_count = 0

        @retry(max_attempts=3, delay=0.5)
        def fails_twice():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("Not yet")
            return "success"

        result = fails_twice()

        assert result == "success"
        # 验证 sleep 被调用了两次（重试两次）
        assert mock_sleep.call_count == 2
        mock_sleep.assert_called_with(0.5)

    def test_retry_with_backoff(self):
        """测试指数退避（如果实现支持）"""
        # 根据实际实现调整这个测试
        pass
```

- [ ] **Step 3: 运行测试确认框架正确**

```bash
pytest tests/test_utils/test_retry.py -v
```

- [ ] **Step 4: 根据实际实现调整测试**

查看 `app/utils/retry.py` 的实际接口，调整测试代码以匹配实际的函数签名和行为。

- [ ] **Step 5: 运行测试确认全部通过**

```bash
pytest tests/test_utils/test_retry.py -v
```

- [ ] **Step 6: 检查覆盖率**

```bash
pytest tests/test_utils/test_retry.py --cov=app/utils/retry --cov-report=term-missing
```

Expected: 覆盖率 ≥ 85%

- [ ] **Step 7: 提交**

```bash
git add tests/test_utils/test_retry.py
git commit -m "test: 添加 retry.py 单元测试，覆盖重试机制和退避策略"
```

---

### Task 3: 提升加密工具覆盖率 (crypto.py)

**Files:**
- Modify: `tests/test_utils/test_crypto.py`
- Source: `app/utils/crypto.py`

- [ ] **Step 1: 查看当前测试和覆盖率**

```bash
pytest tests/test_utils/test_crypto.py --cov=app/utils/crypto --cov-report=term-missing -v
```

- [ ] **Step 2: 查看未覆盖的代码行**

根据覆盖率报告，查看 `app/utils/crypto.py` 中未覆盖的行（38, 42, 54-65, 76-77, 99-102, 116, 133-138, 167-169）

- [ ] **Step 3: 添加缺失的测试用例**

```python
# 在现有测试文件中添加

class TestCryptoEdgeCases:
    """测试加密工具的边界情况"""

    def test_encrypt_empty_string(self):
        """测试加密空字符串"""
        pass

    def test_decrypt_with_wrong_key(self):
        """测试使用错误密钥解密"""
        pass

    def test_key_generation(self):
        """测试密钥生成"""
        pass

    def test_encrypt_large_data(self):
        """测试加密大数据"""
        pass
```

- [ ] **Step 4: 实现完整的边界测试**

根据实际的 crypto.py 接口，实现完整的测试用例。

- [ ] **Step 5: 运行测试确认全部通过**

```bash
pytest tests/test_utils/test_crypto.py -v
```

- [ ] **Step 6: 检查覆盖率提升**

```bash
pytest tests/test_utils/test_crypto.py --cov=app/utils/crypto --cov-report=term-missing
```

Expected: 覆盖率从 79% 提升到 ≥ 85%

- [ ] **Step 7: 提交**

```bash
git add tests/test_utils/test_crypto.py
git commit -m "test: 提升 crypto.py 覆盖率到 85%+，补充边界条件测试"
```

---

### Task 4: 提升登录工具覆盖率 (login.py)

**Files:**
- Modify: `tests/test_utils/test_login.py`
- Source: `app/utils/login.py`

- [ ] **Step 1: 查看当前测试和覆盖率**

```bash
pytest tests/test_utils/test_login.py --cov=app/utils/login --cov-report=term-missing -v
```

- [ ] **Step 2: 分析未覆盖的代码**

未覆盖行：111-113, 126-127, 133-134, 138, 143-149, 190-255, 264-298

这些主要是登录流程的核心逻辑，需要 mock 浏览器操作。

- [ ] **Step 3: 添加登录流程测试**

```python
# 在现有测试文件中添加

class TestLoginFlow:
    """测试登录流程"""

    @patch("app.utils.login.playwright")
    def test_login_success(self, mock_playwright):
        """测试登录成功"""
        pass

    @patch("app.utils.login.playwright")
    def test_login_failure(self, mock_playwright):
        """测试登录失败"""
        pass

    @patch("app.utils.login.playwright")
    def test_login_with_captcha(self, mock_playwright):
        """测试带验证码的登录"""
        pass
```

- [ ] **Step 4: 实现完整的登录测试**

根据实际的 login.py 接口，mock 浏览器操作，实现完整的登录流程测试。

- [ ] **Step 5: 运行测试确认全部通过**

```bash
pytest tests/test_utils/test_login.py -v
```

- [ ] **Step 6: 检查覆盖率提升**

```bash
pytest tests/test_utils/test_login.py --cov=app/utils/login --cov-report=term-missing
```

Expected: 覆盖率从 56% 提升到 ≥ 75%

- [ ] **Step 7: 提交**

```bash
git add tests/test_utils/test_login.py
git commit -m "test: 提升 login.py 覆盖率到 75%+，补充登录流程测试"
```

---

### Task 5: 提升进程工具覆盖率 (process.py)

**Files:**
- Modify: `tests/test_utils/test_process.py`
- Source: `app/utils/process.py`

- [ ] **Step 1: 查看当前测试和覆盖率**

```bash
pytest tests/test_utils/test_process.py --cov=app/utils/process --cov-report=term-missing -v
```

- [ ] **Step 2: 添加缺失的测试用例**

未覆盖行：76-79, 97-109, 120-121, 140, 181

```python
# 在现有测试文件中添加

class TestProcessEdgeCases:
    """测试进程工具的边界情况"""

    def test_kill_process_not_found(self):
        """测试终止不存在的进程"""
        pass

    def test_kill_process_permission_denied(self):
        """测试权限不足时的处理"""
        pass

    def test_is_process_running(self):
        """测试检查进程是否运行"""
        pass
```

- [ ] **Step 3: 实现完整的边界测试**

- [ ] **Step 4: 运行测试确认全部通过**

```bash
pytest tests/test_utils/test_process.py -v
```

- [ ] **Step 5: 检查覆盖率提升**

```bash
pytest tests/test_utils/test_process.py --cov=app/utils/process --cov-report=term-missing
```

Expected: 覆盖率从 80% 提升到 ≥ 85%

- [ ] **Step 6: 提交**

```bash
git add tests/test_utils/test_process.py
git commit -m "test: 提升 process.py 覆盖率到 85%+，补充进程管理边界测试"
```

---

## 第二层：核心服务测试

### Task 6: 调度引擎测试 (engine.py)

**Files:**
- Create: `tests/test_services/test_engine.py`
- Source: `app/services/engine.py`

- [ ] **Step 1: 查看源码了解接口**

```bash
cat app/services/engine.py | head -150
```

- [ ] **Step 2: 创建测试文件框架**

```python
"""app/services/engine.py 的单元测试"""

import threading
from pathlib import Path
from unittest.mock import MagicMock, patch, AsyncMock

import pytest

from app.services.engine import ScheduleEngine, EngineCmdType, StatusSnapshot


@pytest.fixture
def mock_profile_service():
    """模拟 ProfileService"""
    return MagicMock()


@pytest.fixture
def mock_ws_manager():
    """模拟 WebSocketManager"""
    return MagicMock()


@pytest.fixture
def mock_login_history_service():
    """模拟 LoginHistoryService"""
    return MagicMock()


@pytest.fixture
def engine(mock_profile_service, mock_ws_manager, mock_login_history_service):
    """创建测试用引擎实例"""
    return ScheduleEngine(
        project_root=Path("/tmp/test"),
        profile_service=mock_profile_service,
        ws_manager=mock_ws_manager,
        login_history_service=mock_login_history_service,
    )


class TestScheduleEngineInit:
    """测试引擎初始化"""

    def test_engine_initialization(self, engine):
        """测试引擎正确初始化"""
        assert engine is not None
        assert engine._running is False

    def test_engine_default_state(self, engine):
        """测试引擎默认状态"""
        status = engine.get_status()
        assert status.monitoring is False


class TestScheduleEngineLifecycle:
    """测试引擎生命周期"""

    def test_start_engine(self, engine):
        """测试启动引擎"""
        engine.start()
        assert engine._running is True
        engine.stop()

    def test_stop_engine(self, engine):
        """测试停止引擎"""
        engine.start()
        engine.stop()
        assert engine._running is False

    def test_double_start(self, engine):
        """测试重复启动"""
        engine.start()
        engine.start()  # 应该是幂等的
        assert engine._running is True
        engine.stop()

    def test_double_stop(self, engine):
        """测试重复停止"""
        engine.start()
        engine.stop()
        engine.stop()  # 应该是幂等的
        assert engine._running is False


class TestScheduleEngineCommands:
    """测试引擎命令派发"""

    def test_dispatch_start_command(self, engine):
        """测试派发启动命令"""
        # 根据实际实现测试命令派发
        pass

    def test_dispatch_stop_command(self, engine):
        """测试派发停止命令"""
        pass

    def test_dispatch_login_command(self, engine):
        """测试派发登录命令"""
        pass


class TestScheduleEngineNetworkCheck:
    """测试网络检测"""

    @patch("app.services.engine.is_network_available")
    def test_network_check_available(self, mock_is_available, engine):
        """测试网络可用时的检测"""
        mock_is_available.return_value = True
        # 根据实际实现测试
        pass

    @patch("app.services.engine.is_network_available")
    def test_network_check_unavailable(self, mock_is_available, engine):
        """测试网络不可用时的检测"""
        mock_is_available.return_value = False
        pass


class TestScheduleEngineStatus:
    """测试引擎状态"""

    def test_get_status(self, engine):
        """测试获取状态"""
        status = engine.get_status()
        assert isinstance(status, StatusSnapshot)

    def test_status_snapshot_fields(self, engine):
        """测试状态快照字段"""
        status = engine.get_status()
        assert hasattr(status, "monitoring")
        assert hasattr(status, "last_network_ok")
        assert hasattr(status, "start_time")
```

- [ ] **Step 3: 运行测试确认框架正确**

```bash
pytest tests/test_services/test_engine.py -v
```

- [ ] **Step 4: 根据实际实现完善测试**

查看 engine.py 的完整实现，调整测试代码以匹配实际的接口和行为。

- [ ] **Step 5: 运行测试确认全部通过**

```bash
pytest tests/test_services/test_engine.py -v
```

- [ ] **Step 6: 检查覆盖率**

```bash
pytest tests/test_services/test_engine.py --cov=app/services/engine --cov-report=term-missing
```

Expected: 覆盖率 ≥ 80%

- [ ] **Step 7: 提交**

```bash
git add tests/test_services/test_engine.py
git commit -m "test: 添加 engine.py 单元测试，覆盖调度引擎核心逻辑"
```

---

### Task 7: 提升任务执行器覆盖率 (task_executor.py)

**Files:**
- Modify: `tests/test_services/test_task_executor.py`
- Source: `app/services/task_executor.py`

- [ ] **Step 1: 查看当前测试和覆盖率**

```bash
pytest tests/test_services/test_task_executor*.py --cov=app/services/task_executor --cov-report=term-missing -v
```

- [ ] **Step 2: 分析未覆盖的代码**

未覆盖行较多（42% 覆盖率），需要补充大量测试。

- [ ] **Step 3: 添加 BoundedExecutor 测试**

```python
# 在现有测试文件中添加

class TestBoundedExecutor:
    """测试 BoundedExecutor"""

    def test_submit_task_success(self):
        """测试成功提交任务"""
        pass

    def test_submit_task_queue_full(self):
        """测试队列满时的拒绝"""
        pass

    def test_shutdown(self):
        """测试关闭执行器"""
        pass

    def test_concurrent_submit(self):
        """测试并发提交"""
        pass


class TestNullTaskExecutor:
    """测试 NullTaskExecutor"""

    def test_all_methods_return_none_or_empty(self):
        """测试所有方法返回 None 或空值"""
        pass
```

- [ ] **Step 4: 实现完整的执行器测试**

根据 task_executor.py 的完整实现，补充所有边界条件测试。

- [ ] **Step 5: 运行测试确认全部通过**

```bash
pytest tests/test_services/test_task_executor*.py -v
```

- [ ] **Step 6: 检查覆盖率提升**

```bash
pytest tests/test_services/test_task_executor*.py --cov=app/services/task_executor --cov-report=term-missing
```

Expected: 覆盖率从 42% 提升到 ≥ 70%

- [ ] **Step 7: 提交**

```bash
git add tests/test_services/test_task_executor*.py
git commit -m "test: 提升 task_executor.py 覆盖率到 70%+，补充线程池和队列测试"
```

---

### Task 8: 调试服务测试 (debug_service.py)

**Files:**
- Create: `tests/test_services/test_debug_service.py`
- Source: `app/services/debug_service.py`

- [ ] **Step 1: 查看源码了解接口**

```bash
cat app/services/debug_service.py | head -100
```

- [ ] **Step 2: 创建测试文件**

```python
"""app/services/debug_service.py 的单元测试"""

from unittest.mock import MagicMock, patch

import pytest

from app.services.debug_service import DebugService


@pytest.fixture
def mock_container():
    """模拟 ServiceContainer"""
    return MagicMock()


@pytest.fixture
def debug_service(mock_container):
    """创建测试用调试服务"""
    return DebugService(container=mock_container)


class TestDebugServiceInit:
    """测试调试服务初始化"""

    def test_initialization(self, debug_service):
        """测试正确初始化"""
        assert debug_service is not None


class TestDebugSession:
    """测试调试会话"""

    def test_create_session(self, debug_service):
        """测试创建调试会话"""
        pass

    def test_destroy_session(self, debug_service):
        """测试销毁调试会话"""
        pass

    def test_get_session_status(self, debug_service):
        """测试获取会话状态"""
        pass

    def test_list_sessions(self, debug_service):
        """测试列出所有会话"""
        pass
```

- [ ] **Step 3: 根据实际实现完善测试**

- [ ] **Step 4: 运行测试确认全部通过**

```bash
pytest tests/test_services/test_debug_service.py -v
```

- [ ] **Step 5: 检查覆盖率**

```bash
pytest tests/test_services/test_debug_service.py --cov=app/services/debug_service --cov-report=term-missing
```

Expected: 覆盖率 ≥ 90%

- [ ] **Step 6: 提交**

```bash
git add tests/test_services/test_debug_service.py
git commit -m "test: 添加 debug_service.py 单元测试，覆盖调试会话管理"
```

---

### Task 9: 登录历史服务测试 (login_history_service.py)

**Files:**
- Create: `tests/test_services/test_login_history_service.py`
- Source: `app/services/login_history_service.py`

- [ ] **Step 1: 查看源码了解接口**

```bash
cat app/services/login_history_service.py | head -100
```

- [ ] **Step 2: 创建测试文件**

```python
"""app/services/login_history_service.py 的单元测试"""

from unittest.mock import MagicMock, patch
from datetime import datetime

import pytest

from app.services.login_history_service import LoginHistoryService


@pytest.fixture
def mock_db():
    """模拟数据库"""
    return MagicMock()


@pytest.fixture
def history_service(mock_db):
    """创建测试用登录历史服务"""
    return LoginHistoryService(db=mock_db)


class TestLoginHistoryService:
    """测试登录历史服务"""

    def test_add_record(self, history_service):
        """测试添加登录记录"""
        pass

    def test_get_history(self, history_service):
        """测试获取历史记录"""
        pass

    def test_delete_record(self, history_service):
        """测试删除记录"""
        pass

    def test_clear_history(self, history_service):
        """测试清空历史"""
        pass

    def test_get_statistics(self, history_service):
        """测试获取统计信息"""
        pass
```

- [ ] **Step 3: 根据实际实现完善测试**

- [ ] **Step 4: 运行测试确认全部通过**

```bash
pytest tests/test_services/test_login_history_service.py -v
```

- [ ] **Step 5: 检查覆盖率**

```bash
pytest tests/test_services/test_login_history_service.py --cov=app/services/login_history_service --cov-report=term-missing
```

Expected: 覆盖率 ≥ 85%

- [ ] **Step 6: 提交**

```bash
git add tests/test_services/test_login_history_service.py
git commit -m "test: 添加 login_history_service.py 单元测试，覆盖历史记录 CRUD"
```

---

### Task 10: WebSocket 管理器测试 (websocket_manager.py)

**Files:**
- Create: `tests/test_services/test_websocket_manager.py`
- Source: `app/services/websocket_manager.py`

- [ ] **Step 1: 查看源码了解接口**

```bash
cat app/services/websocket_manager.py
```

- [ ] **Step 2: 创建测试文件**

```python
"""app/services/websocket_manager.py 的单元测试"""

from unittest.mock import MagicMock, AsyncMock

import pytest

from app.services.websocket_manager import WebSocketManager


@pytest.fixture
def ws_manager():
    """创建测试用 WebSocket 管理器"""
    return WebSocketManager()


class TestWebSocketManager:
    """测试 WebSocket 管理器"""

    def test_initialization(self, ws_manager):
        """测试初始化"""
        assert ws_manager is not None

    @pytest.mark.asyncio
    async def test_connect(self, ws_manager):
        """测试连接"""
        mock_ws = AsyncMock()
        await ws_manager.connect(mock_ws)
        assert mock_ws in ws_manager.active_connections

    @pytest.mark.asyncio
    async def test_disconnect(self, ws_manager):
        """测试断开连接"""
        mock_ws = AsyncMock()
        await ws_manager.connect(mock_ws)
        await ws_manager.disconnect(mock_ws)
        assert mock_ws not in ws_manager.active_connections

    @pytest.mark.asyncio
    async def test_broadcast(self, ws_manager):
        """测试广播消息"""
        mock_ws1 = AsyncMock()
        mock_ws2 = AsyncMock()
        await ws_manager.connect(mock_ws1)
        await ws_manager.connect(mock_ws2)

        await ws_manager.broadcast("test message")

        mock_ws1.send_text.assert_called_once_with("test message")
        mock_ws2.send_text.assert_called_once_with("test message")

    @pytest.mark.asyncio
    async def test_broadcast_with_failed_connection(self, ws_manager):
        """测试广播时连接失败的处理"""
        mock_ws1 = AsyncMock()
        mock_ws2 = AsyncMock()
        mock_ws1.send_text.side_effect = Exception("Connection lost")

        await ws_manager.connect(mock_ws1)
        await ws_manager.connect(mock_ws2)

        # 应该不抛出异常，继续广播给其他连接
        await ws_manager.broadcast("test message")

        mock_ws2.send_text.assert_called_once_with("test message")

    def test_get_connection_count(self, ws_manager):
        """测试获取连接数"""
        assert ws_manager.get_connection_count() == 0
```

- [ ] **Step 3: 根据实际实现调整测试**

- [ ] **Step 4: 运行测试确认全部通过**

```bash
pytest tests/test_services/test_websocket_manager.py -v
```

- [ ] **Step 5: 检查覆盖率**

```bash
pytest tests/test_services/test_websocket_manager.py --cov=app/services/websocket_manager --cov-report=term-missing
```

Expected: 覆盖率 ≥ 90%

- [ ] **Step 6: 提交**

```bash
git add tests/test_services/test_websocket_manager.py
git commit -m "test: 添加 websocket_manager.py 单元测试，覆盖连接管理和消息广播"
```

---

## 第三层：集成测试

### Task 11: 应用启动集成测试

**Files:**
- Create: `tests/test_integration/__init__.py`
- Create: `tests/test_integration/test_app_startup.py`
- Source: `app/application.py`

- [ ] **Step 1: 创建集成测试目录**

```bash
mkdir -p tests/test_integration
touch tests/test_integration/__init__.py
```

- [ ] **Step 2: 查看 application.py 的启动流程**

```bash
cat app/application.py | head -200
```

- [ ] **Step 3: 创建应用启动测试**

```python
"""应用启动流程集成测试"""

from unittest.mock import MagicMock, patch, AsyncMock
from pathlib import Path

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def mock_container():
    """模拟 ServiceContainer"""
    container = MagicMock()
    container.config_service = MagicMock()
    container.profile_service = MagicMock()
    container.engine = MagicMock()
    container.task_executor = MagicMock()
    return container


class TestAppStartup:
    """测试应用启动流程"""

    @patch("app.application.create_container")
    def test_create_app(self, mock_create_container, mock_container):
        """测试 create_app 正确初始化"""
        mock_create_container.return_value = mock_container

        from app.application import create_app
        app = create_app()

        assert app is not None
        mock_create_container.assert_called_once()

    @patch("app.application.create_container")
    def test_app_routes_registered(self, mock_create_container, mock_container):
        """测试路由正确注册"""
        mock_create_container.return_value = mock_container

        from app.application import create_app
        app = create_app()

        # 验证关键路由存在
        routes = [route.path for route in app.routes]
        assert "/api/health" in routes or "/health" in routes

    @patch("app.application.create_container")
    def test_lifespan_startup(self, mock_create_container, mock_container):
        """测试生命周期启动"""
        mock_create_container.return_value = mock_container

        from app.application import create_app
        app = create_app()

        # 使用 TestClient 触发启动
        with TestClient(app):
            # 验证启动时调用了必要的初始化
            pass


class TestDependencyInjection:
    """测试依赖注入"""

    @patch("app.application.create_container")
    def test_deps_injection(self, mock_create_container, mock_container):
        """测试依赖正确注入"""
        mock_create_container.return_value = mock_container

        from app.application import create_app
        from app.deps import get_container

        app = create_app()

        # 验证依赖注入容器可用
        # 根据实际实现调整
```

- [ ] **Step 4: 运行测试确认全部通过**

```bash
pytest tests/test_integration/test_app_startup.py -v
```

- [ ] **Step 5: 提交**

```bash
git add tests/test_integration/
git commit -m "test: 添加应用启动集成测试，覆盖初始化和依赖注入"
```

---

### Task 12: 登录流程集成测试

**Files:**
- Create: `tests/test_integration/test_login_flow.py`
- Source: `app/services/engine.py`, `app/services/task_executor.py`, `app/tasks/browser_runner.py`

- [ ] **Step 1: 创建登录流程测试**

```python
"""登录认证流程集成测试"""

from unittest.mock import MagicMock, patch, AsyncMock
from pathlib import Path

import pytest


@pytest.fixture
def mock_engine():
    """模拟调度引擎"""
    engine = MagicMock()
    engine.get_status.return_value = MagicMock(monitoring=True)
    return engine


@pytest.fixture
def mock_task_executor():
    """模拟任务执行器"""
    executor = MagicMock()
    return executor


class TestLoginFlow:
    """测试登录认证流程"""

    def test_complete_login_sequence(self, mock_engine, mock_task_executor):
        """测试完整登录序列"""
        # 1. 触发登录命令
        # 2. 验证任务提交到线程池
        # 3. 验证浏览器操作调用
        # 4. 验证结果回调
        pass

    def test_login_with_network_check(self, mock_engine):
        """测试带网络检测的登录流程"""
        pass

    def test_login_retry_on_failure(self, mock_engine, mock_task_executor):
        """测试登录失败重试机制"""
        pass

    def test_login_concurrent_protection(self, mock_task_executor):
        """测试登录并发保护"""
        pass
```

- [ ] **Step 2: 根据实际实现完善测试**

- [ ] **Step 3: 运行测试确认全部通过**

```bash
pytest tests/test_integration/test_login_flow.py -v
```

- [ ] **Step 4: 提交**

```bash
git add tests/test_integration/test_login_flow.py
git commit -m "test: 添加登录流程集成测试，覆盖端到端登录认证"
```

---

### Task 13: 定时任务集成测试

**Files:**
- Create: `tests/test_integration/test_scheduled_task.py`
- Source: `app/services/task_executor.py`, `app/services/task_registry.py`, `app/tasks/step_handlers.py`

- [ ] **Step 1: 创建定时任务测试**

```python
"""定时任务执行集成测试"""

from unittest.mock import MagicMock, patch
from pathlib import Path

import pytest


@pytest.fixture
def mock_task_registry():
    """模拟任务注册表"""
    registry = MagicMock()
    return registry


@pytest.fixture
def mock_step_handlers():
    """模拟步骤处理器"""
    return MagicMock()


class TestScheduledTask:
    """测试定时任务执行"""

    def test_task_registration_and_execution(self, mock_task_registry):
        """测试任务注册和执行"""
        pass

    def test_task_with_variable_resolution(self, mock_task_registry):
        """测试带变量解析的任务执行"""
        pass

    def test_task_failure_handling(self, mock_task_registry):
        """测试任务失败处理"""
        pass

    def test_task_cancellation(self, mock_task_registry):
        """测试任务取消"""
        pass
```

- [ ] **Step 2: 根据实际实现完善测试**

- [ ] **Step 3: 运行测试确认全部通过**

```bash
pytest tests/test_integration/test_scheduled_task.py -v
```

- [ ] **Step 4: 提交**

```bash
git add tests/test_integration/test_scheduled_task.py
git commit -m "test: 添加定时任务集成测试，覆盖任务调度执行"
```

---

## 验证与收尾

### Task 14: 整体覆盖率验证

- [ ] **Step 1: 运行完整测试套件**

```bash
pytest tests/ --cov=app --cov-report=term-missing -q
```

- [ ] **Step 2: 验证覆盖率达标**

Expected: 整体覆盖率 ≥ 85%

- [ ] **Step 3: 验证核心模块覆盖率**

```bash
pytest tests/test_services/test_engine.py tests/test_services/test_task_executor.py tests/test_integration/ --cov=app/services/engine --cov=app/services/task_executor --cov-report=term-missing
```

Expected: 核心模块覆盖率 ≥ 80%

- [ ] **Step 4: 验证测试执行时间**

```bash
time pytest tests/ -q
```

Expected: 执行时间 < 60 秒

- [ ] **Step 5: 生成 HTML 覆盖率报告**

```bash
pytest tests/ --cov=app --cov-report=html
```

- [ ] **Step 6: 提交最终状态**

```bash
git add -A
git commit -m "test: 完成测试覆盖率改进，整体覆盖率达到 85%+"
```

---

## 执行建议

**推荐执行顺序**：
1. Task 1-5（第一层：工具函数测试）
2. Task 6-10（第二层：核心服务测试）
3. Task 11-13（第三层：集成测试）
4. Task 14（验证与收尾）

**每完成一个 Task 后**：
- 运行测试确认通过
- 检查覆盖率提升
- 提交代码

**遇到问题时**：
- 如果 mock 困难，先跳过该测试，记录待解决
- 如果覆盖率提升不及预期，优先保证核心路径测试
- 如果测试执行时间过长，优化 mock 策略

---

**计划版本**：v1.0
**创建日期**：2026-06-15
**预计完成时间**：4-7 天
