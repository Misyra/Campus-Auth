# 修复自动切换方案的实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use subagent-driven-development (recommended) or executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 修复自动切换方案后监控没有重启的问题，并删除形同虚设的冷却时间

**Architecture:** 
1. 删除 `monitor_service.py` 中的冷却时间常量和相关逻辑
2. 在 `monitor_service.py` 中添加 `_profile_switch_needed` 标志位
3. 在 `engine.py` 的 `_do_network_check` 中检查标志位并执行重启

**Tech Stack:** Python, threading

---

## 问题分析

### 问题1：冷却时间形同虚设
- 冷却时间：60秒
- 检测间隔：300秒（默认）
- 结果：每次检测都超过冷却时间，冷却检查永远通过

### 问题2：自动切换后监控没有重启
- `_check_profile_switch()` 只保存活动方案，没有通知 engine 重启监控
- 当前运行的监控仍然使用旧配置

---

## 文件结构

### 修改的文件
- `app/services/monitor_service.py` - 删除冷却时间，添加重启标志
- `app/services/engine.py` - 处理自动切换后的重启逻辑
- `tests/test_monitor_service.py` - 添加测试用例

---

### Task 1: 删除冷却时间

**Files:**
- Modify: `app/services/monitor_service.py:43,77,308-324`

- [ ] **Step 1: 删除冷却时间常量**

在 `app/services/monitor_service.py` 中，删除第43行的常量：
```python
# 删除这行
GATEWAY_CHECK_COOLDOWN_SECONDS = 60
```

- [ ] **Step 2: 删除冷却时间相关的实例变量**

在 `__init__` 方法中，删除第77行：
```python
# 删除这行
self._last_gateway_check_time: float = 0
```

- [ ] **Step 3: 删除冷却时间检查逻辑**

在 `_check_profile_switch` 方法中，删除第316-324行的冷却时间检查：
```python
# 删除这些行
now = time.time()
if (
    now - self._last_gateway_check_time
    < self.GATEWAY_CHECK_COOLDOWN_SECONDS
):
    return

self._last_gateway_check_time = now
```

- [ ] **Step 4: 运行测试验证**

Run: `PYTHONPATH=. .\.venv\Scripts\python.exe -m pytest tests/test_monitor_service.py -q`
Expected: 所有测试通过

- [ ] **Step 5: 提交**

```bash
git add app/services/monitor_service.py
git commit -m "refactor: 删除形同虚设的冷却时间（检测间隔300秒 >> 冷却60秒）"
```

---

### Task 2: 添加重启标志位

**Files:**
- Modify: `app/services/monitor_service.py:77,308-354`

- [ ] **Step 1: 添加重启标志位**

在 `__init__` 方法中，添加标志位：
```python
self._last_profile_id: str | None = None
self._profile_switch_needed: bool = False  # 新增：标志位
```

- [ ] **Step 2: 修改 `_check_profile_switch` 方法**

修改方法，设置标志位而不是直接重启：
```python
def _check_profile_switch(self) -> None:
    """检测网关 IP 并自动切换方案。

    检测到方案变化时设置标志位，由 engine 处理重启。
    """
    if not self._profile_service:
        return

    try:
        data = self._profile_service.load()
        if not data.auto_switch:
            return

        matched_id = self._profile_service.detect_matching_profile()
        if matched_id and matched_id != self._last_profile_id:
            profile = data.profiles.get(matched_id)
            profile_name = profile.name if profile else matched_id
            old_profile = data.profiles.get(self._last_profile_id)
            old_name = (
                old_profile.name if old_profile else (self._last_profile_id or "无")
            )

            self.log_message(
                f"检测到网络环境变化，方案切换: {old_name} -> {profile_name}",
                "INFO",
            )

            self._last_profile_id = matched_id
            ok, msg = self._profile_service.set_active_profile(matched_id)
            if not ok:
                # 方案可能在检测后被删除，回退缓存状态
                self._last_profile_id = self._profile_service.load().active_profile
                self.log_message(f"方案切换失败: {msg}", "WARNING")
            else:
                # 方案切换成功，设置标志位
                self._profile_switch_needed = True
    except Exception as exc:
        self.log_message(f"方案切换检测异常: {exc}", "WARNING")
```

- [ ] **Step 3: 添加重置标志位的方法**

添加方法供 engine 调用：
```python
def consume_profile_switch_flag(self) -> bool:
    """消费重启标志位（原子操作）。"""
    if self._profile_switch_needed:
        self._profile_switch_needed = False
        return True
    return False
```

- [ ] **Step 4: 运行测试验证**

Run: `PYTHONPATH=. .\.venv\Scripts\python.exe -m pytest tests/test_monitor_service.py -q`
Expected: 所有测试通过

- [ ] **Step 5: 提交**

```bash
git add app/services/monitor_service.py
git commit -m "feat: 添加自动切换方案的重启标志位"
```

---

### Task 3: Engine 处理自动切换重启

**Files:**
- Modify: `app/services/engine.py:267-288`

- [ ] **Step 1: 修改 `_do_network_check` 方法**

在 `_do_network_check` 中检查标志位并执行重启：
```python
def _do_network_check(self) -> None:
    """执行一次网络检测。"""
    if self._monitor_core is None:
        return

    try:
        result = self._monitor_core.check_once()
        interval = int(result.get("interval", self._monitor_check_interval))
        self._monitor_check_interval = interval

        if result.get("need_login", False):
            self._login_retry.config = self._get_retry_config()
            self._login_retry.count = 0
            self._do_async_login()
        else:
            self._login_retry.count = 0

        # 检查是否需要重启（自动切换方案）
        if self._monitor_core.consume_profile_switch_flag():
            logger.info("检测到方案切换，重启监控")
            self._handle_stop()
            self._reload_config_internal()
            self._handle_start(EngineCommand(type=EngineCmdType.START))

        self._next_network_check = time.time() + interval
        self._update_status_snapshot(force=True)
    except Exception:
        logger.exception("网络检测异常")
        self._next_network_check = time.time() + self._monitor_check_interval
```

- [ ] **Step 2: 运行测试验证**

Run: `PYTHONPATH=. .\.venv\Scripts\python.exe -m pytest tests/test_engine.py -q`
Expected: 所有测试通过

- [ ] **Step 3: 提交**

```bash
git add app/services/engine.py
git commit -m "fix: 自动切换方案后重启监控"
```

---

### Task 4: 添加测试用例

**Files:**
- Modify: `tests/test_monitor_service.py`
- Modify: `tests/test_engine.py`

- [ ] **Step 1: 添加 `_check_profile_switch` 测试**

在 `tests/test_monitor_service.py` 中添加：
```python
def test_check_profile_switch_sets_flag():
    """测试自动切换方案设置标志位"""
    from app.services.monitor_service import NetworkMonitorCore
    from unittest.mock import MagicMock

    core = NetworkMonitorCore()
    mock_profile_service = MagicMock()
    mock_profile_service.load.return_value.auto_switch = True
    mock_profile_service.detect_matching_profile.return_value = "new_profile"
    mock_profile_service.set_active_profile.return_value = (True, "ok")
    core._profile_service = mock_profile_service
    core._last_profile_id = "old_profile"

    core._check_profile_switch()

    assert core._profile_switch_needed is True
    assert core._last_profile_id == "new_profile"


def test_check_profile_switch_no_change():
    """测试方案未变化时不设置标志位"""
    from app.services.monitor_service import NetworkMonitorCore
    from unittest.mock import MagicMock

    core = NetworkMonitorCore()
    mock_profile_service = MagicMock()
    mock_profile_service.load.return_value.auto_switch = True
    mock_profile_service.detect_matching_profile.return_value = "same_profile"
    core._profile_service = mock_profile_service
    core._last_profile_id = "same_profile"

    core._check_profile_switch()

    assert core._profile_switch_needed is False


def test_consume_profile_switch_flag():
    """测试消费标志位"""
    from app.services.monitor_service import NetworkMonitorCore

    core = NetworkMonitorCore()
    core._profile_switch_needed = True

    assert core.consume_profile_switch_flag() is True
    assert core._profile_switch_needed is False
    assert core.consume_profile_switch_flag() is False
```

- [ ] **Step 2: 运行测试验证**

Run: `PYTHONPATH=. .\.venv\Scripts\python.exe -m pytest tests/test_monitor_service.py -q`
Expected: 所有测试通过

- [ ] **Step 3: 提交**

```bash
git add tests/test_monitor_service.py
git commit -m "test: 添加自动切换方案的测试用例"
```

---

### Task 5: 最终验证

- [ ] **Step 1: 运行所有测试**

Run: `PYTHONPATH=. .\.venv\Scripts\python.exe -m pytest -q`
Expected: 所有测试通过

- [ ] **Step 2: 运行代码检查**

Run: `.\.venv\Scripts\python.exe -m ruff check app/services/monitor_service.py app/services/engine.py`
Expected: 无错误

- [ ] **Step 3: 更新修改日志**

在 `dev/change.md` 中添加修改记录：
```markdown
## 2026-06-15

### 修复
- 删除形同虚设的冷却时间（检测间隔300秒 >> 冷却60秒）
- 修复自动切换方案后监控没有重启的问题
```

- [ ] **Step 4: 最终提交**

```bash
git add dev/change.md
git commit -m "docs: 更新修改日志"
```

---

## 验证方法

1. 启动监控
2. 配置两个方案，设置不同的网关IP匹配
3. 切换网络环境
4. 观察日志是否显示"检测到网络环境变化，方案切换"
5. 观察监控是否自动重启
6. 验证新配置已生效
