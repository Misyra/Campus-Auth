# 全量代码审计执行计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 对 Campus-Auth 全量代码进行死代码、潜在 Bug、代码坏味道审计

**架构:** 9 个独立 agent 按模块划分并行审查，各自输出问题列表，最后汇总去重生成报告

**Tech Stack:** Python 3.12+, FastAPI, Playwright, Vue 3 (无构建), pytest

---

### Task 1: Agent A1 — API 路由层审计

**Files:** `app/api/` 全部 13 个路由文件
- `app/api/profiles.py`
- `app/api/monitor.py`
- `app/api/history.py`
- `app/api/debug.py`
- `app/api/config.py`
- `app/api/autostart.py`
- `app/api/system.py`
- `app/api/scripts.py`
- `app/api/scheduled_tasks.py`
- `app/api/tasks.py`
- `app/api/repo.py`
- `app/api/tools.py`
- `app/api/ocr.py`

**审计清单：**
1. **死代码** — 未使用的 import、未使用的路由函数、未使用的辅助函数、不可达代码
2. **潜在 Bug** — 缺少异常处理（`await` 无 try/catch）、请求/响应模型不匹配、路径参数与函数签名不一致、权限校验遗漏、`None` 未检查
3. **代码坏味道** — 路由函数过长、重复的 boilerplate 代码、硬编码字符串

- [ ] **Step 1: 读取目标文件**

使用 Read 工具读取 `app/api/` 下全部 13 个路由文件。

- [ ] **Step 2: 逐文件审查**

对每个文件执行检查清单，记录所有问题。

输出格式：
```
文件:app/api/xxx.py:行号
  - 类型: [死代码/潜在Bug/坏味道]
  - 问题: 具体描述
  - 严重度: [高/中/低]
```

- [ ] **Step 3: 提交结果**

返回完整的 A1 审计结果。


### Task 2: Agent A2 — 核心服务审计

**Files:**
- `app/services/engine.py`
- `app/services/monitor_service.py`
- `app/services/task_executor.py`
- `app/services/websocket_manager.py`

**审计清单：**
1. **死代码** — 未使用的 import、方法、类、变量；不可达代码
2. **潜在 Bug** — Actor 模型中的竞态条件（队列 vs 线程 vs asyncio）、监控循环中的资源泄漏、线程池管理（关闭/超时）、WebSocket 连接泄漏、`asyncio.create_task` 未保存引用、异步上下文中的同步阻塞调用
3. **代码坏味道** — 过长函数（engine.py 840 行）、过深嵌套、重复模式

- [ ] **Step 1: 读取目标文件**

使用 Read 工具读取 `app/services/` 下 4 个核心文件。

- [ ] **Step 2: 逐文件审查**

对每个文件执行检查清单，记录所有问题。

- [ ] **Step 3: 提交结果**

返回完整的 A2 审计结果。


### Task 3: Agent A3 — 支持服务审计

**Files:**
- `app/services/profile_service.py`
- `app/services/config_service.py`
- `app/services/task_service.py`
- `app/services/login_history_service.py`
- `app/services/debug_service.py`
- `app/services/debug_session.py`
- `app/services/autostart.py`
- `app/services/runtime_config.py`
- `app/services/task_registry.py`
- `app/services/uninstall.py`

**审计清单：**
1. **死代码** — 未使用的 import、方法、类、变量；废弃的兼容代码
2. **潜在 Bug** — 配置读写竞态、密码解密异常未处理、跨平台路径硬编码、文件操作无异常处理、自启动注册/卸载逻辑错误
3. **代码坏味道** — 冗长的 if/elif 链、重复的 CRUD 模式、硬编码路径

- [ ] **Step 1: 读取目标文件**

使用 Read 工具读取 `app/services/` 下 10 个文件。

- [ ] **Step 2: 逐文件审查**

按审计清单逐文件检查，记录所有问题。特别关注：配置文件的线程安全、跨平台路径兼容性、自启动/卸载逻辑。

- [ ] **Step 3: 提交结果**

返回完整的 A3 审计结果，格式同 Task 1。


### Task 4: Agent A4 — Workers + 任务引擎审计

**Files:**
- `app/workers/playwright_worker.py`
- `app/workers/playwright_bootstrap.py`
- `app/workers/script_runner.py`
- `app/tasks/models.py`
- `app/tasks/variable_resolver.py`
- `app/tasks/validator.py`
- `app/tasks/step_handlers.py`
- `app/tasks/manager.py`
- `app/tasks/browser_runner.py`

**审计清单：**
1. **死代码** — 未使用的步骤处理器、未使用的 task 方法、未使用的 import
2. **潜在 Bug** — Playwright 浏览器泄漏（page/browser 未关闭）、Actor 线程异常传播、浏览器崩溃恢复、脚本执行器安全策略绕过、超时未传递、步骤执行错误未冒泡、变量递归解析无限循环
3. **代码坏味道** — handlers.py 840 行长、步骤处理器的重复模式、魔法超时值

- [ ] **Step 1: 读取目标文件**

使用 Read 工具读取 `app/tasks/` + `app/workers/` 下全部 9 个文件。优先读 playwright_worker.py（1003 行）和 step_handlers.py（840 行）。

- [ ] **Step 2: 逐文件审查**

按审计清单逐文件检查。特别关注：playwright_worker 的 Actor 生命周期、step_handlers 中的异常传播和超时机制、browser_runner 与 handlers 的协调。

- [ ] **Step 3: 提交结果**

返回完整的 A4 审计结果。


### Task 5: Agent A5 — Utils 工具模块审计

**Files:** `app/utils/` 全部 19 个工具文件

**审计清单：**
1. **死代码** — 未使用的工具函数、未使用的 import、徒劳表达式、死条件
2. **潜在 Bug** — 加密错误处理（Fernet 密钥损坏）、日志死锁（WebSocket 推送与日志写入循环依赖）、Shell 安全策略绕过（命令注入）、进程管理竞态、跨平台兼容性问题
3. **代码坏味道** — 过长函数、魔法值、TODO 注释

- [ ] **Step 1: 读取目标文件**

使用 Read 工具读取 `app/utils/` 全部 19 个文件。优先读 logging.py（318 行）、crypto.py（258 行）、shell_policy.py（206 行）。

- [ ] **Step 2: 逐文件审查**

按审计清单逐文件检查。特别关注：logging.py 的 WebSocket 推送与文件写入之间是否存在循环依赖/死锁、crypto.py 的密钥损坏恢复路径、shell_policy.py 的安全验证绕过点。

- [ ] **Step 3: 提交结果**

返回完整的 A5 审计结果。


### Task 6: Agent A6 — 应用基础设施审计

**Files:**
- `app/__init__.py`
- `app/application.py`
- `app/container.py`
- `app/schemas.py`
- `app/constants.py`
- `app/deps.py`
- `app/version.py`
- `app/network/probes.py`
- `app/network/detect.py`
- `app/network/decision.py`
- `app/ui/system_tray.py`
- `main.py`

**审计清单：**
1. **死代码** — 未使用的 Schema 字段/枚举、未使用的常量、未使用的网络探测函数、未使用的依赖注入函数
2. **潜在 Bug** — FastAPI 路由注册遗漏、Container 生命周期错误（启动/关闭顺序）、网络探测中的连接泄漏、跨平台网关/WiFi 检测错误、信号处理未覆盖、重复启动检测边界条件
3. **代码坏味道** — 过大的 Schema 类、硬编码 URL/IP、平台上 if/else 重复

- [ ] **Step 1: 读取目标文件**

使用 Read 工具读取 `app/` 顶层 + `app/network/` + `app/ui/` + `main.py` 共 12 个文件。

- [ ] **Step 2: 逐文件审查**

按审计清单逐文件检查。特别关注：application.py（436 行）的路由注册 vs 实际路由文件是否一致、container.py 的启动关闭顺序、network/detect.py（342 行）的跨平台兼容性。

- [ ] **Step 3: 提交结果**

返回完整的 A6 审计结果。


### Task 7: Agent A7 — 前端 JS 审计

**Files:** `frontend/` 全部 JS 文件

重点文件：
- `frontend/app.js`
- `frontend/js/app-options.js`
- `frontend/js/constants.js`
- `frontend/js/components.js`
- `frontend/js/logger.js`
- `frontend/js/data/*.js` (12 个)
- `frontend/js/methods/*.js` (11 个)
- `frontend/js/tasks/*.js` (4 个)

**审计清单：**
1. **死代码** — 未使用的 data 字段、未使用的 methods、未使用的 computed/watch、未使用的 import、未使用的组件
2. **潜在 Bug** — API 调用错误未处理、WebSocket 重连逻辑、模板字符串 XSS、响应式丢失（在 Vue 外部修改 data）、竞态条件（异步 init 顺序依赖）、内存泄漏（setInterval 未清理）
3. **代码坏味道** — 过长 methods、魔数、控制台日志遗留、重复代码

- [ ] **Step 1: 读取目标文件**

使用 Read 工具读取 `frontend/` 全部 JS 文件（36 个）。优先读 app-options.js（12KB）、methods/lifecycle.js（11KB）、methods/ui.js（11KB）、tasks/editor.js（12KB）。

- [ ] **Step 2: 逐文件审查**

按审计清单逐文件检查。特别关注：app-options.js 中的 watch/computed 依赖是否正确、methods/lifecycle.js 中 async init 顺序依赖、WebSocket 重连逻辑、setInterval 清理、Vue data 响应式丢失。

- [ ] **Step 3: 提交结果**

返回完整的 A7 审计结果。


### Task 8: Agent A8 — 前端 HTML + CSS 审计

**Files:** `frontend/` 全部 HTML partials + CSS

重点文件：
- `frontend/partials/*.html` (19 个)
- `frontend/styles/*.css` + `frontend/styles/pages/*.css` (13 个)
- `frontend/index.html`

**审计清单：**
1. **死代码** — 未使用的 CSS 类、未使用的 HTML 片段、重复的 style 块
2. **潜在 Bug** — Vue 模板绑定错误（`v-if`/`v-for` 键值）、事件绑定问题、错误的数据属性名、模板中的硬编码文本、CSS 变量未定义、响应式断点遗漏
3. **代码坏味道** — 过大的 HTML 文件（tasks.html 24KB）、CSS 选择器特异性冲突、!important 滥用

- [ ] **Step 1: 读取目标文件**

使用 Read 工具读取 `frontend/partials/` 全部 19 个 HTML 和 `frontend/styles/` 全部 13 个 CSS。优先读 tasks.html（24KB）、profiles.html（15KB）、appearance.html（18KB）。

- [ ] **Step 2: 逐文件审查**

按审计清单逐文件检查。特别关注：Vue 模板 `v-if`/`v-for` 键值、模板中引用的 data 属性名是否与 JS 侧一致、CSS 变量未定义、!important 滥用。

- [ ] **Step 3: 提交结果**

返回完整的 A8 审计结果。


### Task 9: Agent A9 — 测试代码审计

**Files:** `tests/` 全部 58 个测试文件

**审计清单：**
1. **死代码** — 未使用的 fixture、未使用的测试辅助函数、未使用的 import、跳过的测试（`@pytest.mark.skip` 无原因）
2. **潜在 Bug** — mock 不完全（真实依赖被调用）、断言太弱（`assert True`）、异步测试缺少 `await`、fixture 污染（共享可变对象）、测试依赖顺序
3. **代码坏味道** — 测试代码重复、测试过长（测试多个行为）、测试命名不清晰、硬编码路径

- [ ] **Step 1: 读取目标文件**

使用 Read 工具批量读取 `tests/` 下的测试文件。先读 conftest.py，再按子目录分组（test_api/、test_services/ 等）。

- [ ] **Step 2: 逐文件审查**

按审计清单逐文件检查。特别关注：mock 是否覆盖了真实依赖、fixture 是否共享可变对象导致测试间污染、异步测试是否缺少 await、跳过测试是否有原因说明。

- [ ] **Step 3: 提交结果**

返回完整的 A9 审计结果。


### Task 10: 结果汇总与报告

- [ ] **Step 1: 收集全部 9 个 Agent 的结果**

- [ ] **Step 2: 去重与排序**

将跨 agent 的重叠问题去重，按严重度（高>中>低）排序。

- [ ] **Step 3: 生成最终报告**

报告结构：
```markdown
# Campus-Auth 全量代码审计报告

## 概览
| Agent | 模块 | 文件数 | 问题总数 | 高 | 中 | 低 |
|-------|------|--------|---------|----|----|-----|
| A1 | API 路由 | 13 | N | N | N | N |
| ... | ... | ... | ... | ... | ... | ... |

## 高风险问题
...

## 各模块详情
...

## 问题类型分布
- 死代码: N (N%)
- 潜在 Bug: N (N%)
- 代码坏味道: N (N%)
```
