# 修复 pure_mode 和 login_timeout 配置丢失

> **For agentic workers:** REQUIRED SUB-SKILL: Use subagent-driven-development (recommended) or executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 修复两个配置字段在传输链路中丢失的 bug，确保用户设置的 `pure_mode` 和 `login_timeout` 能正确传递到 Worker。

**Architecture:** 两个 bug 的根因类似——`GlobalSettings` 中的字段在构建运行时配置时被遗漏。修复方式是补充缺失的字段映射，不改变现有架构。

**Tech Stack:** Python, Pydantic v2, pytest

---

## Bug 分析

### Bug 1: pure_mode 丢失

**影响链路：**
```
定时任务/手动登录 → task_executor.execute_login()
  → config = engine.get_runtime_config()        ← build_runtime_config() 构建
  → pure_mode = config["browser_settings"]["pure_mode"]  ← 不存在，永远 False
  → 传给 Worker 的 data 中 pure_mode=False      ← 应该为 True
```

**根因：** `config_service.py:144-159` 构建 `browser_settings` 时遗漏了 `pure_mode`。

### Bug 2: login_timeout 丢失

**影响链路：**
```
GlobalSettings.login_timeout = 60s (用户设置)
  → runtime_config.py:125 正确读取并放入 payload_dict
  → MonitorConfigPayload(**payload_dict)  ← 没有 login_timeout 字段，Pydantic 静默丢弃
  → engine.py:737 getattr(self._ui_config, "login_timeout", 120)  ← 永远返回 120
```

**根因：** `_SystemFieldsMixin` 没有 `login_timeout` 字段，导致 Pydantic 创建 `MonitorConfigPayload` 时静默丢弃该值。

---

## 文件变更清单

| 文件 | 变更类型 | 说明 |
|------|----------|------|
| `app/services/config_service.py:144-177` | 修改 | `browser_settings` 字典补充 `pure_mode` |
| `app/schemas.py:151-183` | 修改 | `_SystemFieldsMixin` 补充 `login_timeout` 字段 |
| `tests/test_app/test_backend_services.py` | 修改 | 补充 `pure_mode` 和 `login_timeout` 的测试 |

---

### Task 1: 修复 pure_mode 丢失

**Files:**
- Modify: `app/services/config_service.py:144-177`
- Test: `tests/test_app/test_backend_services.py`

- [ ] **Step 1: 在 build_runtime_config 的 browser_settings 中添加 pure_mode**

`app/services/config_service.py` 第 144-159 行，`global_settings` 分支：

```python
# 浏览器配置 — 从 GlobalSettings 获取
if global_settings:
    base["browser_settings"] = {
        "headless": global_settings.headless,
        "timeout": global_settings.browser_timeout,
        "navigation_timeout": global_settings.browser_navigation_timeout,
        "user_agent": global_settings.browser_user_agent.strip(),
        "low_resource_mode": global_settings.browser_low_resource_mode,
        "disable_web_security": global_settings.browser_disable_web_security,
        "extra_headers_json": global_settings.browser_extra_headers_json,
        "browser_args": global_settings.browser_args.strip(),
        "stealth_mode": global_settings.stealth_mode,
        "stealth_custom_script": global_settings.stealth_custom_script.strip(),
        "locale": global_settings.browser_locale.strip(),
        "timezone_id": global_settings.browser_timezone.strip(),
        "viewport_width": global_settings.browser_viewport_width,
        "viewport_height": global_settings.browser_viewport_height,
        "pure_mode": global_settings.pure_mode,  # ← 新增
    }
```

第 160-177 行，`else` 回退分支：

```python
else:
    # 回退：使用默认值
    base["browser_settings"] = {
        "headless": True,
        "timeout": 8,
        "navigation_timeout": 15,
        "user_agent": "",
        "low_resource_mode": False,
        "disable_web_security": False,
        "extra_headers_json": "",
        "browser_args": "",
        "stealth_mode": False,
        "stealth_custom_script": "",
        "locale": "zh-CN",
        "timezone_id": "Asia/Shanghai",
        "viewport_width": 1280,
        "viewport_height": 720,
        "pure_mode": True,  # ← 新增，与 GlobalSettings 默认值一致
    }
```

- [ ] **Step 2: 编写 pure_mode 测试**

`tests/test_app/test_backend_services.py`，在 `TestBuildRuntimeConfig` 类中添加：

```python
def test_browser_settings_pure_mode(self):
    """测试 pure_mode 正确传递到 browser_settings"""
    payload = MonitorConfigPayload()

    # 默认值应为 True
    gs_default = GlobalSettings()
    config = build_runtime_config(payload, global_settings=gs_default)
    assert config["browser_settings"]["pure_mode"] is True

    # 显式设置为 False
    gs_false = GlobalSettings(pure_mode=False)
    config = build_runtime_config(payload, global_settings=gs_false)
    assert config["browser_settings"]["pure_mode"] is False

    # 无 global_settings 时回退默认值
    config = build_runtime_config(payload)
    assert config["browser_settings"]["pure_mode"] is True
```

- [ ] **Step 3: 运行测试验证**

Run: `pytest tests/test_app/test_backend_services.py::TestBuildRuntimeConfig -v`
Expected: 全部 PASS，包括新增的 `test_browser_settings_pure_mode`

- [ ] **Step 4: 提交**

```bash
git add app/services/config_service.py tests/test_app/test_backend_services.py
git commit -m "fix: 补充 build_runtime_config 中遗漏的 pure_mode 字段"
```

---

### Task 2: 修复 login_timeout 丢失

**Files:**
- Modify: `app/schemas.py:151-183`
- Test: `tests/test_app/test_backend_services.py`

- [ ] **Step 1: 在 _SystemFieldsMixin 中添加 login_timeout 字段**

`app/schemas.py` 第 151-183 行，在 `_SystemFieldsMixin` 类中添加 `login_timeout`：

```python
class _SystemFieldsMixin(BaseModel):
    """SystemSettings 与 MonitorConfigPayload 共享的系统配置字段"""

    username: str = Field(default="", description="全局校园网用户名")
    password: str = Field(default="", description="全局校园网密码（ENC: 加密）")
    auth_url: str = Field(default="", description="全局认证地址")
    carrier: str = Field(default="无", description="全局运营商")
    carrier_custom: str = Field(default="", description="自定义运营商关键字")
    pause_enabled: bool = Field(default=True, description="启用暂停时段")
    pause_start_hour: int = Field(default=0, ge=0, le=23, description="暂停开始（小时）")
    pause_end_hour: int = Field(default=6, ge=0, le=23, description="暂停结束（小时）")
    backend_log_level: str = Field(default="INFO")
    frontend_log_level: str = Field(default="INFO")
    access_log: bool = Field(default=False, description="Uvicorn HTTP 请求日志")
    startup_action: StartupAction = Field(
        default=StartupAction.NONE,
        description="启动行为：none=不自动执行, monitor=自动监控, login_once=自动登录成功后退出",
    )
    autostart_lightweight: bool = Field(
        default=True, description="自启动轻量模式：True=仅监控, False=完整模式(含Web)"
    )
    minimize_to_tray: bool = Field(default=True, description="最小化到系统托盘")
    auto_open_browser: bool = Field(default=False, description="启动后自动打开浏览器")
    max_retries: int = Field(default=3, ge=0, le=10)
    retry_interval: int = Field(default=5, ge=1, le=300, description="重试间隔（秒）")
    log_retention_days: int = Field(
        default=7, ge=1, le=365, description="日志保留天数"
    )
    app_port: int = Field(default=50721, ge=1024, le=65535, description="网页界面端口")
    proxy: str = Field(default="", description="网络代理地址")
    shell_path: str = Field(
        default="", description="自定义 Shell 路径（留空使用系统默认）"
    )
    login_timeout: int = Field(
        default=60, ge=10, le=600, description="手动登录等待超时（秒）"
    )  # ← 新增
```

- [ ] **Step 2: 编写 login_timeout 测试**

`tests/test_app/test_backend_services.py`，在 `TestBuildRuntimeConfig` 类中添加：

```python
def test_login_timeout_in_payload(self):
    """测试 login_timeout 正确通过 MonitorConfigPayload 传递"""
    # 默认值应为 60
    payload_default = MonitorConfigPayload()
    assert payload_default.login_timeout == 60

    # 显式设置值
    payload_custom = MonitorConfigPayload(login_timeout=120)
    assert payload_custom.login_timeout == 120

    # 边界值
    payload_min = MonitorConfigPayload(login_timeout=10)
    assert payload_min.login_timeout == 10

    payload_max = MonitorConfigPayload(login_timeout=600)
    assert payload_max.login_timeout == 600
```

- [ ] **Step 3: 运行测试验证**

Run: `pytest tests/test_app/test_backend_services.py::TestBuildRuntimeConfig -v`
Expected: 全部 PASS，包括新增的 `test_login_timeout_in_payload`

- [ ] **Step 4: 提交**

```bash
git add app/schemas.py tests/test_app/test_backend_services.py
git commit -m "fix: 在 _SystemFieldsMixin 中补充 login_timeout 字段"
```

---

### Task 3: 验证完整链路

- [ ] **Step 1: 运行所有相关测试**

Run: `pytest tests/test_app/test_backend_services.py tests/test_services/test_config_service.py tests/test_config/test_config_schemas.py -v`
Expected: 全部 PASS

- [ ] **Step 2: 运行全量测试确保无回归**

Run: `pytest tests/ -v --tb=short`
Expected: 全部 PASS

- [ ] **Step 3: 更新修改日志**

`.claude/change.md` 在 `## 2026-06-15` 下添加：

```markdown
### fix
- 修复 `build_runtime_config()` 中 `browser_settings` 遗漏 `pure_mode` 字段
  - TaskExecutor 路径（定时任务/手动登录）的 Worker 永远收到 `pure_mode=False`
  - Engine 自动登录路径通过 `_handle_start()` 显式注入绕过了此遗漏
  - 在 `config_service.py:144-177` 的两个分支中补充 `"pure_mode"` 字段
- 修复 `_SystemFieldsMixin` 遗漏 `login_timeout` 字段
  - `runtime_config.py:125` 正确读取了 `GlobalSettings.login_timeout`，但 `MonitorConfigPayload` 没有该字段
  - Pydantic v2 默认忽略额外字段，导致值被静默丢弃
  - `engine.py:737` 的 `getattr` 回退到硬编码 120s，用户设置永远不生效
  - 在 `_SystemFieldsMixin` 中补充 `login_timeout` 字段（默认 60s，范围 10-600）
```

- [ ] **Step 4: 最终提交**

```bash
git add .claude/change.md
git commit -m "docs: 记录 pure_mode 和 login_timeout 修复"
```

---

## 自检清单

- [x] **规格覆盖：** 两个 bug 都有对应的 Task
- [x] **占位符扫描：** 无 TBD/TODO，所有代码完整
- [x] **类型一致性：** `pure_mode` (bool)、`login_timeout` (int) 类型在所有位置一致
- [x] **测试覆盖：** 每个修复都有对应的单元测试
- [x] **回退值一致：** `pure_mode` 回退值 `True` 与 `GlobalSettings.pure_mode` 默认值一致；`login_timeout` 回退值 `60` 与 `GlobalSettings.login_timeout` 默认值一致
