# 后端代码简化实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 删除 4 处过度设计的代码间接层，减少约 60 行代码，不改变任何外部行为。

**Architecture:** 纯重构，不改架构。每个任务独立，可单独提交。改动范围：engine.py（2 处）、config_service.py（1 处）、monitor_service.py（1 处）。

**Tech Stack:** Python 3.12+, Pydantic v2, loguru, pytest

---

## 文件变更总览

| 文件 | 任务 | 变更 |
|------|------|------|
| `app/services/engine.py` | Task 1, Task 2 | 去 `_enqueue` 重试；`_CMD_ROUTES` → if/elif |
| `app/services/config_service.py` | Task 3 | `_update_system_settings` / `_update_default_profile` 用 `model_copy` |
| `app/services/monitor_service.py` | Task 4 | `_update_state` 去反射，改为显式参数 |

---

### Task 1: `_enqueue` 去重试

**Files:**
- Modify: `app/services/engine.py:170-181`

- [ ] **Step 1: 运行现有测试确认绿色**

```bash
uv run pytest tests/test_services/test_monitor_service_fix.py tests/test_core/test_monitor.py -v
```

Expected: 全部 PASS

- [ ] **Step 2: 修改 `_enqueue` 方法**

找到 `app/services/engine.py` 中的 `_enqueue` 方法（第 170-181 行），将：

```python
    def _enqueue(self, cmd: EngineCommand, retries: int = 2) -> bool:
        """尝试将命令入队，带重试。返回 True 表示成功。"""
        for attempt in range(retries):
            try:
                self._cmd_queue.put_nowait(cmd)
                return True
            except queue.Full:
                if attempt < retries - 1:
                    time.sleep(0.05)
                else:
                    logger.warning("命令队列已满 (type={})，操作被跳过", cmd.type)
        return False
```

替换为：

```python
    def _enqueue(self, cmd: EngineCommand) -> bool:
        """尝试将命令入队。返回 True 表示成功。"""
        try:
            self._cmd_queue.put_nowait(cmd)
            return True
        except queue.Full:
            logger.warning("命令队列已满 (type={})，操作被跳过", cmd.type)
            return False
```

- [ ] **Step 3: 运行测试确认无回归**

```bash
uv run pytest tests/test_services/test_monitor_service_fix.py tests/test_core/test_monitor.py tests/test_services/test_scheduler_service.py -v
```

Expected: 全部 PASS

- [ ] **Step 4: 提交**

```bash
git add app/services/engine.py
git commit -m "refactor: engine _enqueue 去除无意义的重试逻辑"
```

---

### Task 2: `_CMD_ROUTES` → if/elif

**Files:**
- Modify: `app/services/engine.py:186-193,263-274`
- Modify: `app/workers/playwright_worker.py:370-408`

#### Task 2a: engine.py

- [ ] **Step 1: 运行现有测试确认绿色**

```bash
uv run pytest tests/ -v --timeout=30
```

Expected: 全部 PASS

- [ ] **Step 2: 删除 `_CMD_ROUTES` 类变量**

找到 `app/services/engine.py` 中的 `_CMD_ROUTES`（第 186-193 行），整段删除：

```python
    # 命令类型 → handler 方法名
    _CMD_ROUTES: dict[EngineCmdType, str] = {
        EngineCmdType.START: "_handle_start",
        EngineCmdType.STOP: "_handle_stop",
        EngineCmdType.LOGIN: "_handle_login",
        EngineCmdType.SHUTDOWN: "_handle_shutdown",
        EngineCmdType.RELOAD: "_handle_reload",
        EngineCmdType.APPLY_PROFILE: "_handle_apply_profile",
    }
```

- [ ] **Step 3: 替换 `_process_command` 方法**

找到 `_process_command`（第 263-274 行），将：

```python
    def _process_command(self, cmd: EngineCommand) -> None:
        """处理一个命令。"""
        try:
            handler_name = self._CMD_ROUTES.get(cmd.type)
            if handler_name:
                getattr(self, handler_name)(cmd)
        except Exception:
            logger.exception("命令执行失败: {}", cmd.type)
        finally:
            if cmd.response_event:
                cmd.response_event.set()
            self._cmd_queue.task_done()
```

替换为：

```python
    def _process_command(self, cmd: EngineCommand) -> None:
        """处理一个命令。"""
        try:
            if cmd.type == EngineCmdType.START:
                self._handle_start(cmd)
            elif cmd.type == EngineCmdType.STOP:
                self._handle_stop(cmd)
            elif cmd.type == EngineCmdType.LOGIN:
                self._handle_login(cmd)
            elif cmd.type == EngineCmdType.SHUTDOWN:
                self._handle_shutdown(cmd)
            elif cmd.type == EngineCmdType.RELOAD:
                self._handle_reload(cmd)
            elif cmd.type == EngineCmdType.APPLY_PROFILE:
                self._handle_apply_profile(cmd)
        except Exception:
            logger.exception("命令执行失败: {}", cmd.type)
        finally:
            if cmd.response_event:
                cmd.response_event.set()
            self._cmd_queue.task_done()
```

- [ ] **Step 4: 运行测试确认无回归**

```bash
uv run pytest tests/ -v --timeout=30
```

Expected: 全部 PASS

#### Task 2b: playwright_worker.py

- [ ] **Step 5: 删除 `_CMD_ROUTES` 类变量**

找到 `app/workers/playwright_worker.py` 中的 `_CMD_ROUTES`（第 370-379 行），整段删除：

```python
    # 命令类型 → (handler 方法名, 是否需要 data 参数)
    _CMD_ROUTES: dict[str, tuple[str, bool]] = {
        CMD_LOGIN: ("_handle_login", True),
        CMD_DEBUG_START: ("_handle_debug_start", True),
        CMD_DEBUG_STEP: ("_handle_debug_step", True),
        CMD_DEBUG_STOP: ("_handle_debug_stop", False),
        CMD_BROWSER_ACQUIRE: ("_handle_browser_acquire", True),
        CMD_BROWSER_RELEASE: ("_handle_browser_release", False),
        CMD_BROWSER_CLOSE: ("_handle_browser_close", False),
        CMD_BROWSER_HEALTH_CHECK: ("_handle_health_check", False),
    }
```

- [ ] **Step 6: 替换 `_dispatch` 方法**

找到 `_dispatch`（第 381-408 行），将：

```python
    async def _dispatch(self, cmd: WorkerCommand) -> None:
        """派发 WorkerCommand 到对应的异步处理函数。

        根据 cmd.type 路由到对应的 _handle_* 方法，
        将返回值设为 cmd.response_data 并通知等待方。
        """
        try:
            route = self._CMD_ROUTES.get(cmd.type)
            if route:
                handler_name, needs_data = route
                handler = getattr(self, handler_name)
                result = await handler(cmd.data) if needs_data else await handler()
            elif cmd.type == CMD_SHUTDOWN:
                result = WorkerResponse(success=True, data="Worker 正在关闭")
            else:
                result = WorkerResponse(
                    success=False, error=f"未知命令类型: {cmd.type}"
                )

            cmd.response_data = result
        except Exception as e:
            logger.exception("命令 {} 执行异常", cmd.type)
            cmd.response_data = WorkerResponse(
                success=False, error=f"命令执行异常: {e}"
            )
        finally:
            if cmd.response_event:
                cmd.response_event.set()
```

替换为：

```python
    async def _dispatch(self, cmd: WorkerCommand) -> None:
        """派发 WorkerCommand 到对应的异步处理函数。

        根据 cmd.type 路由到对应的 _handle_* 方法，
        将返回值设为 cmd.response_data 并通知等待方。
        """
        try:
            if cmd.type == CMD_LOGIN:
                result = await self._handle_login(cmd.data)
            elif cmd.type == CMD_DEBUG_START:
                result = await self._handle_debug_start(cmd.data)
            elif cmd.type == CMD_DEBUG_STEP:
                result = await self._handle_debug_step(cmd.data)
            elif cmd.type == CMD_DEBUG_STOP:
                result = await self._handle_debug_stop()
            elif cmd.type == CMD_BROWSER_ACQUIRE:
                result = await self._handle_browser_acquire(cmd.data)
            elif cmd.type == CMD_BROWSER_RELEASE:
                result = await self._handle_browser_release()
            elif cmd.type == CMD_BROWSER_CLOSE:
                result = await self._handle_browser_close()
            elif cmd.type == CMD_BROWSER_HEALTH_CHECK:
                result = await self._handle_health_check()
            elif cmd.type == CMD_SHUTDOWN:
                result = WorkerResponse(success=True, data="Worker 正在关闭")
            else:
                result = WorkerResponse(
                    success=False, error=f"未知命令类型: {cmd.type}"
                )

            cmd.response_data = result
        except Exception as e:
            logger.exception("命令 {} 执行异常", cmd.type)
            cmd.response_data = WorkerResponse(
                success=False, error=f"命令执行异常: {e}"
            )
        finally:
            if cmd.response_event:
                cmd.response_event.set()
```

- [ ] **Step 7: 运行测试确认无回归**

```bash
uv run pytest tests/ -v --timeout=30
```

Expected: 全部 PASS

- [ ] **Step 8: 提交**

```bash
git add app/services/engine.py app/workers/playwright_worker.py
git commit -m "refactor: _CMD_ROUTES 间接派发改为直接 if/elif"
```

---

### Task 3: `model_copy` 替代合并验证

**Files:**
- Modify: `app/services/config_service.py:419-423,470-474`

- [ ] **Step 1: 运行现有测试确认绿色**

```bash
uv run pytest tests/test_api/test_config_fix.py tests/test_api/test_api_config_routes.py tests/test_config/test_config_schemas.py -v
```

Expected: 全部 PASS

- [ ] **Step 2: 修改 `_update_system_settings` 中的验证逻辑**

找到 `app/services/config_service.py` 中 `_update_system_settings` 函数内的这 3 行（第 419-423 行）：

```python
    merged = {**system_settings.model_dump(), **update_data}
    validated = type(system_settings).model_validate(merged)
    for field in field_list:
        if field in update_data:
            setattr(system_settings, field, getattr(validated, field))
```

替换为：

```python
    updated = system_settings.model_copy(update=update_data)
    for field in field_list:
        if field in update_data:
            setattr(system_settings, field, getattr(updated, field))
```

- [ ] **Step 3: 修改 `_update_default_profile` 中的验证逻辑**

找到 `_update_default_profile` 函数内的这 3 行（第 470-474 行）：

```python
    merged = {**default_profile.model_dump(), **update_data}
    validated = type(default_profile).model_validate(merged)
    for field in field_list:
        if field in update_data:
            setattr(default_profile, field, getattr(validated, field))
```

替换为：

```python
    updated = default_profile.model_copy(update=update_data)
    for field in field_list:
        if field in update_data:
            setattr(default_profile, field, getattr(updated, field))
```

- [ ] **Step 4: 运行测试确认无回归**

```bash
uv run pytest tests/test_api/test_config_fix.py tests/test_api/test_api_config_routes.py tests/test_config/test_config_schemas.py tests/test_services/test_system_services.py -v
```

Expected: 全部 PASS

- [ ] **Step 5: 提交**

```bash
git add app/services/config_service.py
git commit -m "refactor: 配置更新用 model_copy 替代合并字典+全量验证"
```

---

### Task 4: `_update_state` 去反射

**Files:**
- Modify: `app/services/monitor_service.py:100-107`

- [ ] **Step 1: 运行现有测试确认绿色**

```bash
uv run pytest tests/test_services/test_monitor_service_fix.py tests/test_core/test_monitor.py -v
```

Expected: 全部 PASS

- [ ] **Step 2: 替换 `_update_state` 方法**

找到 `app/services/monitor_service.py` 中的 `_update_state`（第 100-107 行），将：

```python
    def _update_state(self, **kwargs: Any) -> None:
        """线程安全地更新状态字段。

        用法: self._update_state(monitoring=True, status_detail="...")
        """
        with self._state_lock:
            for k, v in kwargs.items():
                setattr(self, k, v)
```

替换为：

```python
    def _update_state(
        self,
        *,
        monitoring: bool | None = None,
        network_check_count: int | None = None,
        login_attempt_count: int | None = None,
        start_time: float | None = None,
        last_check_time: datetime.datetime | None = None,
        network_state: NetworkState | None = None,
        status_detail: str | None = None,
    ) -> None:
        """线程安全地更新状态字段。仅更新非 None 的字段。"""
        with self._state_lock:
            if monitoring is not None:
                self.monitoring = monitoring
            if network_check_count is not None:
                self.network_check_count = network_check_count
            if login_attempt_count is not None:
                self.login_attempt_count = login_attempt_count
            if start_time is not None:
                self.start_time = start_time
            if last_check_time is not None:
                self.last_check_time = last_check_time
            if network_state is not None:
                self.network_state = network_state
            if status_detail is not None:
                self.status_detail = status_detail
```

- [ ] **Step 3: 运行测试确认无回归**

```bash
uv run pytest tests/test_services/test_monitor_service_fix.py tests/test_core/test_monitor.py tests/test_services/test_scheduler_service.py -v
```

Expected: 全部 PASS

- [ ] **Step 4: 提交**

```bash
git add app/services/monitor_service.py
git commit -m "refactor: _update_state 去反射，改为显式参数"
```

---

## 执行顺序

```
Task 1  →  Task 2a  →  Task 2b  →  Task 3  →  Task 4
(engine)   (engine)   (worker)   (config)   (monitor)
```

Task 1 和 Task 2a 改同一文件（engine.py），建议一起做。Task 2b、Task 3、Task 4 各改不同文件，互相独立。

## 验证

全部完成后运行完整测试套件：

```bash
uv run pytest tests/ -v --timeout=30
```

Expected: 全部 PASS，无新增失败。
