# 修复已验证问题实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use subagent-driven-development (recommended) or executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 修复代码审查报告中已验证的 9 个问题（2 个 Bug + 7 个死代码）

**Architecture:** 
1. 修复 B1 端口配置无效 - 修正路径和 JSON 键
2. 修复 B3 密码回退不可达 - 删除无用的回退代码
3. 清理 D1-D7 死代码 - 删除无用的函数和常量

**Tech Stack:** Python

---

## 文件结构

### 修改的文件
- `app/utils/ports.py` - 修复端口配置路径
- `app/services/config_service.py` - 删除密码回退代码
- `app/utils/notify.py` - 删除 send_notification
- `app/utils/config_utils.py` - 删除 extract_profile_fields, validate_gui_config, PROFILE_FIELDS, GLOBAL_FIELDS
- `app/utils/crypto.py` - 删除 is_encrypted
- `app/services/runtime_config.py` - 删除 _normalize_targets

### 删除的测试
- `tests/test_utils/test_src_utils.py` - 删除 send_notification 测试
- `tests/test_utils/test_utils.py` - 删除 extract_profile_fields, is_encrypted 测试
- `tests/test_config/test_config_schemas.py` - 删除 validate_gui_config 测试
- `tests/test_utils/test_config_utils_fix.py` - 删除 PROFILE_FIELDS 测试

---

### Task 1: 修复 B1 端口配置无效

**Files:**
- Modify: `app/utils/ports.py`

- [ ] **Step 1: 修复端口配置路径和 JSON 键**

在 `app/utils/ports.py` 中，修改 `resolve_port` 函数：

```python
def resolve_port() -> int:
    """解析应用监听端口。

    优先级：环境变量 APP_PORT > config/settings.json global_settings.app_port > 默认 50721。
    """
    raw = os.getenv("APP_PORT", "").strip()
    if raw:
        try:
            port = int(raw)
            if 1 <= port <= 65535:
                return port
        except ValueError:
            _startup_logger.warning("端口解析失败，使用默认 {}", _DEFAULT_PORT)

    # 修正：读取 config/settings.json 而非 settings.json
    settings_path = PROJECT_ROOT / "config" / "settings.json"
    if settings_path.exists():
        try:
            data = json.loads(settings_path.read_text(encoding="utf-8"))
            # 修正：读取 global_settings.app_port 而非 system.app_port
            app_port = data.get("global_settings", {}).get("app_port")
            if app_port is not None:
                port = int(app_port)
                if 1 <= port <= 65535:
                    return port
        except (json.JSONDecodeError, ValueError, OSError) as exc:
            _startup_logger.warning(
                "读取 config/settings.json 端口配置失败，使用默认端口 {}: {}",
                _DEFAULT_PORT,
                exc,
            )

    return _DEFAULT_PORT
```

- [ ] **Step 2: 运行测试**

Run: `PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest tests/ -q --tb=short`
Expected: 所有测试通过

- [ ] **Step 3: 提交**

```bash
git add app/utils/ports.py
git commit -m "fix: 修复端口配置路径和 JSON 键 (B1)"
```

---

### Task 2: 修复 B3 密码回退不可达

**Files:**
- Modify: `app/services/config_service.py`

- [ ] **Step 1: 删除不可达的密码回退代码**

在 `app/services/config_service.py` 中，修改 `build_runtime_config` 函数：

```python
    # 账号密码
    base: dict[str, Any] = {"password": ""}
    base["username"] = payload.username.strip()
    raw_password = payload.password.strip()
    if raw_password and not raw_password.startswith("•"):
        base["password"] = raw_password
    # 删除 elif global_settings 分支（GlobalSettings 没有 password 字段，永远不可达）
```

- [ ] **Step 2: 运行测试**

Run: `PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest tests/ -q --tb=short`
Expected: 所有测试通过

- [ ] **Step 3: 提交**

```bash
git add app/services/config_service.py
git commit -m "fix: 删除不可达的密码回退代码 (B3)"
```

---

### Task 3: 清理 D1 send_notification 死代码

**Files:**
- Modify: `app/utils/notify.py`
- Delete: `tests/test_utils/test_src_utils.py` (删除 send_notification 相关测试)

- [ ] **Step 1: 删除 send_notification 函数**

在 `app/utils/notify.py` 中，删除 `send_notification` 函数及其相关代码。

- [ ] **Step 2: 删除相关测试**

删除或修改 `tests/test_utils/test_src_utils.py` 中的 `send_notification` 测试。

- [ ] **Step 3: 运行测试**

Run: `PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest tests/ -q --tb=short`
Expected: 所有测试通过

- [ ] **Step 4: 提交**

```bash
git add app/utils/notify.py tests/
git commit -m "refactor: 删除 send_notification 死代码 (D1)"
```

---

### Task 4: 清理 D2-D5 config_utils 死代码

**Files:**
- Modify: `app/utils/config_utils.py`
- Delete: `tests/test_utils/test_utils.py` (删除 extract_profile_fields 测试)
- Delete: `tests/test_config/test_config_schemas.py` (删除 validate_gui_config 测试)
- Delete: `tests/test_utils/test_config_utils_fix.py` (删除 PROFILE_FIELDS 测试)

- [ ] **Step 1: 删除死代码**

在 `app/utils/config_utils.py` 中，删除以下内容：
- `PROFILE_FIELDS` 常量（第 16 行）
- `GLOBAL_FIELDS` 常量（第 26 行）
- `extract_profile_fields` 函数（第 81 行）
- `validate_gui_config` 方法（第 116 行）

- [ ] **Step 2: 删除相关测试**

删除或修改相关测试文件中的死代码测试。

- [ ] **Step 3: 运行测试**

Run: `PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest tests/ -q --tb=short`
Expected: 所有测试通过

- [ ] **Step 4: 提交**

```bash
git add app/utils/config_utils.py tests/
git commit -m "refactor: 删除 config_utils 死代码 (D2-D5)"
```

---

### Task 5: 清理 D6 is_encrypted 死代码

**Files:**
- Modify: `app/utils/crypto.py`
- Delete: `tests/test_utils/test_utils.py` (删除 is_encrypted 测试)

- [ ] **Step 1: 删除 is_encrypted 函数**

在 `app/utils/crypto.py` 中，删除 `is_encrypted` 函数（第 183 行）。

- [ ] **Step 2: 删除相关测试**

删除或修改 `tests/test_utils/test_utils.py` 中的 `is_encrypted` 测试。

- [ ] **Step 3: 运行测试**

Run: `PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest tests/ -q --tb=short`
Expected: 所有测试通过

- [ ] **Step 4: 提交**

```bash
git add app/utils/crypto.py tests/
git commit -m "refactor: 删除 is_encrypted 死代码 (D6)"
```

---

### Task 6: 清理 D7 _normalize_targets 死代码

**Files:**
- Modify: `app/services/runtime_config.py`

- [ ] **Step 1: 删除 _normalize_targets 函数**

在 `app/services/runtime_config.py` 中，删除 `_normalize_targets` 函数（第 52-56 行）。

- [ ] **Step 2: 运行测试**

Run: `PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest tests/ -q --tb=short`
Expected: 所有测试通过

- [ ] **Step 3: 提交**

```bash
git add app/services/runtime_config.py
git commit -m "refactor: 删除 _normalize_targets 死代码 (D7)"
```

---

## 验证方法

1. 运行所有测试：`PYTHONPATH=. ./.venv/Scripts/python.exe -m pytest -q`
2. 运行代码检查：`./.venv/Scripts/python.exe -m ruff check app/`
3. 手动测试端口配置：修改 `config/settings.json` 中的 `app_port`，重启应用验证端口是否生效
