# Campus-Auth 全量代码审计报告

**审计日期:** 2026-06-15
**审计范围:** Python 后端 (~68 文件) + Vue 3 前端 (36 JS + 19 HTML + 13 CSS) + 测试 (58 文件)
**方法:** 9 个独立 Agent 按模块分工并行审查

---

## 概览

| Agent | 模块 | 文件数 | 问题总数 | 高 | 中 | 低 |
|-------|------|--------|---------|----|----|-----|
| A1 | API 路由层 | 13 | 18 | 2 | 3 | 13 |
| A2 | 核心服务 | 4 | 24 | 2 | 5 | 17 |
| A3 | 支持服务 | 10 | 23 | 0 | 5 | 18 |
| A4 | Workers + 任务引擎 | 9 | 39 | 1 | 10 | 28 |
| A5 | Utils 工具模块 | 19 | 26 | 0 | 4 | 22 |
| A6 | 应用基础设施 | 12 | 21 | 1 | 8 | 12 |
| A7 | 前端 JS | 36 | 16 | 0 | 5 | 11 |
| A8 | 前端 HTML/CSS | 32 | 13 | 2 | 2 | 9 |
| A9 | 测试代码 | 58 | 21 | 3 | 9 | 9 |
| **合计** | | **~194** | **201** | **11** | **51** | **139** |

### 问题类型分布

| 类型 | 数量 | 占比 |
|------|------|------|
| 潜在 Bug | ~67 | 33% |
| 代码坏味道 | ~124 | 62% |
| 死代码 | ~10 | 5% |

---

## 高风险问题（11个，需优先处理）

### 1. `app/api/scheduled_tasks.py:98` — schedule 字段未做类型检查
**严重度: 高**
`**payload["schedule"]` 假设 `payload["schedule"]` 必定是 dict。若客户端传入字符串，抛出 `TypeError` 导致 500。

### 2. `app/api/scheduled_tasks.py:48` — 同上，_validate_create_payload 中未检查 schedule 类型
**严重度: 高**

### 3. `app/services/engine.py:826` — `_task_executor` 为 None 时崩溃
**严重度: 高**
`has_enabled_tasks()` 直接调用 `self._task_executor.has_enabled_tasks()`，但构造函数允许 `_task_executor` 为 None。

### 4. `app/services/task_executor.py:200-213` — 登录去重 cancel_event 无效
**严重度: 高**
去重逻辑中，cancel_event 与正在运行的 Future 不是同一个对象，调用 `cancel_event.set()` 不生效。

### 5. `app/tasks/step_handlers.py:492` — TimeoutError 异常类型不匹配
**严重度: 高**
捕获内置 `TimeoutError`，但 Playwright ≥1.60 的超时异常不继承自内置 TimeoutError，导致超时异常冒泡到通用 except。

### 6. `app/network/decision.py:125` — check_auth_url 默认值与 Schema 冲突
**严重度: 高**
代码中 `config.get("check_auth_url", True)` 默认 True，但 Schema 定义默认 False，行为不一致。

### 7. `frontend/partials/pages/tasks.html:63` — onDragLeave 方法未定义
**严重度: 高**
`@dragleave="onDragLeave($event)"` 绑定了 drag.js 中不存在的方法，拖动时抛出 TypeError。

### 8. `frontend/partials/pages/scripts.html:42` — 同上，onDragLeave 未定义
**严重度: 高**

### 9. `tests/test_services/test_monitor_service.py:371-416` — ScheduleEngine.__new__ 绕过 __init__
**严重度: 高**
6 处测试使用 `ScheduleEngine.__new__(ScheduleEngine)` + 手动属性赋值绕过构造函数，若构造函数添加关键初始化则测试无法捕获。

### 10. `tests/test_utils/test_utils.py:967-979` — caplog + loguru 不兼容
**严重度: 高**
caplog 捕获标准 logging 但项目使用 loguru，密码明文泄漏审计测试形同虚设。

### 11. `tests/test_utils/test_utils.py:736-770` — LogConfigCenter 单例测试间耦合
**严重度: 高**
LogConfigCenter 是单例，测试间状态未重置，后续测试依赖前序测试状态。

---

## 各模块详情

### A1: API 路由层 (18 问题)
- `scheduled_tasks.py:` **2 x 高** — schedule 字段未做类型校验
- `scripts.py:` 中 — ThreadPoolExecutor 泄漏
- `ocr.py:` 中 — tomllib 兼容 Python ≥3.11
- `config.py:` 中 — 日志级别持久化依赖不明
- `autostart.py:` 中 — 轻量模式绕过依赖注入，手动构造 ProfileService（重复代码）

### A2: 核心服务 (24 问题)
- `engine.py:` **1 x 高** — `_task_executor` 为 None 时崩溃
- `engine.py:` 2 x 中 — `_dashboard_sink` 死代码、async WS drain 无事件循环
- `task_executor.py:` **1 x 高** — 登录去重 cancel_event 无效
- `task_executor.py:` 1 x 中 — Shell allowlist 空列表风险
- `monitor_service.py:` 1 x 中 — profile switch 宽泛 except 掩盖错误
- 死代码: engine.py 中 `_dashboard_sink` 赋值后永不注入、`log_msg` 赋值后未使用

### A3: 支持服务 (23 问题)
- `login_history_service.py:` 1 x 死代码 — `_cleanup_lock` 从未使用
- `debug_service.py:` 中 — 浏览器关闭状态标记不一致、服务层抛出 HTTPException
- `autostart.py:` 中 — Linux `python` 可能指向 Python 2、systemd 命令中单引号未转义
- `runtime_config.py:` 中 — 与 config_service.py 大量重复的字段映射代码

### A4: Workers + 任务引擎 (39 问题)
- `step_handlers.py:` **1 x 高** — Playwright TimeoutError 无法捕获
- `step_handlers.py:` 1 x 中 — OCR char_range 实例未缓存导致内存泄漏
- `manager.py:` 1 x 中 — `_write_meta` 死代码，元数据写入逻辑缺失
- `browser_runner.py:` 1 x 中 — `cfg.get("x") or N` 模式下 0 值被吞
- `playwright_worker.py:` 2 x 中 — submit_nowait 绕过重启、竞态窗口
- `script_runner.py:` 1 x 中 — binary_path 白名单可被绕过
- `variable_resolver.py:` 1 x 中 — resolve_for_js JSON 编码引号嵌套问题

### A5: Utils 工具模块 (26 问题)
- `crypto.py:` 1 x 中 — Fernet 回退路径静默返回损坏数据
- `browser.py:` 1 x 中 — Worker 队列满导致浏览器释放命令丢失
- `shell_policy.py:` 1 x 中 — 白名单无 normpath 标准化，存在路径穿越绕过风险
- `time_utils.py:` 1 x 中 — 单调时钟与墙钟混用导致运行时统计可能为负
- `process.py:` 1 x 死代码 — `import time` 从未使用

### A6: 应用基础设施 (21 问题)
- `decision.py:` **1 x 高** — check_auth_url 默认值与 Schema 冲突
- `decision.py:` 1 x 中 — `pause_login` vs `monitor` 配置键不一致
- `schemas.py:` 2 x 中 — Mixin 字段重复 + 与 GlobalSettings 大量重复
- `main.py:` 2 x 中 — 信号处理器被 uvicorn 覆盖、_handle_existing_instance 未捕获终止异常
- `application.py:` 1 x 中 — 自定义信号处理器几乎永不执行

### A7: 前端 JS (16 问题)
- `ui.js:` 1 x 中 — CSS 选择器注入（querySelector 拼接未转义）
- `tasks/editor.js:` 1 x 中 — `_syncingFromMeta`/`_syncingFromJson` 未在 data() 中声明
- `appearance.js:` 1 x 中 — applyAppearanceEarly/applyAppearance 大量重复
- `lifecycle.js:` 1 x 中 — connectWebSocket 82 行过长
- `app.js + appearance.js + logger.js:` 低 — console.log/error 遗留

### A8: 前端 HTML/CSS (13 问题)
- `tasks.html + scripts.html:` **2 x 高** — onDragLeave 方法未定义
- `settings.html:` 1 x 中 — data-include 时序依赖
- `settings-browser.html:` 1 x 中 — btn-warning 受上下文约束
- `settings.css:` 1 x 死代码 — `.settings-tab small` 规则永不生效

### A9: 测试代码 (21 问题)
- `test_monitor_service.py:` **1 x 高** — ScheduleEngine.__new__ 绕过构造
- `test_utils.py:` **2 x 高** — caplog + loguru 不兼容 + LogConfigCenter 单例耦合
- 9 x 中 — 大量 DRY 违规、time.sleep 同步、侵入模块级变量、重复测试

---

## 死代码总结 (约 10 处)

| 文件 | 行 | 问题 |
|------|----|------|
| `app/services/engine.py` | 119 | `_dashboard_sink = None` 赋值后永不注入 |
| `app/services/engine.py` | 755 | `log_msg` 赋值后从未读取 |
| `app/services/login_history_service.py` | 44 | `_cleanup_lock` 从未使用 |
| `app/tasks/manager.py` | 119 | `_write_meta` 从未被调用 |
| `app/tasks/manager.py` | 101 | `_safe_script_path` 从未被调用 |
| `app/tasks/models.py` | 110 | `code→script` 兼容层（如已迁移则为死代码） |
| `app/utils/process.py` | 12 | `import time` 从未使用 |
| `app/utils/logging.py` | 65 | NOTSET 级别映射（loguru 永不产生 NOTSET） |
| `app/network/decision.py` | 23 | `NetworkCheckResult` 数据类从未实例化 |
| `frontend/styles/pages/settings.css` | 41 | `.settings-tab small` 样式永不生效 |

## 建议修复优先级

### 第一梯队（立即修复）
1. `step_handlers.py:492` — TimeoutError 类型不匹配
2. `scheduled_tasks.py:48,98` — schedule 类型校验
3. `engine.py:826` — 空 _task_executor 崩溃
4. `decision.py:125` — check_auth_url 默认值冲突
5. **前端 `tasks.html:63 + scripts.html:42`** — onDragLeave 方法缺失
6. `task_executor.py:200-213` — 登录去重 cancel_event 无效

### 第二梯队（本周修复）
7. `crypto.py:170-173` — Fernet 回退损坏数据
8. `shell_policy.py:117-123` — 路径白名单标准化
9. 所有中危 Bug（~46 个）
10. 测试修复（caplog+loguru、ScheduleEngine.__new__、单例耦合）

### 第三梯队（后续迭代）
11. 所有死代码清理
12. Schema 字段重复重构
13. 代码坏味道治理
