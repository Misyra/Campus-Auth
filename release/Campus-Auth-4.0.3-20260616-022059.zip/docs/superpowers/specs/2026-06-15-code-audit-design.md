# Campus-Auth 全量代码审计设计方案

## 概述

对 Campus-Auth 项目进行全面的代码质量审计，涵盖 Python 后端和 Vue 3 前端。目标：发现死代码、潜在 Bug、代码坏味道。

## 审计范围

| 范围 | 文件数 | 说明 |
|------|--------|------|
| 后端 Python | ~68 | app/ 全部 .py + main.py |
| 前端 JS | 36 | Vue 3 SPA 全部 .js 文件 |
| 前端 HTML/CSS | 32 | 19 个 partials + 13 个样式文件 |
| 测试 | 58 | tests/ 全部测试文件 |
| **总计** | **~194** | |

## 方法：按模块划分（Module-based Decomposition）

将代码库按模块边界拆分为 9 个 agent，各自独立审查指定文件范围。

### Agent 分工

| Agent | 审查范围 | 文件数 | 关键模块 |
|-------|---------|--------|---------|
| A1 | `app/api/` | 13 | 所有 API 路由 |
| A2 | `app/services/` 核心 | 4 | engine, monitor_service, task_executor, websocket_manager |
| A3 | `app/services/` 支持 | 9 | profile_service, config_service, task_service, login_history, debug_service, autostart, runtime_config, task_registry, uninstall |
| A4 | `app/workers/` + `app/tasks/` | 10 | playwright_worker, script_runner, step_handlers, browser_runner 等 |
| A5 | `app/utils/` | 19 | 所有工具模块 |
| A6 | `app/` 顶层 + network/ + ui/ + main.py | 12 | application, container, schemas, constants, deps, version, probes, detect, decision, system_tray, main.py |
| A7 | `frontend/` JS | 36 | data/, methods/, tasks/, components, constants, logger, app-options |
| A8 | `frontend/` HTML + CSS | 32 | partials/, styles/ |
| A9 | `tests/` | 58 | 全部测试文件 |

## 审计检查清单

### 第一优先级：死代码
- 未使用的 import
- 未使用的函数/方法/类
- 未使用的变量/参数
- 不可达代码
- 徒劳的表达式
- 已废弃的兼容代码

### 第二优先级：潜在 Bug
- 类型错误（注解与实际不匹配、Optional 未做 None 检查）
- 异常未处理（await 未 try/catch，可能的 KeyError/IndexError）
- 逻辑错误（条件反转、边界遗漏、`==` 与 `is` 误用）
- 竞态条件（共享变量无锁、asyncio 混用线程）
- 资源泄漏（文件/连接/浏览器未释放）
- 异步问题（async 内缺 await、同步阻塞在事件循环中）

### 第三优先级：代码坏味道
- 过长函数（>80 行）
- 过深嵌套（>4 层）
- 重复代码
- 魔法数字/字符串
- 宽泛 except
- TODO/FIXME/HACK 注释

## 输出格式

每个问题条目格式：
```
文件:path/to/file.py:行号
  - 类型: [死代码/潜在Bug/坏味道]
  - 问题: 具体描述
  - 严重度: [高/中/低]
```

## 最终报告结构

1. **概览表** — 每个 Agent 的统计
2. **高风险问题** — 严重度=高 全部汇总
3. **各模块详情** — 按 Agent 分组逐文件列出
4. **问题类型分布** — 死代码 vs Bug vs 坏味道

## 执行编排

```
启动 → A1..A9 并行 → 等待全部完成 → 结果汇总去重 → 输出报告
```

无共享状态，agent 间无依赖。
