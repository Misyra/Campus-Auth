# E2E 全量测试设计文档

## 概述

为 Campus-Auth 添加端到端测试，通过模拟校园网门户服务器 + 真实启动应用 + API 控制的方式，覆盖配置、任务、方案、脚本、定时任务、登录流程、历史记录等全功能。

## 目标

- 替代手动测试，可自动化验证核心功能
- 集成到 pytest，支持 `uv run pytest tests/e2e/` 运行
- 真实启动应用，不 mock 业务逻辑

## 文件结构

```
tests/e2e/
├── conftest.py               # 公共 fixture
├── mock_portal/              # 模拟校园网
│   ├── server.py             # FastAPI 模拟服务器
│   ├── pages/                # HTML 模拟页面
│   │   ├── normal.html       # 正常登录表单（用户名/密码/运营商）
│   │   ├── hidden.html       # 隐藏输入框场景
│   │   ├── captcha.html      # 带数学验证码
│   │   └── success.html      # 登录成功页
│   └── tasks/                # 配套测试任务 JSON
│       ├── e2e_normal.json
│       ├── e2e_hidden.json
│       └── e2e_captcha.json
├── test_config.py            # 配置修改验证
├── test_tasks.py             # 任务 CRUD + 执行
├── test_profiles.py          # 方案管理
├── test_scripts.py           # 脚本任务
├── test_scheduled.py         # 定时任务
├── test_login.py             # 真实登录流程（多场景）
└── test_history.py           # 登录历史验证
```

## 模拟服务器设计

### 技术选型
- 框架：FastAPI（复用项目依赖，支持 async）
- 端口：18080（避免冲突）
- 启动方式：session 级 fixture，测试开始前启动，结束后关闭

### 路由设计

| 路由 | 方法 | 功能 |
|------|------|------|
| `GET /normal` | GET | 正常登录表单（用户名/密码/运营商下拉框） |
| `POST /normal/login` | POST | 处理登录请求，验证表单，返回成功页 |
| `GET /hidden` | GET | 隐藏输入框表单（测试 reveal_hidden） |
| `POST /hidden/login` | POST | 处理隐藏输入框登录 |
| `GET /captcha` | GET | 带数学验证码的登录表单 |
| `POST /captcha/login` | POST | 验证码 + 登录验证 |
| `POST /callback` | POST | 登录成功回调（记录请求，供测试断言） |
| `GET /api/callbacks` | GET | 查看回调记录（测试用） |
| `DELETE /api/callbacks` | GET | 清空回调记录 |

### 回调机制

登录成功后，模拟服务器记录：
```json
{
  "timestamp": "2026-06-14T12:00:00",
  "task_id": "e2e_normal",
  "username": "test_user",
  "isp": "移动"
}
```

测试通过 `GET /api/callbacks` 查询是否收到回调。

## Fixture 设计

```python
# conftest.py

@pytest.fixture(scope="session")
def mock_portal():
    """启动模拟校园网服务器，返回 base_url"""
    ...

@pytest.fixture(scope="session")
def app_server(mock_portal):
    """启动 Campus-Auth 应用，配置指向模拟服务器"""
    ...

@pytest.fixture
def api(app_server):
    """返回 API 客户端，预配置 base_url"""
    ...
```

### app_server fixture 逻辑

1. 创建临时 settings.json（配置 auth_url 指向模拟服务器）
2. 启动 `python main.py --no-browser --no-tray`
3. 轮询 `GET /api/health` 等待启动完成
4. yield base_url
5. 调用 `POST /api/shutdown` 关闭
6. 清理临时文件

## 测试用例设计

### test_config.py - 配置修改

```python
def test_update_username(api):
    """修改用户名，验证配置生效"""
    
def test_update_auth_url(api):
    """修改认证地址，验证格式校验"""
    
def test_update_carrier(api):
    """修改运营商，验证自定义选项"""
    
def test_update_custom_variables(api):
    """修改自定义变量"""
```

### test_tasks.py - 任务管理

```python
def test_list_tasks(api):
    """获取任务列表"""
    
def test_create_task(api):
    """创建新任务"""
    
def test_update_task(api):
    """更新任务配置"""
    
def test_delete_task(api):
    """删除任务"""
    
def test_set_active_task(api):
    """切换活动任务"""
    
def test_task_order(api):
    """调整任务排序"""
```

### test_profiles.py - 配置方案

```python
def test_create_profile(api):
    """创建新方案"""
    
def test_switch_profile(api):
    """切换方案，验证配置生效"""
    
def test_delete_profile(api):
    """删除方案"""
    
def test_profile_auto_switch(api):
    """自动切换方案（模拟网关变化）"""
```

### test_scripts.py - 脚本任务

```python
def test_create_script(api):
    """创建脚本任务"""
    
def test_run_script(api):
    """执行脚本，验证输出"""
    
def test_delete_script(api):
    """删除脚本"""
```

### test_scheduled.py - 定时任务

```python
def test_create_scheduled(api):
    """创建定时任务"""
    
def test_toggle_scheduled(api):
    """启用/禁用定时任务"""
    
def test_run_scheduled_now(api):
    """立即执行定时任务"""
    
def test_scheduled_history(api):
    """查看执行历史"""
```

### test_login.py - 登录流程（核心）

```python
def test_login_normal(api, mock_portal):
    """正常登录流程：配置 → 启动监控 → 等待登录成功 → 验证回调"""
    
def test_login_hidden_input(api, mock_portal):
    """隐藏输入框场景"""
    
def test_login_with_captcha(api, mock_portal):
    """验证码场景（需要 OCR）"""
    
def test_login_failure(api, mock_portal):
    """登录失败处理"""
```

### test_history.py - 登录历史

```python
def test_login_history_recorded(api):
    """验证登录历史记录"""
    
def test_login_history_filter(api):
    """历史记录筛选"""
```

## 等待策略

### 轮询 status API
```python
def wait_for_status(api, expected, timeout=30):
    """轮询 /api/status 等待状态变化"""
    deadline = time.time() + timeout
    while time.time() < deadline:
        resp = api.get("/api/status")
        if resp.json().get("state") == expected:
            return resp.json()
        time.sleep(0.5)
    raise TimeoutError(f"等待状态 {expected} 超时")
```

### WebSocket 监听（可选增强）
```python
async def wait_for_log(ws_url, pattern, timeout=30):
    """监听 WebSocket 日志，匹配关键词"""
    async with websockets.connect(ws_url) as ws:
        async for msg in ws:
            if pattern in msg:
                return msg
```

## 依赖

- pytest
- httpx（TestClient 已有）
- requests（简单 HTTP 调用）
- websockets（可选，WebSocket 监听）

## 运行方式

```bash
# 运行全部 E2E 测试
uv run pytest tests/e2e/ -v

# 运行特定测试
uv run pytest tests/e2e/test_login.py -v

# 带详细输出
uv run pytest tests/e2e/ -v -s
```

## 注意事项

1. **端口冲突**：模拟服务器用 18080，应用用 50721
2. **测试隔离**：每个测试前后清理回调记录、重置配置
3. **超时处理**：所有等待操作设置合理超时，避免测试挂起
4. **CI 兼容**：确保在 CI 环境中也能运行（可能需要跳过 OCR 测试）
5. **Playwright 依赖**：E2E 测试需要 Playwright Chromium 已安装
