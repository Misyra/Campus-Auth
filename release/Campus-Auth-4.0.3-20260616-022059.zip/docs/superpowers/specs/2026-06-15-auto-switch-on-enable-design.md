# 开启自动切换时立即检测设计

## 目标

开启自动切换开关时，立即进行一次网络检测并切换到匹配的方案。

## 行为逻辑

### 开启自动切换
1. 用户开启自动切换开关
2. 立即进行一次网络检测（网关 IP、SSID）
3. 如果匹配到方案 → 自动切换到该方案
4. 如果没有匹配 → 保持当前方案

### 前端 UI
- 当前方案：显示 active 样式（选中特效）
- 其他方案：不可点击（pointer-events: none）
- 切换按钮：禁用，显示"自动"

## 实现方案

### 后端改动

**`app/api/profiles.py`**：
- `toggle_auto_switch` 接口开启时，触发一次 `_check_profile_switch()`

### 前端改动

**`frontend/partials/pages/profiles.html`**：
- 保持当前的禁用逻辑

**`frontend/styles/pages/profiles.css`**：
- 保持当前的 pointer-events: none 样式

## 测试

1. 开启自动切换 → 立即检测并切换到匹配方案
2. 开启自动切换但无匹配 → 保持当前方案
3. 关闭自动切换 → 恢复手动切换
4. 当前方案保持 active 样式
5. 其他方案不可点击
