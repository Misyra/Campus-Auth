# 修复 execute_login_async 死锁风险设计文档

**日期**：2026-06-15
**状态**：设计阶段
**目标**：修复 `TaskExecutor.execute_login_async` 中的死锁风险

---

## 1. 问题描述

### 1.1 问题位置

文件：`app/services/task_executor.py`
方法：`execute_login_async` (第 195-219 行)

### 1.2 问题代码

```python
def execute_login_async(self, cancel_event=None) -> Future:
    with self._login_lock:                    # ① 获取锁
        if self._login_future is not None and not self._login_future.done():
            return self._login_future
        
        future = self._login_pool.submit(self.execute_login, cancel_event)
        self._login_future = future
        future.add_done_callback(self._on_login_done)  # ② 在锁内注册回调
        return future

def _on_login_done(self, future: Future) -> None:
    with self._login_lock:                    # ③ 回调中再次获取锁
        if self._login_future is future:
            self._login_future = None
```

### 1.3 死锁场景

当 `execute_login` 极快完成时（如配置错误、前置条件不满足）：

1. 主线程在 ① 处获取锁
2. 工作线程在 submit 后立即执行 `execute_login` 并完成
3. Future 状态变为 done，触发回调
4. 回调在 ③ 处尝试获取锁，但锁被主线程持有
5. 主线程在 ② 处注册回调，但回调已在等待锁
6. 主线程释放锁后，回调才能执行

**影响**：主线程被短暂阻塞（微秒级），虽然不是永久死锁，但存在时序风险。

---

## 2. 修复方案

### 2.1 方案选择

采用**方案 1：将 add_done_callback 移到锁外**。

### 2.2 修复后代码

```python
def execute_login_async(self, cancel_event=None) -> Future:
    future = None
    with self._login_lock:
        if self._login_future is not None and not self._login_future.done():
            return self._login_future
        
        future = self._login_pool.submit(self.execute_login, cancel_event)
        self._login_future = future
    
    # 锁外注册回调，避免时序问题
    future.add_done_callback(self._on_login_done)
    return future
```

### 2.3 为什么安全

1. **锁的职责**：保护 `_login_future` 的读写
2. **回调的职责**：清理 `_login_future` 引用
3. **分离后**：锁只保护赋值操作，回调在锁外注册，避免时序问题

### 2.4 不影响去重逻辑

- 去重检查在锁内完成
- 回调只清理引用，不影响去重判断
- 即使回调延迟执行，也不会影响功能正确性

---

## 3. 测试验证

### 3.1 现有测试

所有现有测试应继续通过，无需修改。

### 3.2 新增测试

无需新增测试，因为：
- 修复不改变功能行为
- 现有测试已覆盖去重和并发场景

---

## 4. 风险评估

| 风险 | 影响 | 概率 | 缓解措施 |
|------|------|------|----------|
| 回调延迟执行 | 低 | 低 | 不影响功能正确性 |
| 去重逻辑失效 | 无 | 无 | 去重在锁内完成 |

---

## 5. 实施计划

### 5.1 修改文件

- `app/services/task_executor.py`：第 208-219 行

### 5.2 修改内容

将 `future.add_done_callback(self._on_login_done)` 移到 `with self._login_lock:` 块外。

### 5.3 验证步骤

1. 运行现有测试：`pytest tests/test_services/test_task_executor*.py -v`
2. 运行集成测试：`pytest tests/test_integration/test_login_flow.py -v`
3. 确认无回归

---

**文档版本**：v1.0
**最后更新**：2026-06-15
