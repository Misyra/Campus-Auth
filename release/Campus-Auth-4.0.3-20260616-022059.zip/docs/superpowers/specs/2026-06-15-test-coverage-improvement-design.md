# 测试覆盖率改进设计文档

**日期**：2026-06-15
**状态**：设计阶段
**目标**：将整体测试覆盖率从 77% 提升至 85%+

---

## 1. 背景与目标

### 1.1 当前状况

- **整体覆盖率**：77%
- **测试框架**：pytest + pytest-asyncio + pytest-cov
- **测试文件**：57 个测试文件，覆盖大部分模块

### 1.2 问题分析

**完全缺少测试的关键模块**：
- `app/services/engine.py` - 调度引擎（核心模块）
- `app/services/debug_service.py` - 调试服务
- `app/services/login_history_service.py` - 登录历史
- `app/services/websocket_manager.py` - WebSocket 管理
- `app/api/ocr.py` - OCR API
- `app/tasks/browser_runner.py` - 浏览器任务运行器
- `app/utils/ports.py` - 端口工具
- `app/utils/retry.py` - 重试工具

**低覆盖率模块（<60%）**：
- `app/application.py` - 34%（应用启动核心）
- `app/workers/playwright_worker.py` - 31%（浏览器自动化）
- `app/services/task_executor.py` - 42%（任务执行器）
- `app/services/autostart.py` - 54%（开机自启）
- `app/utils/login.py` - 56%（登录工具）

### 1.3 改进目标

- **主要目标**：整体测试覆盖率 ≥ 85%
- **次要目标**：核心模块覆盖率 ≥ 80%
- **质量目标**：所有测试通过率 100%，执行时间 < 60 秒

---

## 2. 设计方案

### 2.1 方案选择

采用**分层递进法**，按模块依赖关系自底向上补充测试：

1. **第一层**：工具函数测试（提升 2-3%）
2. **第二层**：核心服务测试（提升 3-4%）
3. **第三层**：集成测试（提升 2-3%）

**选择理由**：
- 符合依赖关系，底层稳定后上层测试更可靠
- 每一步都有明确的验证标准，风险最低
- 最符合"先确保核心功能可靠"的目标

### 2.2 测试策略

**Mock 策略**：
- 外部依赖（文件系统、网络、浏览器）必须 mock
- 内部模块间依赖优先使用真实对象
- 避免过度 mock 导致测试失去意义

**测试隔离**：
- 每个测试独立运行，不依赖执行顺序
- 使用 fixtures 管理测试状态
- 临时文件使用 tmp_path 自动清理

**边界条件**：
- 正常流程 + 异常流程
- 并发场景 + 超时处理
- 资源耗尽 + 恢复机制

---

## 3. 详细设计

### 3.1 第一层：工具函数测试

**目标**：确保底层工具函数的可靠性，为上层模块测试打下基础。

**模块清单**：

| 模块 | 当前状态 | 目标 | 测试重点 |
|------|----------|------|----------|
| `utils/ports.py` | 无测试 | 85%+ | 端口检测、端口分配逻辑 |
| `utils/retry.py` | 无测试 | 85%+ | 重试机制、退避策略 |
| `utils/crypto.py` | 79% | 85%+ | 加密解密、密钥管理 |
| `utils/login.py` | 56% | 75%+ | 登录流程、凭证处理 |
| `utils/process.py` | 80% | 85%+ | 进程管理、信号处理 |

**测试示例**：

```python
# tests/test_utils/test_ports.py
class TestPortUtils:
    def test_resolve_port_default(self):
        """测试默认端口分配"""
        
    def test_resolve_port_conflict(self):
        """测试端口冲突时的处理"""
        
    def test_resolve_port_custom_range(self):
        """测试自定义端口范围"""
        
    @pytest.mark.parametrize("port,expected", [...])
    def test_is_port_available(self, port, expected):
        """参数化测试端口可用性检测"""
```

**验证标准**：
- 所有新增测试通过
- 覆盖率达到目标
- 无测试相互依赖

### 3.2 第二层：核心服务测试

**目标**：补充核心业务逻辑的测试，确保调度引擎和任务执行的可靠性。

**模块清单**：

| 模块 | 当前状态 | 目标 | 测试重点 |
|------|----------|------|----------|
| `services/engine.py` | 无测试（75%） | 85%+ | 状态机转换、命令派发、网络检测 |
| `services/task_executor.py` | 42% | 70%+ | 双线程池、任务队列、登录去重 |
| `services/debug_service.py` | 无测试（90%） | 95%+ | 调试会话管理 |
| `services/login_history_service.py` | 无测试（83%） | 90%+ | 历史记录 CRUD |
| `services/websocket_manager.py` | 无测试（93%） | 95%+ | 连接管理、消息广播 |

**engine.py 测试设计**：

```python
# tests/test_services/test_engine.py
class TestScheduleEngine:
    @pytest.fixture
    def engine(self, mock_profile_service, mock_ws_manager):
        """创建测试用引擎实例"""
        return ScheduleEngine(
            project_root=Path("/tmp/test"),
            profile_service=mock_profile_service,
            ws_manager=mock_ws_manager,
        )
    
    def test_start_stop_lifecycle(self, engine):
        """测试引擎启动停止生命周期"""
        
    def test_network_check_when_available(self, engine, mock_network):
        """测试网络正常时的检测流程"""
        
    def test_network_check_when_unavailable(self, engine, mock_network):
        """测试网络异常时的检测流程"""
        
    def test_login_retry_mechanism(self, engine):
        """测试登录重试机制"""
        
    def test_command_dispatch(self, engine):
        """测试命令派发机制"""
```

**task_executor.py 测试设计**：

```python
# tests/test_services/test_task_executor.py
class TestTaskExecutor:
    def test_login_pool_separate_from_task_pool(self):
        """测试登录线程池与任务线程池隔离"""
        
    def test_bounded_executor_queue_full(self):
        """测试队列满时的拒绝行为"""
        
    def test_login_deduplication(self):
        """测试登录去重机制"""
        
    def test_concurrent_task_submission(self):
        """测试并发提交任务的安全性"""
```

**其他服务模块测试**：
- **debug_service.py**：测试调试会话的创建、销毁、状态查询
- **login_history_service.py**：测试历史记录的增删改查
- **websocket_manager.py**：测试连接管理、消息广播、异常处理

**验证标准**：
- 核心引擎的状态转换测试完整
- 任务执行器的并发场景覆盖
- 所有边界条件测试通过
- Mock 设置合理，不影响测试速度

### 3.3 第三层：集成测试

**目标**：验证模块间的协作，确保整个系统的核心流程正确。

**测试范围**：

| 场景 | 涉及模块 | 测试重点 |
|------|----------|----------|
| 应用启动流程 | `application.py` + 依赖注入 | 完整启动链路、依赖初始化 |
| 登录认证流程 | `engine.py` + `task_executor.py` + `browser_runner.py` | 端到端登录流程 |
| 定时任务执行 | `task_executor.py` + `task_registry.py` + `step_handlers.py` | 任务调度执行 |
| WebSocket 通信 | `websocket_manager.py` + API 路由 | 实时状态推送 |

**应用启动集成测试**：

```python
# tests/test_integration/test_app_startup.py
class TestAppStartup:
    @pytest.fixture
    def mock_container(self):
        """模拟 ServiceContainer"""
        
    def test_create_app_initializes_all_services(self, mock_container):
        """测试 create_app 正确初始化所有服务"""
        
    def test_lifespan_startup_shutdown(self, test_client):
        """测试应用生命周期管理"""
        
    def test_dependency_injection(self, test_client):
        """测试依赖注入正确性"""
```

**登录流程集成测试**：

```python
# tests/test_integration/test_login_flow.py
class TestLoginFlow:
    def test_complete_login_sequence(self):
        """测试完整登录序列"""
        # 1. 触发登录命令
        # 2. 验证任务提交到线程池
        # 3. 验证浏览器操作调用
        # 4. 验证结果回调
        
    def test_login_with_network_check(self):
        """测试带网络检测的登录流程"""
        
    def test_login_retry_on_failure(self):
        """测试登录失败重试机制"""
```

**定时任务集成测试**：

```python
# tests/test_integration/test_scheduled_task.py
class TestScheduledTask:
    def test_task_registration_and_execution(self):
        """测试任务注册和执行"""
        
    def test_task_with_variable_resolution(self):
        """测试带变量解析的任务执行"""
        
    def test_task_failure_handling(self):
        """测试任务失败处理"""
```

**测试环境配置**：
- 使用 pytest fixtures 管理测试依赖
- 使用 tmp_path 隔离文件系统操作
- 使用 mock server 模拟外部服务

**验证标准**：
- 核心业务流程端到端测试通过
- 模块间依赖正确验证
- 异常场景覆盖完整
- 测试执行时间合理（< 30 秒）

---

## 4. 实施计划

### 4.1 时间安排

| 阶段 | 内容 | 预计时间 | 覆盖率提升 |
|------|------|----------|-----------|
| 第一层 | 工具函数测试 | 1-2 天 | +2-3% → 80% |
| 第二层 | 核心服务测试 | 2-3 天 | +3-4% → 84% |
| 第三层 | 集成测试 | 1-2 天 | +2-3% → 86% |
| **总计** | | **4-7 天** | **+9% → 86%** |

### 4.2 执行顺序

1. **第一层：工具函数测试**
   - 优先补充 `ports.py`、`retry.py` 的单元测试
   - 提升 `crypto.py`、`login.py` 覆盖率
   - 验证：所有测试通过，覆盖率达标

2. **第二层：核心服务测试**
   - 为 `engine.py` 添加单元测试（mock 外部依赖）
   - 为 `task_executor.py` 补充边界条件测试
   - 为 `browser_runner.py` 添加核心流程测试
   - 验证：核心模块测试完整，覆盖率达标

3. **第三层：集成测试**
   - 添加 `application.py` 启动流程集成测试
   - 补充 `websocket_manager.py` 集成测试
   - 验证：端到端流程测试通过，整体覆盖率达标

---

## 5. 风险评估

### 5.1 风险识别

| 风险 | 影响 | 概率 | 缓解措施 |
|------|------|------|----------|
| 模块耦合过紧难以 mock | 中 | 中 | 重构依赖注入，使用接口抽象 |
| 测试执行时间过长 | 低 | 低 | 优化 mock，减少 I/O 操作 |
| 覆盖率提升不及预期 | 中 | 中 | 优先测试核心路径，接受部分模块覆盖率不达标 |
| 测试相互依赖导致不稳定 | 中 | 低 | 严格隔离测试，使用 fixtures 管理状态 |

### 5.2 应对策略

**如果模块耦合过紧**：
- 识别紧耦合点，提出重构建议
- 使用依赖注入容器管理依赖
- 优先测试可隔离的部分

**如果测试执行时间过长**：
- 分析慢测试，优化 mock 策略
- 使用 pytest-xdist 并行执行测试
- 减少不必要的 I/O 操作

**如果覆盖率提升不及预期**：
- 重新评估模块优先级
- 优先保证核心模块覆盖率
- 接受部分非核心模块覆盖率不达标

---

## 6. 成功标准

### 6.1 必须达到

- [ ] 整体测试覆盖率 ≥ 85%
- [ ] 核心模块（engine、task_executor、browser_runner）覆盖率 ≥ 80%
- [ ] 所有新增测试通过率 100%
- [ ] 测试执行时间 < 60 秒

### 6.2 期望达到

- [ ] 整体测试覆盖率 ≥ 86%
- [ ] 核心模块覆盖率 ≥ 85%
- [ ] 无测试相互依赖
- [ ] 测试代码可读性良好

---

## 7. 后续维护

### 7.1 CI/CD 集成

- 在 PR 流程中添加覆盖率检查
- 设置覆盖率下降告警阈值（如：单次 PR 下降 > 2%）
- 自动生成覆盖率报告

### 7.2 测试文档

- 为复杂测试添加注释说明
- 维护测试用例清单
- 定期更新测试策略文档

### 7.3 定期回顾

- 每月审查测试有效性
- 及时清理过时测试
- 根据项目发展调整测试策略

---

## 8. 附录

### 8.1 测试文件组织

```
tests/
├── test_api/                    # API 路由测试
├── test_app/                    # 应用层测试
├── test_config/                 # 配置模块测试
├── test_core/                   # 核心逻辑测试
├── test_integration/            # 集成测试（新增）
│   ├── test_app_startup.py
│   ├── test_login_flow.py
│   └── test_scheduled_task.py
├── test_services/               # 服务层测试
├── test_utils/                  # 工具函数测试
└── conftest.py                  # 测试配置
```

### 8.2 测试命名规范

- 测试文件：`test_<模块名>.py`
- 测试类：`Test<模块名>`
- 测试方法：`test_<功能描述>`
- 使用下划线分隔，描述清晰

### 8.3 测试覆盖率目标

| 模块类型 | 目标覆盖率 | 说明 |
|----------|-----------|------|
| 工具函数 | 85%+ | 底层依赖，必须可靠 |
| 核心服务 | 80%+ | 业务逻辑，重点测试 |
| API 路由 | 75%+ | 接口层，主要测试异常处理 |
| 集成测试 | N/A | 覆盖核心流程，不追求覆盖率 |

---

**文档版本**：v1.0
**最后更新**：2026-06-15
**作者**：AI Assistant
