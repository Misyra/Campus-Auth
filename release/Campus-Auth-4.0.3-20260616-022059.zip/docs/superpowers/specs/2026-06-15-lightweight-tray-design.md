# 轻量模式托盘支持 + 自启动独立卡片

**日期**: 2026-06-15
**状态**: 已批准

## 目标

1. 轻量模式支持系统托盘（独立开关）
2. 托盘"打开控制台"按钮可按需唤醒 WebUI
3. 自启动设置在前端独立为醒目的卡片

## 设计

### 1. 新增配置字段

在 `GlobalSettings`（`app/schemas.py`）中新增：

```python
lightweight_tray: bool = Field(default=True, description="轻量模式显示系统托盘")
```

### 2. 托盘行为

| | 完整模式 | 轻量模式 |
|--|---------|---------|
| 开关 | `minimize_to_tray` | `lightweight_tray` |
| "打开控制台" | 直接打开浏览器 | 启动 Web 服务 → 打开浏览器 |

**轻量模式"打开控制台"逻辑**：
- Web 服务未启动 → 启动 Uvicorn → 打开浏览器
- Web 服务已运行 → 直接打开浏览器
- Web 服务启动后保持运行，不卸载

### 3. 后端改动

#### 3.1 schemas.py

- `GlobalSettings` 新增 `lightweight_tray` 字段
- `get_runtime_features()` 修改：轻量模式下 `tray_enabled` 改为由 `lightweight_tray` 控制

```python
def get_runtime_features(
    mode: RuntimeMode | str, minimize_to_tray: bool, auto_open_browser: bool,
    lightweight_tray: bool = True
) -> RuntimeFeatures:
    if mode == RuntimeMode.LIGHTWEIGHT:
        return RuntimeFeatures(
            web_enabled=False,
            browser_enabled=False,
            tray_enabled=lightweight_tray,
        )
    return RuntimeFeatures(
        web_enabled=True,
        browser_enabled=auto_open_browser,
        tray_enabled=minimize_to_tray,
    )
```

#### 3.2 main.py

- `_build_app_config()` 读取 `lightweight_tray` 配置
- `AppConfig` 新增 `lightweight_tray` 字段
- `_run_lightweight()` 中托盘逻辑改为使用 `lightweight_tray`
- 托盘 `on_exit` 回调中，如果 Web 服务已启动则先关闭

#### 3.3 system_tray.py

- 构造函数新增 `on_open_console` 回调参数
- "打开控制台"菜单项优先调用 `on_open_console`，无回调时回退到 `webbrowser.open()`

#### 3.4 轻量模式 Web 服务启动

在 `_run_lightweight()` 中，当托盘触发"打开控制台"时：
1. 检查 Web 服务是否已启动
2. 未启动 → 在单独线程中调用 `app.application.run()` 启动 FastAPI + Uvicorn
3. 等待 Uvicorn 就绪（端口监听中）
4. 打开浏览器

需要在单独线程中启动，因为主循环是 `while True: time.sleep(60)` 阻塞的。

### 4. 前端改动

#### 4.1 settings-system.html

自启动部分从"系统策略"面板中独立出来，作为单独的卡片区域：

```
┌─────────────────────────────────┐
│  开机自启动                      │
│  ┌─────────────────────────────┐│
│  │ [开关] 开机自启动            ││
│  │ 方式: [轻量模式] [完整模式]  ││
│  └─────────────────────────────┘│
│                                 │
│  轻量模式托盘                    │
│  ┌─────────────────────────────┐│
│  │ [开关] 显示系统托盘          ││
│  └─────────────────────────────┘│
└─────────────────────────────────┘
```

#### 4.2 前端配置同步

- `config.js` 中新增 `lightweight_tray` 字段的读写
- `fetchConfig()` 和 `saveConfig()` 处理新字段

### 5. 调用链路

```
用户点击托盘"打开控制台"
  → SystemTray.on_open_console()
  → _run_lightweight 中的回调
    → 检查 Web 服务是否已启动
    → 未启动: container.start_web_services() + 启动 Uvicorn
    → webbrowser.open(port)
```

### 6. 不做的事情

- 不做 Web 服务按需卸载
- 不做 Web 服务空闲超时
- 不修改完整模式的托盘行为
