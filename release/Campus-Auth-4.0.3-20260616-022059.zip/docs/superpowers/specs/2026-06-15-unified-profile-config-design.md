# 统一 Profile 配置设计

## 目标

将账号、密码、运营商、任务、认证地址等业务字段从 SystemSettings 移到 ProfileSettings，让 Profile 成为配置的唯一数据源，简化代码逻辑。

## 当前问题

1. **职责不清**：凭证字段同时存在于 SystemSettings 和 ProfileSettings
2. **复杂合并逻辑**：`_build_config_payload` 需要根据 `use_global_*` 标志合并 system 和 profile
3. **条件分支多**：10 个 `use_global` 相关的条件判断
4. **代码重复**：`_update_system_settings` 和 `_build_runtime_config` 有重复的字段映射

## 设计方案

### 1. 数据模型重构

#### GlobalSettings（新，替代 SystemSettings）

只保留纯系统配置，不包含任何业务逻辑：

```python
class GlobalSettings(BaseModel):
    """全局系统配置 — 仅系统级设置，不包含业务逻辑"""

    # 日志配置
    backend_log_level: str = Field(default="INFO")
    frontend_log_level: str = Field(default="INFO")
    access_log: bool = Field(default=False, description="Uvicorn HTTP 请求日志")
    log_retention_days: int = Field(default=7, ge=1, le=365, description="日志保留天数")

    # UI 配置
    minimize_to_tray: bool = Field(default=True, description="最小化到系统托盘")
    auto_open_browser: bool = Field(default=False, description="启动后自动打开浏览器")
    startup_action: StartupAction = Field(default=StartupAction.NONE)
    autostart_lightweight: bool = Field(default=True)

    # 网络配置
    proxy: str = Field(default="", description="网络代理地址")
    block_proxy: bool = Field(default=True, description="屏蔽系统代理")

    # 应用配置
    app_port: int = Field(default=50721, ge=1024, le=65535)
    shell_path: str = Field(default="", description="自定义 Shell 路径")
    pure_mode: bool = Field(default=True, description="纯净模式")

    # 重试配置
    max_retries: int = Field(default=3, ge=0, le=10)
    retry_interval: int = Field(default=5, ge=1, le=300, description="重试间隔（秒）")

    # Source 级别配置
    source_levels: dict[str, str] = {}
```

#### ProfileSettings（扩展）

成为配置的唯一数据源，包含所有业务配置：

```python
class ProfileSettings(BaseModel):
    """方案配置 — 所有业务配置的唯一数据源"""

    # 基本信息
    name: str = Field(default="默认方案")
    match_gateway_ip: str = Field(default="", description="匹配的网关 IP")
    match_ssid: str = Field(default="", description="匹配的 WiFi SSID")

    # 凭证配置（必填）
    username: str = Field(default="", description="校园网用户名")
    password: str = Field(default="", description="校园网密码（加密存储）")
    carrier: str = Field(default="无", description="运营商")
    carrier_custom: str = Field(default="", description="自定义运营商关键字")
    auth_url: str = Field(default="", description="认证地址")
    active_task: str = Field(default="", description="活动任务")

    # 监控配置
    check_interval_seconds: int = Field(default=300, ge=10, le=86400)
    pause_enabled: bool = Field(default=True)
    pause_start_hour: int = Field(default=0, ge=0, le=23)
    pause_end_hour: int = Field(default=6, ge=0, le=23)
    network_targets: str = Field(default=DEFAULT_NETWORK_TARGETS)
    http_targets: str = Field(default=DEFAULT_HTTP_TARGETS)
    enable_tcp_check: bool = Field(default=False)
    enable_http_check: bool = Field(default=False)
    enable_local_check: bool = Field(default=True)
    check_auth_url: bool = Field(default=False)
    auth_url_targets: str = Field(default="")
    url_check_urls: str = Field(default="...")
    network_check_timeout: int = Field(default=2, ge=1, le=30)

    # 浏览器配置
    headless: bool = Field(default=True)
    browser_timeout: int = Field(default=8, ge=1, le=60)
    browser_navigation_timeout: int = Field(default=30, ge=1, le=120)
    login_timeout: int = Field(default=60, ge=10, le=600)
    browser_user_agent: str = Field(default="Mozilla/5.0 ...")
    browser_low_resource_mode: bool = Field(default=False)
    browser_disable_web_security: bool = Field(default=False)
    browser_extra_headers_json: str = Field(default="")
    browser_args: str = Field(default="")
    stealth_mode: bool = Field(default=False)
    stealth_custom_script: str = Field(default="")
    browser_locale: str = Field(default="zh-CN")
    browser_timezone: str = Field(default="Asia/Shanghai")
    browser_viewport_width: int = Field(default=1280)
    browser_viewport_height: int = Field(default=720)

    # 自定义变量
    custom_variables: dict[str, str] = Field(default_factory=dict)
```

#### ProfilesData（更新）

```python
class ProfilesData(BaseModel):
    """Top-level structure of settings.json"""

    auto_switch: bool = Field(default=False)
    active_profile: str = Field(default="default")
    global_settings: GlobalSettings = Field(default_factory=GlobalSettings)  # 改名
    profiles: dict[str, ProfileSettings] = Field(default_factory=dict)
```

---

### 2. 配置加载逻辑简化

#### 当前逻辑（复杂）

```python
def _build_config_payload(profile_service, data, apply_overrides):
    # 从 system 提取基础字段
    payload_dict = extract_profile_fields(system_settings.model_dump(), PROFILE_FIELDS)

    if apply_overrides:
        # 复杂的合并逻辑
        if profile and not profile.use_global_credentials and profile.username:
            payload_dict["username"] = profile.username
            # ... 10+ 行条件判断
        else:
            payload_dict["username"] = system_settings.username
            # ... fallback 逻辑
    else:
        # UI 模式
        payload_dict["password"] = mask_password(system_settings.password)
```

#### 方案B后（简化）

```python
def _build_config_payload(profile_service, data, apply_overrides):
    profile = data.profiles.get(data.active_profile)

    if apply_overrides:
        # 直接从 profile 读取，无条件判断
        payload_dict = profile.model_dump()
        payload_dict["password"] = _decrypt_password_field(profile.password)
    else:
        # UI 模式：返回 profile 配置，密码掩码
        payload_dict = profile.model_dump()
        payload_dict["password"] = mask_password(profile.password)

    # 合并 global_settings 中的系统配置
    payload_dict.update({
        "backend_log_level": data.global_settings.backend_log_level,
        "frontend_log_level": data.global_settings.frontend_log_level,
        "access_log": data.global_settings.access_log,
        "log_retention_days": data.global_settings.log_retention_days,
        "minimize_to_tray": data.global_settings.minimize_to_tray,
        "auto_open_browser": data.global_settings.auto_open_browser,
        "startup_action": data.global_settings.startup_action,
        "autostart_lightweight": data.global_settings.autostart_lightweight,
        "proxy": data.global_settings.proxy,
        "block_proxy": data.global_settings.block_proxy,
        "app_port": data.global_settings.app_port,
        "shell_path": data.global_settings.shell_path,
        "pure_mode": data.global_settings.pure_mode,
        "max_retries": data.global_settings.max_retries,
        "retry_interval": data.global_settings.retry_interval,
        "source_levels": data.global_settings.source_levels,
    })

    return MonitorConfigPayload(**payload_dict)
```

**减少**：约40行代码，10个条件分支

---

### 3. 配置保存逻辑简化

#### 当前逻辑

```python
def _update_system_settings(system_settings, payload):
    # 更新凭证字段
    system_settings.username = payload.username
    system_settings.password = save_password_field(payload.password)
    system_settings.auth_url = payload.auth_url
    system_settings.carrier = payload.carrier
    # ... 更多字段
```

#### 方案B后

```python
def _update_global_settings(global_settings, payload):
    # 只更新系统配置，不更新凭证
    global_settings.backend_log_level = payload.backend_log_level
    global_settings.frontend_log_level = payload.frontend_log_level
    global_settings.proxy = payload.proxy
    # ... 只有系统配置
```

**减少**：约15行代码

---

### 4. 迁移策略

启动时自动迁移：

```python
def migrate_config_if_needed(data: ProfilesData) -> ProfilesData:
    """迁移旧配置到新格式"""
    system = data.system

    # 检查是否有凭证需要迁移
    has_credentials = any([
        system.username,
        system.password,
        system.auth_url,
        system.carrier != "无",
        system.active_task,
    ])

    if has_credentials:
        # 确保 default profile 存在
        if "default" not in data.profiles:
            data.profiles["default"] = ProfileSettings()

        default_profile = data.profiles["default"]

        # 迁移凭证到 default profile
        if system.username and not default_profile.username:
            default_profile.username = system.username
        if system.password and not default_profile.password:
            default_profile.password = system.password
        if system.auth_url and not default_profile.auth_url:
            default_profile.auth_url = system.auth_url
        if system.carrier and system.carrier != "无":
            default_profile.carrier = system.carrier
            default_profile.carrier_custom = system.carrier_custom
        if system.active_task and not default_profile.active_task:
            default_profile.active_task = system.active_task

        # 清空 system 中的凭证
        system.username = ""
        system.password = ""
        system.auth_url = ""
        system.carrier = "无"
        system.carrier_custom = ""
        system.active_task = ""

        logger.info("已迁移凭证到 default profile")

    return data
```

---

### 5. 前端改动

#### 移除的UI元素

1. **设置页面**：
   - 移除"使用全局账号密码"开关
   - 移除"使用全局认证地址"开关
   - 移除"使用全局任务"开关
   - 移除 system 中的凭证输入框

2. **方案编辑页面**：
   - 所有凭证字段变为必填（或有默认值）
   - 移除 `use_global_*` 相关的显示逻辑

#### 新增的UI元素

1. **设置页面**：
   - 显示当前活动方案的凭证信息（只读）
   - 提供"编辑当前方案"按钮

---

### 6. API 改动

#### GET /api/config

返回当前活动方案的配置（包含凭证）：

```json
{
  "username": "admin",
  "password": "••••••",
  "auth_url": "http://...",
  "carrier": "移动",
  "check_interval_seconds": 300,
  // ... 其他配置
}
```

#### PUT /api/config

保存配置到当前活动方案：

```json
{
  "username": "admin",
  "password": "new_password",
  "auth_url": "http://...",
  "carrier": "移动",
  // ... 其他配置
}
```

---

### 7. 测试策略

1. **单元测试**：
   - 测试 `migrate_config_if_needed` 迁移逻辑
   - 测试 `_build_config_payload` 简化后的逻辑
   - 测试 `GlobalSettings` 和 `ProfileSettings` 的验证

2. **集成测试**：
   - 测试配置保存和加载流程
   - 测试 profile 切换
   - 测试自动切换方案

3. **迁移测试**：
   - 测试旧配置迁移到新格式
   - 测试迁移后配置的正确性

---

### 8. 实施步骤

1. **Phase 1：数据模型**
   - 创建 `GlobalSettings` 类
   - 扩展 `ProfileSettings` 类
   - 更新 `ProfilesData` 类

2. **Phase 2：迁移逻辑**
   - 实现 `migrate_config_if_needed`
   - 在配置加载时调用迁移

3. **Phase 3：简化配置加载**
   - 重构 `_build_config_payload`
   - 简化 `_update_global_settings`

4. **Phase 4：前端改动**
   - 移除 `use_global_*` 相关UI
   - 更新设置页面和方案编辑页面

5. **Phase 5：测试和验证**
   - 运行所有测试
   - 手动测试迁移流程
   - 验证配置保存和加载

---

### 9. 风险和缓解

| 风险 | 缓解措施 |
|------|----------|
| 迁移失败导致配置丢失 | 迁移前备份 settings.json |
| 旧版本配置不兼容 | 保留迁移逻辑，支持旧格式 |
| 前端改动范围大 | 分阶段实施，先改后端再改前端 |
| 测试覆盖不足 | 添加迁移测试和集成测试 |

---

### 10. 成功标准

1. ✅ 配置加载代码减少 40+ 行
2. ✅ 消除所有 `use_global_*` 条件分支
3. ✅ 迁移后配置正确，无数据丢失
4. ✅ 所有测试通过
5. ✅ 前端UI正常工作
